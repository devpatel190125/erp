# School ERP — Complete quality build

**Stack:** FastAPI + MySQL (XAMPP) · HTML/CSS/JS · 5 portals  
**Portals:** Admin · Teacher · Student · Parent · Warden

## Highlights
- Classes 1–12 with stage-wise subjects (seed)
- EduFlow-style UI, right drawers, compact toasts, theme colours
- Admin: dashboard, people, academics, exams (mark entry + results), fees (proper payment flow), timetable, hostel, reports, settings
- Teacher: dashboard, attendance, assignments + submissions, mark entry, materials, timetable
- Student: dashboard, documents, homework boxes, results, notices; **hostel menu only if hosteler**
- Parent: child overview + fees; **hostel only if child is hosteler**
- Warden: occupancy, rooms/beds map, mess weekly grid editor, outpass, visitors

## Setup
1. MySQL: create database `school_erp`
2. `backend/.env` from `.env.example` → `DATABASE_URL=mysql+pymysql://root:@127.0.0.1:3306/school_erp`
3. ```
   cd backend
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   python seed.py
   uvicorn app.main:app --reload --port 8000
   ```
4. Open http://127.0.0.1:8000 — hard refresh (Ctrl+Shift+R)

## Demo login
| Role | ID | Password / OTP |
|------|-----|----------------|
| Admin | 9000000001 | Admin@123 then OTP **123456** |
| Others | numbers printed by seed | OTP **123456** |

## Notes
- Console OTP mode: always `123456`
- Schema columns auto-added on startup
- If seed says data exists: DROP + CREATE database then seed again
