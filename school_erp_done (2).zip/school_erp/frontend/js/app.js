/* School ERP – complete multi-portal build */
/* School ERP - shared frontend engine. Each page html sets window.ROLE and window.PAGE. */
const API = (location.port === "8000" || location.port === "") ? "/api" : "http://localhost:8000/api";
const $ = (s, r = document) => r.querySelector(s);
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const DIR = { admin: "admin", student: "student", teacher: "teacher", parent: "parent", warden: "hostel" };
const ROOT = location.pathname.split("/").length > 2 && /\/(admin|student|teacher|parent|hostel)\//.test(location.pathname) ? "../" : "";

function toast(msg, ok = true) {
  document.querySelectorAll(".toast").forEach(el => el.remove());
  const t = document.createElement("div");
  t.className = "toast " + (ok ? "ok" : "err");
  t.innerHTML = `<span class="toast-ico">${ok ? "✓" : "!"}</span><span class="toast-msg">${esc(String(msg || ""))}</span>`;
  document.body.appendChild(t);
  requestAnimationFrame(() => t.classList.add("show"));
  setTimeout(() => { t.classList.remove("show"); setTimeout(() => t.remove(), 220); }, 2800);
}
function logout() { localStorage.clear(); location.href = ROOT + "login.html"; }
async function api(path, opt = {}) {
  const h = { ...(opt.headers || {}) }; const tk = localStorage.getItem("erp_token"); if (tk) h.Authorization = "Bearer " + tk;
  if (opt.json) { h["Content-Type"] = "application/json"; opt.body = JSON.stringify(opt.json); }
  const r = await fetch(API + path, { ...opt, headers: h });
  if (r.status === 401 && tk) { logout(); return; }
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(Array.isArray(d.detail) ? d.detail.map(x => (x.loc || []).slice(-1) + ": " + x.msg).join("; ") : d.detail || "Request failed");
  return d;
}
const post = (p, json) => api(p, { method: "POST", json });
const put = (p, json) => api(p, { method: "PUT", json });
const URLQ = new URLSearchParams(location.search).get("q") || "";      // set by the search bar on list pages
async function getPdf(path, name) {                                    // downloads a PDF (the login token must be sent, so a plain link would not work)
  try {
    const res = await fetch(API + path, { headers: { Authorization: "Bearer " + localStorage.erp_token } });
    if (!res.ok) { let m = "Could not create the PDF"; try { m = (await res.json()).detail || m; } catch (e) { } return toast(m, false); }
    const a = document.createElement("a"); a.href = URL.createObjectURL(await res.blob()); a.download = name; a.click(); toast("PDF downloaded");
  } catch (e) { toast(e.message, false); }
}

/* ---------------- charts (pure SVG - no library, works offline, follows the dark/light theme) ---------------- */
const PAL = ["#E56F22", "#476EA5", "#269777", "#A477C0", "#D4A23D", "#D95F0C", "#B92D42", "#18734F", "#F48C48", "#85A9DA"];
const COL = { Present: "#269777", Absent: "#B92D42", Late: "#D4A23D", Leave: "#476EA5", Pass: "#269777", Fail: "#B92D42", Paid: "#269777", Collected: "#269777",
  Pending: "#D4A23D", Open: "#B92D42", Resolved: "#269777", High: "#B92D42", Medium: "#D4A23D", Low: "#269777", "Occupied beds": "#E56F22", "Free beds": "#269777",
  Occupied: "#E56F22", Free: "#269777", "90% and above": "#269777", "75% - 89%": "#D4A23D", "Below 75%": "#B92D42", Active: "#269777", Inactive: "#607086",
  student: "#476EA5", teacher: "#A477C0", parent: "#D4A23D", warden: "#269777", admin: "#E56F22" };
const col = (k, i) => COL[k] || PAL[i % PAL.length];
const num = v => Number(v) || 0;
const fmt = v => Number(v).toLocaleString("en-IN", { maximumFractionDigits: 2 });
const short = (t, n = 10) => { t = String(t); return t.length > n ? t.slice(0, n - 1) + "…" : t; };
const pctColor = (k, v) => v >= 75 ? "#269777" : v >= 50 ? "#D4A23D" : "#B92D42";
const NO_DATA = '<div class="chart-empty"><span>No data for this chart</span></div>';
function chartCard(title, inner) { const d = document.createElement("div"); d.className = "card chart anim-in"; d.innerHTML = `<div class="chart-head"><b>${esc(title)}</b></div>${inner}`; return d; }
const entries = o => Object.entries(o || {}).map(([k, v]) => [k, num(v)]);

function donut(obj, title, o = {}) {
  const e = entries(obj).filter(([, v]) => v > 0), tot = e.reduce((a, [, v]) => a + v, 0);
  if (!tot) return chartCard(title, NO_DATA);
  const R = 38, CX = 55, CY = 55, C = 2 * Math.PI * R; let off = 0;
  const arcs = e.map(([k, v], i) => {
    const len = v / tot * C;
    const s = `<circle r="${R}" cx="${CX}" cy="${CY}" fill="none" stroke="${col(k, i)}" stroke-width="16" stroke-linecap="butt" stroke-dasharray="${len} ${C - len}" stroke-dashoffset="${-off}" transform="rotate(-90 ${CX} ${CY})"><title>${esc(k)}: ${fmt(v)}</title></circle>`;
    off += len; return s;
  }).join("");
  const legend = e.map(([k, v], i) =>
    `<div class="lg"><i style="background:${col(k, i)}"></i><span title="${esc(k)}">${esc(short(k, 12))}</span><b>${o.money ? "₹" : ""}${fmt(v)}</b><span class="pct">${Math.round(v / tot * 100)}%</span></div>`
  ).join("");
  const fs = String(fmt(tot)).length > 6 ? 13 : 17;
  return chartCard(title, `<div class="donut">
    <svg viewBox="0 0 110 110" width="110" height="110" aria-hidden="true">
      <circle r="${R}" cx="${CX}" cy="${CY}" fill="none" stroke="var(--border)" stroke-width="16"/>
      ${arcs}
      <text x="${CX}" y="${CY - 2}" text-anchor="middle" class="ct" style="font-size:${fs}px;font-weight:700;fill:var(--text)">${o.money ? "₹" : ""}${fmt(tot)}</text>
      <text x="${CX}" y="${CY + 14}" text-anchor="middle" class="cs" style="font-size:11px;fill:var(--muted)">${esc(o.sub || "total")}</text>
    </svg>
    <div class="legend">${legend}</div>
  </div>`);
}


function barChart(obj, title, o = {}) {
  let e = entries(obj);
  if (!e.length || e.every(([, v]) => !v)) return chartCard(title, NO_DATA);
  // Drop leading zeros (e.g. empty months) keep trailing data
  while (e.length > 1 && !e[0][1]) e = e.slice(1);
  if (e.length > 14) e = e.slice(0, 14);
  const max = o.max || Math.max(1, ...e.map(x => x[1])) * 1.15;
  const n = e.length;
  const L = 36, Rpad = 8, T = 18, B = 42;
  const W = 300, H = 170;
  const step = (W - L - Rpad) / n;
  const bw = Math.min(22, Math.max(8, step * 0.55));
  const grid = [0, 0.5, 1].map(f => {
    const y = T + (H - T - B) * (1 - f);
    return `<line x1="${L}" x2="${W - Rpad}" y1="${y}" y2="${y}" class="gl"/><text x="${L - 4}" y="${y + 3}" text-anchor="end" class="ax">${fmt(max * f)}</text>`;
  }).join("");
  const bars = e.map(([k, v], i) => {
    const h = (H - T - B) * (v / max);
    const x = L + step * i + (step - bw) / 2;
    const y = H - B - h;
    const c = o.color ? o.color(k, v) : col(k, o.single ? 0 : i);
    // Label: prefer trailing number (Class 12 -> 12) or short text
    let lab = String(k).replace(/^Class\s*/i, "").trim() || String(k);
    lab = short(lab, n > 10 ? 4 : 8);
    const rotate = n > 8;
    const labEl = rotate
      ? `<text x="${x + bw / 2}" y="${H - B + 10}" text-anchor="end" class="ax" transform="rotate(-40 ${x + bw / 2} ${H - B + 10})" style="font-size:9px">${esc(lab)}</text>`
      : `<text x="${x + bw / 2}" y="${H - 8}" text-anchor="middle" class="ax" style="font-size:10px">${esc(lab)}</text>`;
    return `<rect x="${x}" y="${y}" width="${bw}" height="${Math.max(h, 1)}" rx="4" fill="${c}"><title>${esc(k)}: ${fmt(v)}${o.unit || ""}</title></rect>
      <text x="${x + bw / 2}" y="${y - 3}" text-anchor="middle" class="vl" style="font-size:9px">${fmt(v)}</text>${labEl}`;
  }).join("");
  return chartCard(title, `<div class="chart-svg-wrap"><svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" preserveAspectRatio="xMidYMid meet">${grid}${bars}</svg></div>`);
}


function lineChart(obj, title, o = {}) {
  const e = entries(obj);
  if (e.length < 2) return e.length ? barChart(obj, title, o) : chartCard(title, NO_DATA);
  const W = 300, H = 170, L = 36, R = 12, T = 18, B = 32;
  const hi = o.max || Math.max(1, ...e.map(x => x[1])) * 1.08;
  const lo = o.min ?? 0;
  const x = i => L + (W - L - R) * i / Math.max(1, e.length - 1);
  const y = v => T + (H - T - B) * (1 - (v - lo) / (hi - lo || 1));
  const grid = [0, 0.5, 1].map(f => {
    const yy = T + (H - T - B) * (1 - f);
    return `<line x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}" class="gl"/><text x="${L - 4}" y="${yy + 3}" text-anchor="end" class="ax">${fmt(lo + (hi - lo) * f)}</text>`;
  }).join("");
  const pts = e.map(([, v], i) => `${x(i)},${y(v)}`).join(" ");
  const dots = e.map(([k, v], i) =>
    `<circle cx="${x(i)}" cy="${y(v)}" r="3.5" fill="var(--accent)"><title>${esc(k)}: ${fmt(v)}${o.unit || ""}</title></circle>
     <text x="${x(i)}" y="${y(v) - 8}" text-anchor="middle" class="vl" style="font-size:9px">${fmt(v)}${o.unit || ""}</text>
     <text x="${x(i)}" y="${H - 8}" text-anchor="middle" class="ax" style="font-size:9px">${esc(short(k, 6))}</text>`
  ).join("");
  return chartCard(title, `<div class="chart-svg-wrap"><svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" preserveAspectRatio="xMidYMid meet">${grid}
    <polyline fill="none" stroke="var(--accent)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" points="${pts}"/>
    ${dots}</svg></div>`);
}


function hbars(obj, title, o = {}) {           // horizontal bars - best for long labels / percentages
  const e = entries(obj); if (!e.length) return chartCard(title, NO_DATA);
  const max = o.max || Math.max(1, ...e.map(x => x[1]));
  return chartCard(title, e.slice(0, o.limit || 12).map(([k, v], i) => `<div class="hb"><span title="${esc(k)}">${esc(short(k, 26))}</span><div class="tr"><i style="width:${Math.min(100, v / max * 100)}%;background:${o.color ? o.color(k, v) : col(k, o.single ? 0 : i)}"></i></div><b>${fmt(v)}${o.unit || ""}</b></div>`).join(""));
}


function groupBars(obj, title, o = {}) {
  const labels = Object.keys(obj || {});
  if (!labels.length) return chartCard(title, NO_DATA);
  const names = [...new Set(labels.flatMap(l => Object.keys(obj[l] || {})))];
  const all = labels.flatMap(l => names.map(n => num((obj[l] || {})[n])));
  if (!all.length || all.every(v => !v)) return chartCard(title, NO_DATA);
  const max = Math.max(1, ...all) * 1.15;
  const W = 300, H = 170, L = 36, R = 8, T = 18, B = 36;
  const gw = (W - L - R) / labels.length;
  const bw = Math.min(12, (gw * 0.7) / Math.max(1, names.length));
  const grid = [0, 0.5, 1].map(f => {
    const y = T + (H - T - B) * (1 - f);
    return `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" class="gl"/><text x="${L - 4}" y="${y + 3}" text-anchor="end" class="ax">${fmt(max * f)}</text>`;
  }).join("");
  let bars = "";
  labels.forEach((lab, i) => {
    names.forEach((nm, j) => {
      const v = num((obj[lab] || {})[nm]);
      const h = (H - T - B) * v / max;
      const x = L + gw * i + (gw - names.length * bw) / 2 + j * bw;
      const y = H - B - h;
      bars += `<rect x="${x}" y="${y}" width="${bw}" height="${Math.max(h, 1)}" rx="2" fill="${col(nm, j)}"><title>${esc(lab)} ${esc(nm)}: ${fmt(v)}</title></rect>`;
    });
    bars += `<text x="${L + gw * i + gw / 2}" y="${H - 10}" text-anchor="middle" class="ax" style="font-size:9px">${esc(short(lab, 8))}</text>`;
  });
  const legend = names.map((nm, j) => `<span class="lg" style="display:inline-flex;align-items:center;gap:4px;margin-right:8px;font-size:11px"><i style="width:8px;height:8px;border-radius:2px;background:${col(nm, j)};display:inline-block"></i>${esc(nm)}</span>`).join("");
  return chartCard(title, `<div class="chart-svg-wrap"><svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}">${grid}${bars}</svg><div style="margin-top:4px">${legend}</div></div>`);
}

const CHARTS = { donut, bar: barChart, line: lineChart, hbar: hbars, group: groupBars };
const monthly = rows => { const m = {}; rows.forEach(r => { const k = String(r.date).slice(0, 7); (m[k] ??= [0, 0]); m[k][1]++; if (r.status === "Present" || r.status === "Late") m[k][0]++; });
  return Object.fromEntries(Object.keys(m).sort().map(k => [k, Math.round(m[k][0] / m[k][1] * 1000) / 10])); };
const attBuckets = rows => { const b = { "90% and above": 0, "75% - 89%": 0, "Below 75%": 0 }; rows.forEach(r => { const p = num(r.attendance); b[p >= 90 ? "90% and above" : p >= 75 ? "75% - 89%" : "Below 75%"]++; }); return b; };

/* turn table rows (or a dashboard/data object) into chart data. spec: {type,title,by|totals|series|label+value|map|fn|key} */
function chartData(spec, rows, data) {
  if (spec.key) return data?.[spec.key];
  if (spec.fn) return spec.fn(rows);
  if (spec.map) return Object.fromEntries(Object.entries(spec.map).map(([n, f]) => [n, data?.[f] ?? 0]));
  const L = r => typeof spec.label === "function" ? spec.label(r) : r[spec.label];
  if (spec.by) { const o = {}; rows.forEach(r => { const k = r[spec.by] ?? "-"; o[k] = (o[k] || 0) + 1; }); return o; }
  if (spec.totals) return Object.fromEntries(Object.entries(spec.totals).map(([n, f]) => [n, rows.reduce((a, r) => a + num(r[f]), 0)]));
  if (spec.series) { const o = {}; rows.forEach(r => { const k = L(r); o[k] ??= {}; spec.series.forEach(([f, n]) => o[k][n] = (o[k][n] || 0) + num(r[f])); }); return o; }
  const s = {}, c = {}; rows.forEach(r => { const k = L(r); s[k] = (s[k] || 0) + num(r[spec.value]); c[k] = (c[k] || 0) + 1; });
  return spec.avg ? Object.fromEntries(Object.keys(s).map(k => [k, Math.round(s[k] / c[k] * 10) / 10])) : s;
}
function chartGrid(specs, rows, data) {
  const g = document.createElement("div"); g.className = "chart-grid";
  specs.forEach(s => {
    try {
      const raw = chartData(s, rows, data);
      const fn = CHARTS[s.type || "donut"];
      if (!fn) { g.appendChild(chartCard(s.title, NO_DATA)); return; }
      g.appendChild(fn(raw || {}, s.title, s));
    } catch (e) {
      console.error("chart failed", s.title, e);
      g.appendChild(chartCard(s.title || "Chart", NO_DATA));
    }
  });
  return g;
}
function downloadCSV(name, cols, rows) {
  const q = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const csv = [cols.map(c => q(c[1])).join(","), ...rows.map(r => cols.map(c => q(r[c[0]])).join(","))].join("\r\n");
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv" })); a.download = (name || "export").replace(/\W+/g, "_") + ".csv"; a.click();
}


/* ---------------- menus + page definitions ---------------- */

/* Clean SVG nav icons (modern look) */
const NAV_ICON = {
  dashboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>',
  students: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  teachers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  parents: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  wardens: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
  classes: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
  attendance: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>',
  exams: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
  fees: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
  timetable: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
  hostel: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  hostelact: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
  notices: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
  complaints: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
  reports: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
  promotion: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
  users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>',
  audit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
  settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>',
  documents: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
  profile: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  subjects: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
  work: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>',
  results: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>',
  materials: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
  outpass: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
  mess: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3zm0 0v7"/></svg>',
  rooms: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  visitors: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>',
  contact: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
};
const DEFAULT_NAV_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/></svg>';

const M = (p, l) => [p, l];
const MENU = {
  admin: [M("dashboard", "📊 Dashboard"), M("students", "🎓 Students"), M("documents", "📄 Documents"), M("teachers", "👩‍🏫 Teachers"), M("parents", "👪 Parents"), M("wardens", "🏠 Wardens"), M("classes", "🏫 Academics"),
    M("attendance", "✅ Attendance"), M("exams", "📝 Examinations"), M("fees", "💰 Fees"), M("timetable", "🗓 Timetable"), M("hostel", "🛏 Hostel"), M("notices", "📢 Notices & Events"), M("complaints", "📮 Complaints"), M("reports", "📈 Reports"),
    M("users", "👥 Users & Access"), M("audit", "📜 Audit Log"), M("settings", "⚙️ Settings")],
  student: [M("dashboard", "📊 Dashboard"), M("documents", "📄 My Documents"), M("attendance", "✅ Attendance"), M("subjects", "📚 Subjects"), M("timetable", "🗓 Timetable"), M("work", "📒 Homework & Assignments"), M("exams", "📝 Exams"), M("results", "🏆 Results"), M("notices", "📢 Notices"), M("materials", "📂 Study Material"), M("outpass", "🛏 Hostel Outpass"), M("mess", "🍽 Mess Menu"), M("complaints", "📮 Complaints"), M("settings", "⚙️ Settings")],
  teacher: [M("dashboard", "📊 Dashboard"), M("students", "🎓 My Classes"), M("attendance", "✅ Attendance"), M("work", "📒 Assignments"), M("exams", "📝 Mark Entry"), M("timetable", "🗓 My Timetable"), M("materials", "📂 Study Material"), M("notices", "📢 Notices"), M("settings", "⚙️ Settings")],
  parent: [M("dashboard", "📊 Dashboard"), M("attendance", "✅ Attendance"), M("results", "🏆 Results"), M("work", "📒 Homework"), M("exams", "📝 Examinations"), M("timetable", "🗓 Timetable"), M("fees", "💰 Fees"), M("mess", "🍽 Mess Menu"), M("notices", "📢 Notices"), M("settings", "⚙️ Settings")],
  warden: [M("dashboard", "📊 Dashboard"), M("rooms", "🛏 Rooms"), M("students", "🎓 Hostel Students"), M("attendance", "✅ Attendance"), M("outpass", "🪪 Outpass"), M("mess", "🍽 Mess Menu"), M("complaints", "📮 Complaints"), M("visitors", "🚪 Visitors"), M("notices", "📢 Notices"), M("settings", "⚙️ Settings")],
};
const sel = (url, label = "name", value = "id") => ({ url, label, value });
const F = (n, l, t = "text", o) => ({ n, l, t, o });
const CL = sel("/admin/classes"), SEC = sel("/admin/sections", "label"), SUB = sel("/admin/subjects", "label");
const stCols = [["admission_no", "Adm No"], ["name", "Name"], ["class", "Class"], ["section", "Sec"], ["mobile", "Mobile"], ["parent", "Parent"], ["hostel", "Hostel"], ["attendance", "Att %"]];
const shared = {
  notices: { title: "Notices", url: "/notifications/notices", cols: [["title", "Title"], ["body", "Details"], ["audience", "For"], ["created_at", "Date"]] },
};
const noticeForm = { title: "New Notice", url: "/notifications/notices", fields: [F("title", "Title"), F("body", "Details", "textarea"), F("audience", "Audience", "select", { list: ["all", "student", "teacher", "parent", "warden"] })] };
const stFields = [F("name", "Full name"), F("mobile", "Mobile (10 digits)"), F("email", "Email (OTP is sent here)"), F("admission_no", "Admission No"), F("roll_no", "Roll No", "number"), F("class_id", "Class", "select", CL), F("section_id", "Section", "select", SEC), F("dob", "Date of birth", "date"), F("gender", "Gender", "select", { list: ["M", "F"] }), F("is_hostel", "Hostel student?", "select", { list: [false, true] }), F("parent_name", "Parent name"), F("parent_mobile", "Parent mobile"), F("address_line1", "Address line 1"), F("address_line2", "Address line 2"), F("city", "City"), F("state", "State"), F("pincode", "Pincode")];
const personFields = [F("name", "Name"), F("mobile", "Mobile (10 digits)"), F("email", "Email (OTP is sent here)")];
const teacherFields = [...personFields, F("employee_no", "Employee No"), F("qualification", "Qualification"), F("experience", "Experience (e.g. 5 years)"), F("class_id", "Assign class (optional)", "select", CL)];
const feeEdit = [F("fee_type", "Type", "select", { list: ["Tuition", "Exam", "Transport", "Hostel", "Other"] }), F("amount", "Amount", "number"), F("due_date", "Due date", "date")];
const noticeFields = [F("title", "Title"), F("body", "Details", "textarea"), F("audience", "Audience", "select", { list: ["all", "student", "teacher", "parent", "warden"] })];
const ownNotices = { ...shared.notices, edit: { title: "Edit Notice", url: "/notifications/notices/", fields: noticeFields }, del: "/notifications/notices/", confirm: "Delete this notice?" };
const workFields = [F("title", "Title"), F("description", "Details", "textarea"), F("due_date", "Due", "date")];
const att = { title: "Attendance (days)", type: "donut", map: { Present: "present", Absent: "absent", Late: "late", Leave: "leave" }, sub: "days" };
const attMonthly = { title: "Monthly attendance %", type: "line", fn: monthly, unit: "%", max: 100 };
const perfSubj = { title: "Average % by subject", type: "hbar", label: "subject", value: "percentage", avg: true, unit: "%", max: 100, color: pctColor };
const gradeDist = { title: "Grade distribution", type: "donut", by: "grade", sub: "results" };
const feeDonut = { title: "Fees paid vs pending", type: "donut", totals: { Paid: "paid", Pending: "pending" }, money: true, sub: "total" };
const payForm = { title: "Record Payment", url: "/fees/payment", fields: [F("fee_id", "Student fee (only unpaid fees are listed)", "select", sel("/admin/fees/pending", "label")), F("amount", "Amount", "number"), F("mode", "Mode", "select", { list: ["Cash", "UPI", "Card", "Cheque"] })] };
const QUICK = [{ l: "➕ Add student", form: { title: "Add Student", url: "/admin/students", fields: stFields } }, { l: "💰 Record payment", form: payForm }, { l: "📢 Send notice", form: noticeForm },
  { l: "✅ Correct attendance", href: "attendance.html" }, { l: "🎓 Promote a class", href: "promotion.html" }, { l: "🛏 Hostel", href: "hostel.html" }];
const RECEIPT = { label: "🧾 Receipt", show: r => r.last_payment_id, run: async r => { await getPdf("/pdf/receipt/" + r.last_payment_id, "receipt_" + r.last_payment_id + ".pdf"); return false; } };
const REPORT = { label: "📄 Report card (PDF)", url: "/pdf/report-card", name: "report_card.pdf" };
const VACATE = { label: "🚪 Vacate", cls: "ghost danger", show: r => r.room && r.room !== "Not allocated", confirm: "Free this student's bed?", run: r => post("/hostel/vacate", { student_id: r.student_id }) };
const decide = d => async r => { const x = prompt(d === "Approved" ? "Note for the student (optional)" : "Reason for rejecting (optional)"); if (x === null) return false; return post("/hostel/outpass/" + r.id + "/decide", { decision: d, remarks: x || null }); };
const OUTPASS_ACTS = [{ label: "✅ Approve", cls: "", show: r => r.status === "Pending", run: decide("Approved") }, { label: "❌ Reject", cls: "ghost danger", show: r => r.status === "Pending", run: decide("Rejected") },
  { label: "↩ Returned", show: r => r.status === "Approved", run: r => post("/hostel/outpass/" + r.id + "/returned", {}) }];
const outpassStaff = { title: "Outpass / leave requests", url: "/hostel/outpass", cols: [["student", "Student"], ["class", "Class"], ["room", "Room"], ["from", "From"], ["to", "To"], ["reason", "Reason"], ["status", "Status"], ["remarks", "Note"]], acts: OUTPASS_ACTS,
  charts: [{ title: "Requests by status", type: "donut", by: "status", sub: "requests" }], form: { title: "New outpass (for a student)", url: "/hostel/outpass", fields: [F("student_id", "Student", "select", sel("/hostel/students", "name", "student_id")), F("from_date", "Leaving on", "date"), F("to_date", "Returning on", "date"), F("reason", "Reason")] } };
const messCfg = edit => ({ title: "Weekly mess menu", url: "/hostel/mess", cols: [["day", "Day"], ["Breakfast", "Breakfast"], ["Lunch", "Lunch"], ["Snacks", "Snacks"], ["Dinner", "Dinner"]],
  ...(edit ? { edit: { title: "Edit this day's menu", url: "/hostel/mess/", clean: true, fields: [F("Breakfast", "Breakfast"), F("Lunch", "Lunch"), F("Snacks", "Snacks"), F("Dinner", "Dinner")] } } : {}) });
const hostelComplaints = { title: "Hostel complaints", url: "/hostel/complaints", cols: [["student", "Student"], ["description", "Complaint"], ["category", "Category (AI)"], ["priority", "Priority (AI)"], ["status", "Status"]], resolve: "/hostel/complaints/",
  charts: [{ title: "By category", type: "donut", by: "category", sub: "complaints" }, { title: "By priority", type: "donut", by: "priority", sub: "complaints" }, { title: "Open vs resolved", type: "donut", by: "status", sub: "complaints" }] };
const hostelVisitors = { title: "Visitors", url: "/hostel/visitors", cols: [["visitor", "Visitor"], ["student", "Student"], ["relation", "Relation"], ["purpose", "Purpose"], ["in_time", "In"], ["out_time", "Out"]], checkout: "/hostel/visitors/",
  charts: [{ title: "Visitors by relation", type: "donut", by: "relation", sub: "visits" }], form: { title: "Log visitor", url: "/hostel/visitors", fields: [F("student_id", "Student", "select", sel("/hostel/students", "name", "student_id")), F("visitor_name", "Visitor name"), F("relation", "Relation"), F("purpose", "Purpose")] } };
const PAGES = {
  admin: {
    dashboard: { custom: "adminDash", title: "Dashboard" },

    documents: { custom: "documents", title: "Documents" },
    students: { title: "Students", url: "/admin/students", cols: stCols, view: r => "student.html?id=" + r.id, del: "/admin/students/", confirm: "Deactivate this student? Their attendance, marks and fees history is kept.",
      charts: [{ title: "Students per class", type: "bar", by: "class", single: true }, { title: "Hostel vs day scholars", type: "donut", by: "hostel", sub: "students" }, { title: "Attendance of students", type: "donut", fn: attBuckets, sub: "students" }],
      form: { title: "Add Student", url: "/admin/students", fields: stFields }, edit: { title: "Edit Student", url: "/admin/students/", detail: true, fields: stFields },
      exportUrl: "/admin/students/export-csv", exportName: "students_export.csv",
      importUrl: "/admin/students/import-csv", importTemplate: "/admin/students/import-template" },
    teachers: { title: "Teachers", url: "/admin/teachers", cols: [["name", "Name"], ["mobile", "Mobile"], ["email", "Email"], ["employee_no", "Emp No"], ["qualification", "Qualification"], ["experience", "Experience"], ["class", "Class"], ["subjects", "Subjects"]], del: "/admin/teachers/", confirm: "Deactivate this teacher?",
      acts: [{ label: "View", cls: "ghost", run: r => {
        const photo = r.photo ? (API + "/files/" + r.photo) : null;
        const { body } = openPersonDrawer(r.name, {
          name: r.name, role: "Teacher", photo,
          "Employee no": r.employee_no, Mobile: r.mobile, Email: r.email,
          Qualification: r.qualification, Experience: r.experience, Class: r.class, Subjects: r.subjects
        });
        const up = document.createElement("button"); up.className = "btn sm"; up.textContent = "Upload photo";
        up.style.marginTop = "12px";
        up.onclick = () => {
          const inp = document.createElement("input"); inp.type = "file"; inp.accept = "image/*";
          inp.onchange = async () => {
            if (!inp.files[0]) return;
            const fd = new FormData(); fd.append("file", inp.files[0]);
            try { toast((await api("/admin/teachers/" + r.id + "/photo", { method: "POST", body: fd })).message); render(); }
            catch (e) { toast(e.message, false); }
          };
          inp.click();
        };
        body.appendChild(up);
        return false;
      } }],
      form: { title: "Add Teacher", url: "/admin/teachers", fields: teacherFields }, edit: { title: "Edit Teacher", url: "/admin/teachers/", fields: teacherFields } },
    parents: { title: "Parents", url: "/admin/parents", cols: [["name", "Name"], ["mobile", "Mobile"], ["email", "Email"], ["children", "Children"]], del: "/admin/parents/", confirm: "Deactivate this parent?",
      edit: { title: "Edit Parent", url: "/admin/parents/", fields: personFields },
      acts: [{ label: "View", cls: "ghost", run: r => {
        const extra = `<div style="margin-top:16px"><b>Linked students</b><p class="lbl" style="margin:6px 0 8px">${esc(r.children || "None linked")}</p>
          <button type="button" class="btn sm" data-kids>Open student list</button></div>`;
        const { body } = openPersonDrawer(r.name, { name: r.name, role: "Parent", Mobile: r.mobile, Email: r.email, Children: r.children });
        const btn = body.querySelector("[data-kids]");
        if (btn) btn.onclick = () => location.href = "students.html";
        return false;
      } }] },
    wardens: { title: "Hostel Wardens", url: "/admin/wardens", cols: [["name", "Name"], ["mobile", "Mobile"], ["email", "Email"]], del: "/admin/wardens/", confirm: "Deactivate this warden?",
      form: { title: "Add Warden", url: "/admin/wardens", fields: personFields }, edit: { title: "Edit Warden", url: "/admin/wardens/", fields: personFields },
      acts: [{ label: "View", cls: "ghost", run: r => { openPersonDrawer(r.name, { name: r.name, role: "Hostel Warden", Mobile: r.mobile, Email: r.email }); return false; } }] },
    classes: { custom: "academicsAdmin", title: "Academics" },
    attendance: { sections: [
      { title: "Today by class", url: "/attendance/summary", cols: [["class", "Class"], ["section", "Sec"], ["students", "Students"], ["present", "Present"], ["absent", "Absent"], ["late", "Late"], ["leave", "Leave"]],
        cards: [["students", "Students"], ["present", "Present"], ["absent", "Absent"], ["late", "Late"], ["leave", "Leave"]],
        charts: [{ title: "Whole school today", type: "donut", totals: { Present: "present", Absent: "absent", Late: "late", Leave: "leave" }, sub: "marked" }] },
      { custom: "correct" }
    ] },
    exams: { custom: "examsAdmin", title: "Examinations" },
    fees: { custom: "feesAdmin", title: "Fees" },
    timetable: { custom: "timetable", title: "Timetable" },
    notices: { custom: "noticesAdmin", title: "Notices" },
    student: { custom: "studentprofile", title: "👤 Student Profile", parent: "students" },
    hostel: { custom: "hostelAdmin", title: "Hostel" },
    hostelact: { sections: [outpassStaff, hostelComplaints, hostelVisitors,
      { title: "Hostel attendance (today)", url: "/hostel/attendance", cols: [["name", "Student"], ["status", "Status"]], charts: [{ title: "Today", type: "donut", by: "status", sub: "students" }] }] },
    promotion: { custom: "promotion", title: "🎓 Year-end Promotion" },
    users: { custom: "usersAccess", title: "Users & Access" },
    audit: { title: "Audit Log - who changed what (last 30 days)", url: "/admin/audit", cols: [["time", "Time (IST)"], ["user", "User"], ["role", "Role"], ["action", "What happened"], ["ip", "IP"]],
      charts: [{ title: "Changes by user", type: "hbar", by: "user", single: true }, { title: "Changes by role", type: "donut", by: "role", sub: "changes" }, { title: "Changes per day", type: "bar", fn: rows => { const o = {}; [...rows].reverse().forEach(r => o[r.day] = (o[r.day] || 0) + 1); return o; }, single: true }] },
    settings: { custom: "settings", title: "⚙️ Settings" },
    complaints: { title: "Complaints", url: "/admin/complaints", cols: [["from", "From"], ["role", "Role"], ["subject", "Subject"], ["description", "Details"], ["status", "Status"]], resolve: "/admin/complaints/",
      charts: [{ title: "Open vs resolved", type: "donut", by: "status", sub: "complaints" }, { title: "Complaints by role", type: "donut", by: "role", sub: "complaints" }] },
    reports: { sections: [
      { title: "Low Attendance Students", url: "/admin/reports/low-attendance", cols: [["name", "Name"], ["class", "Class"], ["section", "Sec"], ["attendance", "Att %"]], charts: [{ title: "Attendance % of students below the limit", type: "hbar", label: "name", value: "attendance", unit: "%", max: 100, color: pctColor }] },
      { title: "Class Result Report", url: "/admin/reports/class-result?class_id=1", cols: [["name", "Student"], ["exams", "Exams"], ["average", "Average %"], ["grade", "Grade"], ["result", "Result"]], filter: { param: "class_id", list: CL },
        charts: [{ title: "Pass vs fail", type: "donut", by: "result", sub: "students" }, gradeDist, { title: "Average % per student", type: "hbar", label: "name", value: "average", unit: "%", max: 100, color: pctColor, limit: 15 }] },
      { title: "Subject Performance", url: "/admin/reports/subject-performance?class_id=1", cols: [["subject", "Subject"], ["average", "Average %"], ["entries", "Entries"]], filter: { param: "class_id", list: CL },
        charts: [{ title: "Average % by subject", type: "bar", label: "subject", value: "average", unit: "%", max: 100, color: pctColor }] },
      { title: "Fee Collection Report", url: "/fees/report", cols: [["student", "Student"], ["class", "Class"], ["fee_type", "Type"], ["total", "Total"], ["paid", "Paid"], ["pending", "Pending"]],
        charts: [{ title: "Collected vs pending (₹)", type: "donut", totals: { Collected: "paid", Pending: "pending" }, money: true, sub: "total fees" }, { title: "Pending ₹ by class", type: "bar", label: "class", value: "pending", single: true }, { title: "Collected vs pending by type", type: "group", label: "fee_type", series: [["paid", "Collected"], ["pending", "Pending"]] }] },
      { title: "Today's Attendance by Class", url: "/attendance/summary", cols: [["class", "Class"], ["section", "Sec"], ["students", "Students"], ["present", "Present"], ["absent", "Absent"]],
        charts: [{ title: "Present vs absent by class", type: "group", label: r => r.class + (r.section && r.section !== "-" ? "-" + r.section : ""), series: [["present", "Present"], ["absent", "Absent"]] }] }] },
  },
  student: {
    work: { sections: [
      { title: "Homework", url: "/students/me/homework", cols: [["subject", "Subject"], ["title", "Title"], ["description", "Details"], ["due_date", "Due"]] },
      { title: "Assignments", url: "/students/me/assignments", cols: [["subject", "Subject"], ["title", "Title"], ["due_date", "Due"], ["status", "Status"], ["marks", "Marks"]] }
    ] },
    documents: { title: "My Documents", url: "/students/me/documents", cols: [["doc_type", "Type"], ["title", "Title"], ["status", "Status"], ["remarks", "Remarks"], ["uploaded_at", "Uploaded"]],
      charts: [{ title: "By status", type: "donut", by: "status", sub: "documents" }],
      form: { title: "Upload Document", url: "/students/me/documents", multipart: true, fields: [
        F("doc_type", "Type", "select", { list: ["photo", "aadhaar", "birth_cert", "marksheet", "tc", "other"] }),
        F("title", "Title"),
        F("file", "File", "file", { accept: ".pdf,.jpg,.jpeg,.png,.webp" }),
      ] } },
    dashboard: { custom: "studentDash" },
    settings: { custom: "portalSettings" },
    profile: { title: "My Profile", url: "/students/me/profile", kv: true },
    attendance: { title: "My Attendance", url: "/students/me/attendance", pick: "records", cards: [["percentage", "Attendance rate"], ["present", "Present days"], ["absent", "Absent days"], ["late", "Late days"], ["leave", "Leave days"]], charts: [{ title: "Monthly attendance %", type: "bar", key: "attendance_monthly", unit: "%", max: 100, single: true }] },
    subjects: { title: "My Subjects", url: "/students/me/subjects", cols: [["subject", "Subject"]] },
    timetable: { title: "My Timetable", url: "/students/me/timetable", cols: [["day", "Day"], ["time", "Time"], ["subject", "Subject"], ["teacher", "Teacher"], ["room", "Room"]], grid: true },
    homework: { title: "Homework", url: "/students/me/homework", cols: [["subject", "Subject"], ["title", "Title"], ["description", "Details"], ["due_date", "Due"]] },
    assignments: { title: "Assignments", url: "/students/me/assignments", cols: [["subject", "Subject"], ["title", "Title"], ["due_date", "Due"], ["status", "Status"], ["marks", "Marks"], ["feedback", "Feedback"]], upload: r => "/students/me/assignments/" + r.id + "/submit", charts: [{ title: "Submitted vs pending", type: "donut", by: "status", sub: "assignments" }] },
    exams: { title: "Exam Schedule", url: "/students/me/exams", cols: [["name", "Exam"], ["subject", "Subject"], ["exam_date", "Date"], ["max_marks", "Max"]] },
    results: { custom: "studentResults" },
    fees: { title: "My Fees", url: "/students/me/fees", cols: [["fee_type", "Type"], ["amount", "Total"], ["paid", "Paid"], ["pending", "Pending"], ["due_date", "Due"], ["history", "Payment history"]] },
    notices: { custom: "portalNotices" },
    outpass: { title: "My hostel outpass requests", url: "/hostel/outpass", cols: [["from", "From"], ["to", "To"], ["reason", "Reason"], ["status", "Status"], ["remarks", "Warden's note"]], charts: [{ title: "My requests", type: "donut", by: "status", sub: "requests" }],
      form: { title: "Request outpass", url: "/hostel/outpass", fields: [F("from_date", "Leaving on", "date"), F("to_date", "Returning on", "date"), F("reason", "Reason")] } },
    mess: { custom: "messView" },
    materials: { title: "Study Material", url: "/students/me/materials", cols: [["subject", "Subject"], ["title", "Title"]], download: r => r.file },
    complaints: { title: "My Complaints", url: "/students/me/complaints", cols: [["subject", "Subject"], ["description", "Details"], ["status", "Status"]], form: { title: "New Complaint", url: "/students/me/complaints", fields: [F("subject", "Subject"), F("description", "Details", "textarea")] } },
  },
  teacher: {
    work: { custom: "teacherWork" },
    dashboard: { custom: "teacherDash" },
    settings: { custom: "portalSettings" },
    attendance: { custom: "teacherAtt" },
    students: { title: "Students", url: "/teachers/students", cols: [["roll_no", "Roll"], ["name", "Name"], ["class", "Class"], ["section", "Sec"], ["attendance", "Att %"]],
      charts: [{ title: "Attendance of my students", type: "donut", fn: attBuckets, sub: "students" }, { title: "Lowest attendance %", type: "hbar", fn: rows => Object.fromEntries([...rows].sort((a, b) => a.attendance - b.attendance).slice(0, 8).map(r => [r.name, r.attendance])), unit: "%", max: 100, color: pctColor }] },
    homework: { title: "Homework", url: "/homework", cols: [["subject", "Subject"], ["title", "Title"], ["description", "Details"], ["due_date", "Due"]], edit: { title: "Edit Homework", url: "/homework/", fields: workFields }, del: "/homework/", confirm: "Delete this homework?",
      form: { title: "Give Homework", url: "/homework", fields: [F("class_id", "Class", "select", sel("/teachers/subjects", "label", "class_id")), F("subject_id", "Subject", "select", sel("/teachers/subjects", "label")), F("title", "Title"), F("description", "Details", "textarea"), F("due_date", "Due", "date")] } },
    assignments: { title: "Assignments", url: "/assignments", cols: [["subject", "Subject"], ["title", "Title"], ["due_date", "Due"], ["max_marks", "Max"], ["submissions", "Submissions"]], charts: [{ title: "Submissions per assignment", type: "bar", label: "title", value: "submissions", single: true }],
      form: { title: "Create Assignment", url: "/assignments", fields: [F("class_id", "Class", "select", sel("/teachers/subjects", "label", "class_id")), F("subject_id", "Subject", "select", sel("/teachers/subjects", "label")), F("title", "Title"), F("description", "Details", "textarea"), F("due_date", "Due", "date"), F("max_marks", "Max marks", "number")] },
      edit: { title: "Edit Assignment", url: "/assignments/", fields: [...workFields, F("max_marks", "Max marks", "number")] }, del: "/assignments/", confirm: "Delete this assignment? (blocked once students submitted)", rowBtn: ["Review", "review"] },
    exams: { custom: "teacherMarks" },
    timetable: { custom: "timetable", title: "Timetable" },
    materials: { title: "Study Material", url: "/homework", cols: [], upload_form: true },
    notices: { sections: [{ ...ownNotices, form: noticeForm }] },
  },
  parent: {
    work: { sections: [
      { title: "Homework", url: "/parents/child/homework", cols: [["subject", "Subject"], ["title", "Title"], ["due_date", "Due"]] },
      { title: "Assignments", url: "/parents/child/assignments", cols: [["subject", "Subject"], ["title", "Title"], ["due_date", "Due"], ["status", "Status"], ["marks", "Marks"]] }
    ] },
    dashboard: { custom: "parentDash" },
    settings: { custom: "portalSettings" },
    attendance: { title: "Child's Attendance", url: "/parents/child/attendance", pick: "records", cards: [["percentage", "Attendance %"], ["present", "Present"], ["absent", "Absent"]], cols: [["date", "Date"], ["status", "Status"]], charts: [att, attMonthly] },
    results: { title: "Results", url: "/parents/child/results", pdfs: [REPORT], cols: [["exam", "Exam"], ["subject", "Subject"], ["total", "Total"], ["percentage", "%"], ["grade", "Grade"], ["result", "Result"]], charts: [perfSubj, gradeDist] },
    homework: { title: "Homework", url: "/parents/child/homework", cols: [["subject", "Subject"], ["title", "Title"], ["due_date", "Due"]] },
    assignments: { title: "Assignments", url: "/parents/child/assignments", cols: [["subject", "Subject"], ["title", "Title"], ["due_date", "Due"], ["status", "Status"], ["marks", "Marks"]], charts: [{ title: "Submitted vs pending", type: "donut", by: "status", sub: "assignments" }] },
    exams: { title: "Exam Schedule", url: "/parents/child/exams", cols: [["name", "Exam"], ["subject", "Subject"], ["exam_date", "Date"]] },
    timetable: { title: "Timetable", url: "/parents/child/timetable", cols: [["day", "Day"], ["time", "Time"], ["subject", "Subject"], ["teacher", "Teacher"]], grid: true },
    fees: { sections: [
      { title: "Fee Heads (custom types)", url: "/fees/heads", cols: [["name", "Head"], ["default_amount", "Default ₹"]],
        form: { title: "Add Fee Head", url: "/fees/heads", fields: [F("name", "Head name"), F("default_amount", "Default amount", "number")] } },
      { title: "Fee records", url: "/fees", cols: [["student", "Student"], ["class", "Class"], ["fee_type", "Type"], ["amount", "Amount"], ["paid", "Paid"], ["pending", "Pending"], ["due_date", "Due"]],
        form: { title: "Assign Fee", url: "/fees", fields: [F("class_id", "Class (all students)", "select", CL), F("student_id", "Or one student", "select", sel("/admin/students")), F("fee_type", "Fee head", "select", sel("/fees/heads", "name", "name")), F("amount", "Amount", "number"), F("due_date", "Due", "date")] } },
    ], _fees_legacy: true,  title: "Fees", url: "/parents/child/fees", acts: [RECEIPT], cols: [["fee_type", "Type"], ["amount", "Total"], ["paid", "Paid"], ["pending", "Pending"], ["due_date", "Due"], ["history", "History"]], charts: [feeDonut] },
    notices: { custom: "portalNotices" },
    mess: { custom: "messView" },
    contact: { sections: [{ title: "Message teachers", url: null, form: { title: "Message Teachers", url: "/parents/message-teacher", fields: [F("subject", "Subject"), F("description", "Message", "textarea")] } }, { title: "Submit concern to school", url: null, form: { title: "Submit Concern", url: "/parents/concerns", fields: [F("subject", "Subject"), F("description", "Details", "textarea")] } }] },
  },
  warden: {
    dashboard: { custom: "wardenDash" },
    settings: { custom: "portalSettings" },
    rooms: { custom: "wardenRooms" },
    students: { title: "Hostel Students", url: "/hostel/students", acts: [VACATE], cols: [["name", "Name"], ["class", "Class"], ["mobile", "Mobile"], ["room", "Room"]], charts: [{ title: "Hostel students per class", type: "bar", by: "class", single: true }] },
    attendance: { custom: "hostelmark" },
    complaints: { title: "Complaints", url: "/hostel/complaints", cols: [["student", "Student"], ["description", "Complaint"], ["category", "Category (AI)"], ["priority", "Priority (AI)"], ["status", "Status"]], resolve: "/hostel/complaints/",
      charts: [{ title: "By category", type: "donut", by: "category", sub: "complaints" }, { title: "By priority", type: "donut", by: "priority", sub: "complaints" }, { title: "Open vs resolved", type: "donut", by: "status", sub: "complaints" }],
      form: { title: "Log Complaint", url: "/hostel/complaints", fields: [F("description", "Complaint", "textarea")] } },
    outpass: outpassStaff,
    mess: { custom: "messGrid" },
    visitors: { title: "Visitors", url: "/hostel/visitors", cols: [["visitor", "Visitor"], ["student", "Student"], ["relation", "Relation"], ["purpose", "Purpose"], ["in_time", "In"], ["out_time", "Out"]], checkout: "/hostel/visitors/",
      charts: [{ title: "Visitors by relation", type: "donut", by: "relation", sub: "visits" }],
      form: { title: "Log Visitor", url: "/hostel/visitors", fields: [F("student_id", "Student", "select", sel("/hostel/students", "name", "student_id")), F("visitor_name", "Visitor name"), F("relation", "Relation"), F("purpose", "Purpose")] } },
    notices: { custom: "portalNotices" },
  },
};

/* ---------------- rendering ---------------- */
const badge = v => ["Present", "Absent", "Late", "Leave", "Pass", "Fail", "Submitted", "Pending", "High", "Medium", "Low", "Open", "Resolved", "Approved", "Rejected", "Returned", "Active", "Inactive"].includes(v) ? `<span class="badge b-${v}">${v}</span>` : esc(v);
function table(rows, cols, opts = {}) {
  const S = opts.state || {}; S.flt = S.flt || {};                       // remembered between reloads (after an Edit / Delete the view stays put)
  let page = S.page || 0, q = S.q ?? (opts.noq ? "" : URLQ).toLowerCase(), sk = S.sk || null, dir = S.dir || 1; const per = opts.per || 10, flt = S.flt;
  const wrap = document.createElement("div");
  const uniq = c => [...new Set(rows.map(r => String(r[c[0]] ?? "-")))].sort((x, y) => x.localeCompare(y, undefined, { numeric: true }));
  // automatic dropdown filters for columns that repeat a few values (class, status, type ...)
  const fcols = rows.length >= 5 ? cols.filter(c => !/(^id$|_id$|date|time|mobile|email|description|history|reason|detail|remark|created|requested|payments|occupants)/i.test(c[0]) && uniq(c).length >= 2 && uniq(c).length <= 10 && uniq(c).length < rows.length * 0.7) : [];
  wrap.innerHTML = `<div class="tools"><input placeholder="Search…" data-q>${fcols.map(c => `<select data-f="${c[0]}" style="max-width:170px"><option value="">All ${esc(c[1])}</option>${uniq(c).map(v => `<option>${esc(v)}</option>`).join("")}</select>`).join("")}<button class="btn ghost sm" data-clr style="display:none">✕ Clear</button></div><div class="tw"><table><thead><tr>${cols.map(c => `<th class="sortable" data-k="${c[0]}">${c[1]}<i></i></th>`).join("")}${opts.extra ? "<th></th>" : ""}</tr></thead><tbody></tbody></table></div><div class="pager"></div>`;
  const qi = wrap.querySelector("[data-q]"); qi.value = q; if (rows.length <= 5 && !q && !opts.tools) wrap.querySelector(".tools").style.display = "none";   // tiny table: no search bar needed
  wrap.querySelectorAll("select[data-f]").forEach(el => { el.value = flt[el.dataset.f] || ""; flt[el.dataset.f] = el.value; });
  const num = v => parseFloat(String(v).replace(/[₹,%\s]/g, ""));
  const draw = () => {
    let f = rows.filter(r => (!q || cols.some(c => String(r[c[0]] ?? "").toLowerCase().includes(q))) && Object.entries(flt).every(([k, v]) => !v || String(r[k] ?? "-") === v));
    if (sk) { const numeric = f.every(r => r[sk] == null || r[sk] === "-" || r[sk] === "" || !isNaN(num(r[sk])));
      f = [...f].sort((x, y) => numeric ? ((num(x[sk]) || 0) - (num(y[sk]) || 0)) * dir : String(x[sk] ?? "").localeCompare(String(y[sk] ?? ""), undefined, { numeric: true }) * dir); }
    const pages = Math.max(1, Math.ceil(f.length / per)); page = Math.min(page, pages - 1); S.q = q; S.sk = sk; S.dir = dir; S.page = page;
    wrap.querySelector("tbody").innerHTML = f.slice(page * per, page * per + per).map((r, i) => `<tr>${cols.map(c => `<td>${badge(r[c[0]] ?? "-")}</td>`).join("")}${opts.extra ? `<td data-i="${i}"></td>` : ""}</tr>`).join("") || `<tr><td colspan="${cols.length + 1}" style="color:var(--muted)">No records</td></tr>`;
    if (opts.extra) wrap.querySelectorAll("td[data-i]").forEach(td => opts.extra(f[page * per + +td.dataset.i], td));
    wrap.querySelectorAll("th.sortable").forEach(th => th.dataset.dir = th.dataset.k === sk ? dir : "");
    wrap.querySelector("[data-clr]").style.display = q || sk || Object.values(flt).some(Boolean) ? "" : "none";
    wrap.querySelector(".pager").innerHTML = pages > 1 ? `<span>${f.length} records</span><button class="btn ghost sm" ${page ? "" : "disabled"}>Prev</button><span>${page + 1}/${pages}</span><button class="btn ghost sm" ${page < pages - 1 ? "" : "disabled"}>Next</button>` : `<span>${f.length} record${f.length === 1 ? "" : "s"}</span>`;
    const [b1, b2] = wrap.querySelectorAll(".pager button"); if (b1) { b1.onclick = () => { page--; draw(); }; b2.onclick = () => { page++; draw(); }; }
  };
  qi.oninput = e => { q = e.target.value.toLowerCase(); page = 0; draw(); };
  wrap.querySelectorAll("select[data-f]").forEach(el => el.onchange = () => { flt[el.dataset.f] = el.value; page = 0; draw(); });
  wrap.querySelectorAll("th.sortable").forEach(th => th.onclick = () => { if (sk === th.dataset.k) dir = -dir; else { sk = th.dataset.k; dir = 1; } draw(); });
  wrap.querySelector("[data-clr]").onclick = () => { q = ""; qi.value = ""; sk = null; dir = 1; Object.keys(flt).forEach(k => flt[k] = ""); wrap.querySelectorAll("select[data-f]").forEach(el => el.value = ""); draw(); };
  draw(); return wrap;
}
function statCards(data, cards) { const d = document.createElement("div"); d.className = "cards"; d.innerHTML = cards.map(([k, l]) => `<div class="card"><div class="stat ${String(typeof data[k] === "number" ? data[k].toLocaleString("en-IN") : data[k] ?? 0).length > 9 ? "sm" : ""}">${typeof data[k] === "number" ? data[k].toLocaleString("en-IN", { maximumFractionDigits: 2 }) : esc(data[k] ?? 0)}</div><div class="lbl">${l}</div></div>`).join(""); return d; }
function modal(title, fields, onSubmit, values, extra) {
  const edit = !!values;
  document.querySelectorAll(".drawer-root").forEach(el => el.remove());
  const m = document.createElement("div");
  m.className = "drawer-root on";
  m.innerHTML = `<div class="drawer-backdrop" data-c></div>
    <aside class="drawer-panel" role="dialog" aria-modal="true">
      <div class="drawer-head">
        <div>
          <h3>${esc(title)}</h3>
          <p class="lbl" style="margin:4px 0 0">${edit ? "Update the fields below and save." : "Fill in the details and save."}</p>
        </div>
        <button type="button" class="btn ghost sm" data-c title="Close">✕</button>
      </div>
      <div class="drawer-body" data-f></div>
      <div class="drawer-foot">
        <button type="button" class="btn ghost danger" data-extra style="display:none"></button>
        <div style="flex:1"></div>
        <button type="button" class="btn ghost" data-c>Cancel</button>
        <button type="button" class="btn" data-s>${edit ? "Save changes" : "Save"}</button>
      </div>
    </aside>`;
  document.body.appendChild(m);
  document.body.classList.add("drawer-open");
  const box = m.querySelector("[data-f]");
  const close = () => { m.remove(); document.body.classList.remove("drawer-open"); };
  fields.forEach(async f => {
    const w = document.createElement("div"); w.className = "drawer-field";
    w.innerHTML = `<label>${f.l}</label>`; let el;
    if (f.t === "select") el = document.createElement("select");
    else if (f.t === "textarea") { el = document.createElement("textarea"); el.rows = 4; }
    else if (f.t === "file") { el = document.createElement("input"); el.type = "file"; if (f.o?.accept) el.accept = f.o.accept; }
    else { el = document.createElement("input"); el.type = f.t || "text"; }
    el.name = f.n; w.appendChild(el); box.appendChild(w);
    if (f.t === "select") {
      el.innerHTML = `<option value="">-- select --</option>`;
      if (f.o && f.o.list) f.o.list.forEach(v => el.add(new Option(String(v), v)));
      else if (f.o && f.o.url) try { (await api(f.o.url)).forEach(x => el.add(new Option(x[f.o.label], x[f.o.value]))); } catch (e) { }
    }
    if (edit && values[f.n] != null && f.t !== "file") el.value = String(values[f.n]);
  });
  m.querySelectorAll("[data-c]").forEach(b => b.onclick = close);
  if (extra && extra.label && extra.onClick) {
    const xb = m.querySelector("[data-extra]");
    xb.style.display = ""; xb.textContent = extra.label; xb.onclick = () => extra.onClick(close);
  }
  m.querySelector("[data-s]").onclick = async () => {
    const hasFile = [...box.querySelectorAll("input[type=file]")].some(e => e.files && e.files[0]);
    try {
      let r;
      if (hasFile) {
        const fd = new FormData();
        box.querySelectorAll("[name]").forEach(e => {
          if (e.type === "file") { if (e.files[0]) fd.append(e.name, e.files[0]); }
          else if (e.value !== "") fd.append(e.name, e.value);
        });
        r = await onSubmit(fd);
      } else {
        const body = {};
        box.querySelectorAll("[name]").forEach(e => {
          let v = e.value; if (v === "") { if (edit) body[e.name] = null; return; }
          if (e.type === "number" || (e.tagName === "SELECT" && /_id$/.test(e.name))) v = Number(v);
          if (v === "true") v = true; if (v === "false") v = false; body[e.name] = v;
        });
        r = await onSubmit(body);
      }
      toast(r?.message || "Saved"); close(); render();
    } catch (e) { toast(e.message, false); }
  };
  // focus first input
  setTimeout(() => box.querySelector("input,select,textarea")?.focus(), 80);
}

async function editRow(cfg, r) {
  const e = cfg.edit; let cur = r;
  if (e.detail) { try { cur = await api(e.url + r.id); } catch (x) { return toast(x.message, false); } }
  if (e.clean) cur = Object.fromEntries(Object.entries(cur).map(([k, v]) => [k, v === "-" ? "" : v]));
  modal(e.title || "Edit", e.fields, body => put(e.url + r.id, body), cur);
}
async function section(cfg, host) {
  const wrap = document.createElement("div"); wrap.className = "section-wrap"; host.appendChild(wrap);
  const statsSlot = document.createElement("div"); statsSlot.className = "stats-slot"; wrap.appendChild(statsSlot);
  const chartsSlot = document.createElement("div"); chartsSlot.className = "charts-slot"; wrap.appendChild(chartsSlot);
  const gridSlot = document.createElement("div"); gridSlot.className = "grid-slot"; wrap.appendChild(gridSlot);
  const card = document.createElement("div"); card.className = "card table-card"; wrap.appendChild(card);
  const head = document.createElement("div"); head.className = "tools"; head.innerHTML = `<b style="flex:1;align-self:center">${cfg.title || ""}</b>`; card.appendChild(head);
  [cfg.form, ...(cfg.forms || []), ...(cfg.forms2 || [])].filter(Boolean).forEach(f => { const b = document.createElement("button"); b.className = "btn"; b.textContent = "+ " + f.title; b.onclick = () => modal(f.title, f.fields, body => {
      if (body instanceof FormData) return api(f.url, { method: "POST", body });
      return post(f.url, body);
    }); head.appendChild(b); });
  (cfg.actions || []).forEach(([l, u]) => { const b = document.createElement("button"); b.className = "btn ghost"; b.textContent = l; b.onclick = async () => { try { toast((await post(u, {})).message); } catch (e) { toast(e.message, false); } }; head.appendChild(b); });
  (cfg.pdfs || []).forEach(x => { const b = document.createElement("button"); b.className = "btn ghost"; b.textContent = x.label; b.onclick = () => getPdf(x.url, x.name); head.appendChild(b); });
  let lastRows = [];
  if (cfg.cols && cfg.url) { const b = document.createElement("button"); b.className = "btn ghost"; b.textContent = "⬇ Export CSV"; b.title = "Download this table as a spreadsheet file"; b.onclick = () => downloadCSV(cfg.title, cfg.cols, lastRows); head.appendChild(b); }
  if (cfg.exportUrl) {
    const b = document.createElement("button"); b.className = "btn ghost"; b.textContent = "⬇ Full export";
    b.onclick = () => getPdf(cfg.exportUrl, cfg.exportName || "export.csv").catch(() => downloadAuthFile(cfg.exportUrl, cfg.exportName || "export.csv"));
    head.appendChild(b);
  }
  if (cfg.importUrl) {
    const b = document.createElement("button"); b.className = "btn ghost"; b.textContent = "⬆ Import CSV";
    const fi = document.createElement("input"); fi.type = "file"; fi.accept = ".csv,text/csv"; fi.style.display = "none";
    b.onclick = () => fi.click();
    fi.onchange = async () => {
      if (!fi.files[0]) return;
      const fd = new FormData(); fd.append("file", fi.files[0]);
      try {
        const r = await api(cfg.importUrl, { method: "POST", body: fd });
        toast(r.message || "Import done");
        if (typeof load === "function") load();
        else location.reload();
      } catch (e) { toast(e.message, false); }
      fi.value = "";
    };
    head.appendChild(b); head.appendChild(fi);
    if (cfg.importTemplate) {
      const tbtn = document.createElement("button"); tbtn.className = "btn ghost"; tbtn.textContent = "📄 Template";
      tbtn.onclick = () => downloadAuthFile(cfg.importTemplate, "import_template.csv");
      head.appendChild(tbtn);
    }
  }
  if (cfg.filter) { const s = document.createElement("select"); s.style.maxWidth = "180px"; head.appendChild(s);
    const items = await api(cfg.filter.list.url); items.forEach(x => s.add(new Option(x[cfg.filter.list.label], x[cfg.filter.list.value])));
    const first = items.find(x => x.students > 0) || items[0]; if (first) s.value = first[cfg.filter.list.value];   // default to a class that has data
    const setUrl = () => { cfg.url = cfg.url.replace(/=\d*/, "=" + s.value); }; setUrl();   // use the FIRST real class (was hard-coded to class_id=1)
    s.onchange = () => { setUrl(); load(); }; }
  const body = document.createElement("div"); card.appendChild(body); const tstate = {};
  const hasAct = cfg.edit || cfg.del || cfg.resolve || cfg.upload || cfg.download || cfg.rowBtn || cfg.acts || cfg.view || cfg.checkout;
  async function load() {
    if (!cfg.url) return; body.innerHTML = '<div class="spin"></div>';
    try {
      const data = await api(cfg.url); body.innerHTML = "";
      if (cfg.kv) { body.innerHTML = Object.entries(data).map(([k, v]) => `<div class="bar"><b style="width:140px">${esc(k)}</b><span>${esc(v)}</span></div>`).join(""); return; }
      statsSlot.innerHTML = ""; chartsSlot.innerHTML = ""; gridSlot.innerHTML = "";
      if (cfg.cards) statsSlot.appendChild(statCards(data, cfg.cards));
      const rows = cfg.pick ? data[cfg.pick] : data; lastRows = Array.isArray(rows) ? rows : [];
      if (cfg.cols && !lastRows.length) {
        body.innerHTML = '<div class="empty"><div style="font-size:28px;margin-bottom:8px">📭</div><b>No records yet</b><p class="lbl" style="margin:6px 0 0">Use the buttons above to add the first item, or check filters.</p></div>';
      }
      if (cfg.grid && lastRows.length) { const g = document.createElement("div"); g.innerHTML = renderTimetableGrid(lastRows); gridSlot.appendChild(g); }
      if (cfg.charts && lastRows.length) chartsSlot.appendChild(chartGrid(cfg.charts, lastRows, data));
      else if (cfg.charts && !lastRows.length) chartsSlot.innerHTML = '';
      if (cfg.cols && lastRows.length) body.appendChild(table(rows, cfg.cols, hasAct ? { state: tstate, extra: (r, td) => {
        td.style.whiteSpace = "nowrap";
        const add = (label, cls, fn) => { const b = document.createElement("button"); b.className = "btn sm " + cls; b.textContent = label; b.style.marginRight = "4px"; b.onclick = fn; td.appendChild(b); };
        const mine = r.mine !== false;     // notices: only the author (or admin) may change them
        if (cfg.view) add("👁 View", "ghost", () => { location.href = cfg.view(r); });
        (cfg.acts || []).forEach(a => { if (a.show && !a.show(r)) return; add(a.label, a.cls || "ghost", async () => { if (a.confirm && !confirm(a.confirm)) return; try { const res = await a.run(r); if (res !== false) { toast(res?.message || "Done"); load(); } } catch (e) { toast(e.message, false); } }); });
        if (cfg.edit && mine) add("✏️ Edit", "ghost", () => editRow(cfg, r));
        if (cfg.del && mine) add("🗑 Delete", "ghost danger", async () => { if (!confirm(cfg.confirm || "Delete this record? This cannot be undone.")) return; try { toast((await api(cfg.del + r.id, { method: "DELETE" })).message || "Deleted"); load(); } catch (e) { toast(e.message, false); } });
        if (cfg.resolve && r.status !== "Resolved") add("Resolve", "", async () => { await post(cfg.resolve + r.id + "/resolve", {}); toast("Resolved"); load(); });
        if (cfg.checkout && r.out_time === "Inside") add("Check out", "", async () => { try { toast((await post(cfg.checkout + r.id + "/checkout", {})).message); load(); } catch (e) { toast(e.message, false); } });
        if (cfg.upload) add("Upload", "", () => { const i = document.createElement("input"); i.type = "file"; i.onchange = async () => { const fd = new FormData(); fd.append("file", i.files[0]); try { toast((await api(cfg.upload(r), { method: "POST", body: fd })).message); load(); } catch (e) { toast(e.message, false); } }; i.click(); });
        if (cfg.download) add("Download", "", async () => { const res = await fetch(API + "/files/" + cfg.download(r), { headers: { Authorization: "Bearer " + localStorage.erp_token } }); if (!res.ok) return toast("You cannot open this file", false); const b = await res.blob(); const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = cfg.download(r); a.click(); });
        if (cfg.rowBtn?.[1] === "publish") add("Publish results", "", async () => { try { toast((await post("/exams/" + r.id + "/publish", {})).message); } catch (e) { toast(e.message, false); } });
        if (cfg.rowBtn?.[1] === "verifyDoc") {
          add("Verify", "ok", async () => { try { toast((await post("/admin/documents/" + r.id + "/verify?status=Verified", {})).message); location.reload(); } catch (e) { toast(e.message, false); } });
          add("Reject", "danger", async () => { const reason = prompt("Rejection reason (optional)") || ""; try { toast((await post("/admin/documents/" + r.id + "/verify?status=Rejected&remarks=" + encodeURIComponent(reason), {})).message); location.reload(); } catch (e) { toast(e.message, false); } });
        }
        if (cfg.rowBtn?.[1] === "review") add("Review", "", () => review(r));
      } } : { state: tstate }));
    } catch (e) { body.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
  }
  load();
}
async function review(a) {
  const subs = await api("/assignments/" + a.id + "/submissions");
  const m = document.createElement("div"); m.className = "modal on";
  m.innerHTML = `<div class="box" style="width:min(640px,95vw)"><h3 style="margin-top:0;font-family:var(--font-heading)">${esc(a.title)}</h3>
    <p class="lbl" style="margin:0 0 12px">Review submissions, assign marks and feedback. Max marks: <b>${esc(a.max_marks ?? "—")}</b></p>
    <div data-l></div><div style="margin-top:14px"><button class="btn ghost" data-c>Close</button></div></div>`;
  document.body.appendChild(m);
  const l = m.querySelector("[data-l]");
  if (!subs.length) { l.innerHTML = '<div class="empty">No submissions yet. Students upload from their Assignments page.</div>'; }
  subs.forEach(s => {
    const d = document.createElement("div"); d.className = "card"; d.style.margin = "0 0 10px";
    d.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">${esc(s.student)}</b>
      <span class="lbl">${s.submitted_at ? esc(String(s.submitted_at).slice(0, 16).replace("T", " ")) : ""}</span>
      ${s.file ? `<button class="btn sm ghost" data-dl>Download</button>` : ""}</div>
      <div class="form-grid" style="margin-top:8px">
        <div><label>Marks</label><input type="number" data-mk value="${s.marks ?? ""}" placeholder="0"></div>
        <div style="grid-column:span 2"><label>Feedback</label><input data-fb value="${esc(s.feedback || "")}" placeholder="Short feedback"></div>
      </div>
      <button class="btn sm" style="margin-top:8px" data-save>Save review</button>`;
    if (s.file) d.querySelector("[data-dl]").onclick = async () => {
      const res = await fetch(API + "/files/" + s.file, { headers: { Authorization: "Bearer " + localStorage.erp_token } });
      if (!res.ok) return toast("Cannot open file", false);
      const a2 = document.createElement("a"); a2.href = URL.createObjectURL(await res.blob()); a2.download = s.file; a2.click();
    };
    d.querySelector("[data-save]").onclick = async () => {
      try {
        toast((await post("/assignments/submissions/" + s.id + "/review", {
          marks: +d.querySelector("[data-mk]").value, feedback: d.querySelector("[data-fb]").value
        })).message);
      } catch (e) { toast(e.message, false); }
    };
    l.appendChild(d);
  });
  m.querySelector("[data-c]").onclick = () => m.remove();
}
async function markPage(host, hostel) {
  const card = document.createElement("div"); card.className = "card"; host.appendChild(card);
  card.innerHTML = `<div class="tools">${hostel ? "" : "<select id=cls style='max-width:260px'></select>"}<input type=date id=dt style="max-width:170px" value="${new Date().toISOString().slice(0, 10)}"><button class="btn ghost" id=all>All present</button><button class="btn" id=save>Save attendance</button></div><div id=list></div>`;
  let classes = []; if (!hostel) { classes = await api("/teachers/me/classes"); const s = $("#cls"); classes.forEach((c, i) => s.add(new Option(c.label, i))); s.onchange = load; }
  async function load() {
    const list = $("#list"); list.innerHTML = '<div class="spin"></div>'; let rows;
    if (hostel) rows = await api("/hostel/attendance?date_=" + $("#dt").value); else { const c = classes[$("#cls").value || 0]; if (!c) { list.textContent = "No classes assigned"; return; } rows = await api(`/attendance/class?class_id=${c.class_id}&date=${$("#dt").value}` + (c.section_id ? "&section_id=" + c.section_id : "")); }
    if (!rows.length) { list.innerHTML = '<div class="empty">No students found for this class/date.</div>'; return; }
    list.innerHTML = `<div class="att-hint lbl">Mark status for each student, then Save. Use “All present” for a quick start.</div>
      <div class="scroll"><table class="att-table"><thead><tr><th>Student</th>${["Present", "Absent", "Late", "Leave"].map(s => `<th class="att-${s}">${s}</th>`).join("")}</tr></thead><tbody>
      ${rows.map(r => `<tr data-id="${r.student_id}"><td><b>${esc(r.name)}</b></td>${["Present", "Absent", "Late", "Leave"].map(s => `<td class="att-cell"><label class="att-opt att-${s}"><input type=radio name="s${r.student_id}" value="${s}" ${r.status === s ? "checked" : ""}><span>${s[0]}</span></label></td>`).join("")}</tr>`).join("")}
      </tbody></table></div>`;
    list.querySelectorAll("input[type=radio]").forEach(inp => {
      const sync = () => {
        const name = inp.name;
        list.querySelectorAll(`input[name="${name}"]`).forEach(i => i.closest("label").classList.toggle("on", i.checked));
      };
      inp.addEventListener("change", sync); sync();
    });
  }
  $("#dt").onchange = load; $("#all").onclick = () => document.querySelectorAll('input[value="Present"]').forEach(i => i.checked = true);
  $("#save").onclick = async () => {
    const records = [...document.querySelectorAll("#list tr[data-id]")].map(tr => ({ student_id: +tr.dataset.id, status: tr.querySelector("input:checked")?.value })).filter(r => r.status);
    if (!records.length) return toast("Select a status first", false);
    try { const date = $("#dt").value; let r; if (hostel) r = await post("/hostel/attendance", { date, records }); else { const c = classes[$("#cls").value || 0]; r = await post("/attendance/mark", { class_id: c.class_id, section_id: c.section_id, date, records }); } toast(r.message); } catch (e) { toast(e.message, false); }
  }; load();
}
async function materialsPage(host) {
  host.innerHTML = "";
  const card = document.createElement("div"); card.className = "card"; host.appendChild(card);
  let subs = [];
  try { subs = await api("/teachers/subjects"); } catch (e) { card.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; return; }
  if (!subs.length) {
    card.innerHTML = '<div class="empty"><b>No subjects assigned</b><p class="lbl">Ask admin to allocate subjects to your classes.</p></div>';
    return;
  }
  card.innerHTML = `<b>Upload study material</b>
    <div class="tools" style="margin-top:10px;flex-wrap:wrap">
      <select id="ms" style="min-width:200px;flex:1">${subs.map((s, i) => `<option value="${i}">${esc(s.label)}</option>`).join("")}</select>
      <input id="mt" placeholder="Title" style="min-width:160px;flex:1">
      <input type="file" id="mf" accept=".pdf,.doc,.docx,.ppt,.pptx,.png,.jpg,.jpeg">
      <button class="btn" type="button" id="mu">Upload</button>
    </div>
    <p class="lbl" style="margin-top:8px">PDF, Word, PowerPoint or image · max 5MB</p>`;
  const list = document.createElement("div"); list.className = "card"; list.innerHTML = '<div class="spin"></div>'; host.appendChild(list);
  async function loadList() {
    try {
      let rows = [];
      try { rows = await api("/homework"); } catch (e) { rows = []; }
      // study materials endpoint if exists
      try {
        const m = await api("/files/materials");
        if (Array.isArray(m)) rows = m;
        else if (m && m.items) rows = m.items;
      } catch (e) {}
      list.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Uploaded materials</b></div>`;
      if (!rows.length) {
        list.insertAdjacentHTML("beforeend", '<div class="empty"><b>No materials yet</b><p class="lbl">Upload notes for your classes above.</p></div>');
        return;
      }
      list.appendChild(table(rows, [
        ["title", "Title"], ["subject", "Subject"], ["class", "Class"], ["created_at", "Date"]
      ], { noq: true, per: 20, extra: (r, td) => {
        if (r.file_path || r.file) {
          const b = document.createElement("button"); b.className = "btn sm ghost"; b.textContent = "Open";
          b.onclick = () => window.open(API + "/files/" + (r.file_path || r.file), "_blank");
          td.appendChild(b);
        }
      }}));
    } catch (e) { list.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
  }
  $("#mu").onclick = async () => {
    const s = subs[$("#ms").value];
    if (!$("#mf").files[0]) return toast("Choose a file", false);
    if (!$("#mt").value.trim()) return toast("Enter a title", false);
    const fd = new FormData();
    fd.append("title", $("#mt").value);
    fd.append("class_id", s.class_id);
    fd.append("subject_id", s.id || s.subject_id);
    fd.append("file", $("#mf").files[0]);
    try {
      toast((await api("/files/materials", { method: "POST", body: fd })).message || "Uploaded");
      $("#mt").value = ""; $("#mf").value = "";
      loadList();
    } catch (e) { toast(e.message, false); }
  };
  loadList();
}
function buildCalendar(events) {
  const wrap = document.createElement("div"); wrap.className = "card";
  const today = new Date(); const y = today.getFullYear(), mo = today.getMonth();
  const first = new Date(y, mo, 1); const startPad = (first.getDay() + 6) % 7; // Mon=0
  const daysIn = new Date(y, mo + 1, 0).getDate();
  const byDate = {};
  (events || []).forEach(e => { if (!e.event_date) return; (byDate[e.event_date] = byDate[e.event_date] || []).push(e); });
  const monthName = first.toLocaleString("en", { month: "long", year: "numeric" });
  let cells = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map(h => `<div class="ch">${h}</div>`).join("");
  for (let i = 0; i < startPad; i++) cells += `<div class="cd muted"></div>`;
  for (let d = 1; d <= daysIn; d++) {
    const iso = `${y}-${String(mo + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    const isToday = d === today.getDate();
    const evs = byDate[iso] || [];
    const tip = evs.map(e => e.title).join(", ");
    cells += `<div class="cd${isToday ? " today" : ""}${evs.length ? " has-ev" : ""}" title="${esc(tip || "")}" data-date="${iso}">${d}${evs.length ? '<div class="dot"></div>' : ""}</div>`;
  }
  wrap.innerHTML = `<b>📅 School calendar · ${esc(monthName)}</b><div class="cal-grid" style="margin-top:10px">${cells}</div>`;
  const list = (events || []).filter(e => e.event_date).slice(0, 8);
  if (list.length) {
    const ul = document.createElement("div"); ul.style.marginTop = "12px";
    ul.innerHTML = list.map(e => `<div class="lbl" style="margin:4px 0"><b style="color:var(--text)">${esc(e.event_date)}</b> — ${esc(e.title)}${e.description ? ": " + esc(e.description) : ""}</div>`).join("");
    wrap.appendChild(ul);
  } else {
    wrap.insertAdjacentHTML("beforeend", '<p class="lbl" style="margin-top:10px">No upcoming events. Add them from Notices & Events.</p>');
  }
  wrap.querySelectorAll(".cd.has-ev").forEach(el => {
    el.onclick = () => {
      const evs = byDate[el.dataset.date] || [];
      modal2("Events · " + el.dataset.date, evs.map(e => `<div class="card" style="margin:6px 0"><b>${esc(e.title)}</b><div class="lbl">${esc(e.description || "")}</div></div>`).join("") || "None");
    };
  });
  return wrap;
}
async function dashboard(cfg, host) {
  host.innerHTML = '<div class="spin"></div>';
  try {
    const d = await api(cfg.url); host.innerHTML = ""; if (cfg.child) host.insertAdjacentHTML("beforeend", `<p class="lbl">Showing: <b>${esc(d.child)}</b> (${esc(d.class)})</p>`);
    if (cfg.quick) { const q = document.createElement("div"); q.className = "quick"; cfg.quick.forEach(x => { const b = document.createElement("button"); b.className = "btn"; b.textContent = x.l; b.onclick = () => x.form ? modal(x.form.title, x.form.fields, body => post(x.form.url, body)) : (location.href = x.href); q.appendChild(b); }); host.appendChild(q); }
    host.appendChild(statCards(d, cfg.cards));
    if (cfg.charts) host.appendChild(chartGrid(cfg.charts, [], d));
    if (cfg.calendar) {
      const split = document.createElement("div"); split.className = "dash-split";
      const left = document.createElement("div");
      (cfg.tables || []).slice(0, 2).forEach(([k, t, cols]) => { const c = document.createElement("div"); c.className = "card"; c.innerHTML = `<b>${t}</b>`; c.appendChild(table(d[k] || [], cols)); left.appendChild(c); });
      split.appendChild(left);
      split.appendChild(buildCalendar(d.calendar_events));
      host.appendChild(split);
      (cfg.tables || []).slice(2).forEach(([k, t, cols]) => { const c = document.createElement("div"); c.className = "card"; c.innerHTML = `<b>${t}</b>`; c.appendChild(table(d[k] || [], cols)); host.appendChild(c); });
    } else {
      (cfg.tables || []).forEach(([k, t, cols]) => { const c = document.createElement("div"); c.className = "card"; c.innerHTML = `<b>${t}</b>`; c.appendChild(table(d[k] || [], cols)); host.appendChild(c); });
    }
  } catch (e) { host.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
}

/* ---------------- admin custom pages ---------------- */
const custom = (name, host) => ({ mark: () => markPage(host, false), hostelmark: () => markPage(host, true), correct: () => correctPage(host), promotion: () => promotionPage(host),
  studentprofile: () => studentProfilePage(host), settings: () => settingsPage(host), timetable: () => timetablePage(host), usersAccess: () => usersAccessPage(host),
  documents: () => documentsPage(host), adminDash: () => adminDashboardPage(host),
  examsAdmin: () => examsAdminPage(host), feesAdmin: () => feesAdminPage(host),
  academicsAdmin: () => academicsAdminPage(host), hostelAdmin: () => hostelAdminPage(host),
  noticesAdmin: () => noticesAdminPage(host),
  teacherDash: () => teacherDashPage(host), studentDash: () => studentDashPage(host),
  parentDash: () => parentDashPage(host), wardenDash: () => wardenDashPage(host),
  teacherAtt: () => teacherAttPage(host), portalSettings: () => portalSettingsPage(host),
  portalNotices: () => portalNoticesPage(host),
  teacherWork: () => teacherWorkPage(host), teacherMarks: () => teacherMarksPage(host),
  studentWork: () => studentWorkPage(host), studentDocs: () => studentDocsPage(host),
  studentResults: () => studentResultsPage(host), wardenRooms: () => wardenRoomsPage(host), messGrid: () => messGridPage(host, true), messView: () => messGridPage(host, false)
  })[name]();
const mkCard = (host, html) => { const c = document.createElement("div"); c.className = "card"; if (html) c.innerHTML = html; host.appendChild(c); return c; };
const errBox = (host, e) => { host.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; };

async function studentProfilePage(host) {
  const id = new URLSearchParams(location.search).get("id");
  if (!id) return mkCard(host, '<p class="lbl">Open a student from the <a href="students.html">Students</a> page.</p>');
  host.innerHTML = '<div class="spin"></div>';
  let d; try { d = await api(`/admin/students/${id}/profile`); } catch (e) { return errBox(host, e); }
  const s = d.details; host.innerHTML = "";
  const initials = (s.name || "?").split(" ").map(x => x[0]).slice(0, 2).join("").toUpperCase();
  const photoUrl = s.photo ? (API + "/files/" + s.photo) : null;

  // Hero
  const head = document.createElement("div"); head.className = "card student-hero";
  head.innerHTML = `<div class="phead">
    <div class="avatar profile-avatar large">${photoUrl ? `<img src="${photoUrl}" alt="" onerror="this.remove()">` : esc(initials)}</div>
    <div class="pinfo" style="flex:1">
      <h2 style="margin:0;font-family:var(--font-heading)">${esc(s.name)} ${s.active ? "" : '<span class="badge b-Absent">Inactive</span>'}</h2>
      <div class="lbl" style="margin-top:4px">${esc(s.class)} – ${esc(s.section)} · Roll ${esc(s.roll_no ?? "—")} · Adm ${esc(s.admission_no)}</div>
      <div class="lbl">${s.gender === "F" ? "Female" : s.gender === "M" ? "Male" : ""} ${s.dob ? "· Born " + esc(s.dob) : ""} ${s.city ? "· " + esc(s.city) : ""}</div>
    </div>
    <div class="pbtn"></div>
  </div>
  <div class="profile-kv" style="margin-top:14px">
    <b>Mobile</b><span>${esc(s.mobile || "—")}</span>
    <b>Email</b><span>${esc(s.email || "—")}</span>
    <b>Parent</b><span>${esc(s.parent_name || "—")} ${s.parent_mobile ? "(" + esc(s.parent_mobile) + ")" : ""}</span>
    <b>Hostel</b><span>${d.hostel ? esc(d.hostel.room) : "Day scholar"}</span>
  </div>`;
  host.appendChild(head);
  const btn = (label, cls, fn) => { const b = document.createElement("button"); b.className = "btn sm " + cls; b.textContent = label; b.onclick = fn; head.querySelector(".pbtn").appendChild(b); };
  btn("← Students", "ghost", () => { location.href = "students.html"; });
  btn("Edit", "ghost", async () => { try { modal("Edit Student", stFields, body => put("/admin/students/" + id, body), await api("/admin/students/" + id)); } catch (e) { toast(e.message, false); } });
  btn("Report card", "ghost", () => getPdf("/pdf/report-card?student_id=" + id, "report_card_" + s.admission_no + ".pdf"));
  btn("Upload photo", "ghost", () => {
    const inp = document.createElement("input"); inp.type = "file"; inp.accept = "image/*";
    inp.onchange = async () => {
      if (!inp.files[0]) return;
      const fd = new FormData();
      fd.append("doc_type", "photo");
      fd.append("title", "Profile photo");
      fd.append("file", inp.files[0]);
      try {
        // admin may not have student upload - use admin documents path if exists; else student path won't work
        // Use a dedicated admin upload if available
        await api("/admin/students/" + id + "/photo", { method: "POST", body: fd });
        toast("Photo uploaded"); render();
      } catch (e) {
        // fallback: not available
        toast(e.message || "Photo upload failed", false);
      }
    };
    inp.click();
  });
  btn(s.active ? "Deactivate" : "Re-activate", s.active ? "ghost danger" : "", async () => {
    if (s.active && !confirm("Deactivate this student?")) return;
    try { toast((await post(`/admin/users/${s.user_id}/${s.active ? "deactivate" : "activate"}`, {})).message); render(); } catch (e) { toast(e.message, false); }
  });

  host.appendChild(statCards({
    att: d.attendance.percentage, avg: d.average, pend: d.pending_fees,
    n: (d.results || []).length, docs: (d.documents || []).length
  }, [["att", "Attendance %"], ["avg", "Average %"], ["pend", "Pending fees ₹"], ["n", "Results"], ["docs", "Documents"]]));

  host.appendChild(chartGrid([
    { key: "attendance_breakdown", type: "donut", title: "Attendance", sub: "days" },
    { key: "subject_performance", type: "hbar", title: "Subject performance %", unit: "%", max: 100, color: pctColor },
    { key: "fee_status", type: "donut", title: "Fees", money: true, sub: "total" },
  ], [], d));

  // Documents with verify
  const docCard = document.createElement("div"); docCard.className = "card";
  docCard.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Documents</b><span class="lbl">${(d.documents || []).length} file(s)</span></div>`;
  const docs = d.documents || [];
  if (!docs.length) docCard.insertAdjacentHTML("beforeend", '<div class="empty">No documents uploaded yet.</div>');
  else {
    docCard.appendChild(table(docs, [["doc_type", "Type"], ["title", "Title"], ["status", "Status"], ["uploaded_at", "Uploaded"]], {
      noq: true, per: 20,
      extra: (r, td) => {
        const add = (label, cls, fn) => { const b = document.createElement("button"); b.className = "btn sm " + cls; b.textContent = label; b.onclick = fn; td.appendChild(b); };
        if (r.file_path) add("Preview", "ghost", async () => {
          try {
            const res = await fetch(API + "/files/" + r.file_path, { headers: { Authorization: "Bearer " + localStorage.erp_token } });
            if (!res.ok) return toast("Cannot open", false);
            const blob = await res.blob(); const url = URL.createObjectURL(blob);
            const m = document.createElement("div"); m.className = "drawer-root on";
            m.innerHTML = `<div class="drawer-backdrop" data-c></div><aside class="drawer-panel" style="width:min(480px,100vw)">
              <div class="drawer-head"><div><h3>${esc(r.title)}</h3><p class="lbl">${esc(r.doc_type)} · ${esc(r.status)}</p></div>
              <button class="btn ghost sm" data-c>✕</button></div>
              <div class="drawer-body">${blob.type.startsWith("image/") ? `<img src="${url}" style="max-width:100%;border-radius:10px">` : `<a class="btn" href="${url}" target="_blank">Open file</a>`}</div>
              <div class="drawer-foot"><div style="flex:1"></div><button class="btn ghost" data-c>Close</button></div></aside>`;
            document.body.appendChild(m); document.body.classList.add("drawer-open");
            const close = () => { m.remove(); document.body.classList.remove("drawer-open"); };
            m.querySelectorAll("[data-c]").forEach(b => b.onclick = close);
          } catch (e) { toast(e.message, false); }
        });
        if (r.status === "Pending") {
          add("Verify", "ok", async () => { try { toast((await post("/admin/documents/" + r.id + "/verify?status=Verified", {})).message); render(); } catch (e) { toast(e.message, false); } });
          add("Reject", "danger", () => modal("Reject", [F("remarks", "Reason", "textarea")], async body => {
            await post("/admin/documents/" + r.id + "/verify?status=Rejected&remarks=" + encodeURIComponent(body.remarks || ""), {});
            toast("Rejected"); render(); return {};
          }));
        }
      }
    }));
  }
  host.appendChild(docCard);

  const t = (title, rows, cols, opts) => {
    const c = document.createElement("div"); c.className = "card";
    c.innerHTML = `<b>${esc(title)}</b>`;
    c.appendChild(table(rows || [], cols, { noq: true, per: 12, ...(opts || {}) }));
    host.appendChild(c);
  };
  t("Results", d.results, [["exam", "Exam"], ["subject", "Subject"], ["total", "Total"], ["percentage", "%"], ["grade", "Grade"], ["result", "Result"]]);
  t("Fees", d.fees, [["fee_type", "Type"], ["amount", "Total"], ["paid", "Paid"], ["pending", "Pending"], ["due_date", "Due"]]);
  t("Payments", d.payments, [["paid_on", "Date"], ["fee_type", "Fee"], ["amount", "Amount"], ["mode", "Mode"]], {
    extra: (r, td) => {
      if (!r.payment_id) return;
      const b = document.createElement("button"); b.className = "btn sm ghost"; b.textContent = "Receipt";
      b.onclick = () => getPdf("/pdf/receipt/" + r.payment_id, "receipt_" + r.payment_id + ".pdf");
      td.appendChild(b);
    }
  });
  if (d.hostel) {
    t("Hostel outpass history", d.hostel.outpasses || [], [["from", "From"], ["to", "To"], ["reason", "Reason"], ["status", "Status"]]);
  }
}


async function promotionPage(host) {
  const classes = await api("/admin/classes");
  const c = mkCard(host, `<p class="lbl">Move a class up at the end of the school year. Untick students who must repeat the year. Marks, fees and attendance history are kept. Students moved to <b>Leave school</b> become inactive (alumni) and cannot log in.</p>
    <div class="tools"><label class="lbl">From</label><select id="pf" style="max-width:200px"></select><label class="lbl">To</label><select id="pt" style="max-width:220px"></select><input id="py" placeholder="New year, e.g. 2027-28 (first class only)" style="max-width:290px"><button class="btn" id="pgo">Promote selected</button></div><p class="lbl" id="pyi"></p><div id="plist"></div>`);
  classes.forEach(x => $("#pf", c).add(new Option(`${x.name} (${x.students})`, x.id)));
  const first = classes.find(x => x.students > 0) || classes[0]; if (first) $("#pf", c).value = first.id;
  const fillTo = (next) => { const t = $("#pt", c); t.innerHTML = ""; classes.filter(x => x.id != $("#pf", c).value).forEach(x => t.add(new Option(x.name, x.id))); t.add(new Option("🎓 Leave school (graduate)", "grad")); if (next) t.value = next; };
  async function load() {
    const list = $("#plist", c); list.innerHTML = '<div class="spin"></div>';
    try {
      const d = await api("/admin/promotion/preview?class_id=" + $("#pf", c).value); fillTo(d.next_class_id);
      $("#pyi", c).innerHTML = `Current academic year: <b>${esc(d.current_year || "not set")}</b>. When you promote the <b>first</b> class, type the new year (e.g. 2027-28) - it is created once and becomes current. For the other classes leave the box <b>empty</b>.`;
      list.innerHTML = d.students.length ? `<table><tr><th><input type="checkbox" id="pall" checked style="width:auto"></th><th>Roll</th><th>Name</th><th>Section</th><th>Attendance</th><th>Pending fees</th></tr>${d.students.map(s => `<tr><td><input type="checkbox" class="pk" value="${s.id}" checked style="width:auto"></td><td>${esc(s.roll_no ?? "-")}</td><td>${esc(s.name)}</td><td>${esc(s.section)}</td><td>${s.attendance}%</td><td>${s.pending_fees > 0 ? `<span class="badge b-Pending">₹${s.pending_fees.toLocaleString("en-IN")}</span>` : "-"}</td></tr>`).join("")}</table>` : '<p class="lbl">No active students in this class.</p>';
      const all = $("#pall", c); if (all) all.onchange = () => c.querySelectorAll(".pk").forEach(k => k.checked = all.checked);
    } catch (e) { list.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
  }
  $("#pf", c).onchange = () => { load(); };
  $("#pgo", c).onclick = async () => {
    const ids = [...c.querySelectorAll(".pk:checked")].map(k => +k.value); if (!ids.length) return toast("Tick at least one student", false);
    const to = $("#pt", c).value, label = $("#pt", c).selectedOptions[0].textContent, from = $("#pf", c).selectedOptions[0].textContent.replace(/ \(\d+\)$/, "");
    if (!confirm(`${to === "grad" ? "Mark" : "Move"} ${ids.length} student(s) of ${from} ${to === "grad" ? "as having LEFT school" : "to " + label}?`)) return;
    try { const r = await post("/admin/promotion", { from_class_id: +$("#pf", c).value, to_class_id: to === "grad" ? null : +to, student_ids: ids, academic_year: $("#py", c).value.trim() || null }); toast(r.message); const fresh = await api("/admin/classes"); classes.splice(0, classes.length, ...fresh); $("#pf", c).innerHTML = ""; classes.forEach(x => $("#pf", c).add(new Option(`${x.name} (${x.students})`, x.id))); $("#pf", c).value = classes.find(x => x.name === from)?.id; load(); } catch (e) { toast(e.message, false); }
  };
  load();
}

async function correctPage(host) {
  const [classes, sections] = await Promise.all([api("/admin/classes"), api("/admin/sections")]);
  const today = new Date().toISOString().slice(0, 10);
  const c = mkCard(host, `<b>Correct attendance for any date</b><p class="lbl">Pick a class and a date. Existing marks are shown; change them and press Save. Every correction is written to the Audit Log.</p>
    <div class="tools"><select id="cc" style="max-width:180px"></select><select id="cs" style="max-width:150px"></select><input type="date" id="cd" max="${today}" value="${today}" style="max-width:170px"><button class="btn ghost" id="call">All present</button><button class="btn" id="csave">Save corrections</button></div><div id="clist"></div>`);
  classes.forEach(x => $("#cc", c).add(new Option(x.name, x.id))); const f = classes.find(x => x.students > 0) || classes[0]; if (f) $("#cc", c).value = f.id;
  const fillSec = () => { const s = $("#cs", c); s.innerHTML = '<option value="">All sections</option>'; sections.filter(x => x.class_id == $("#cc", c).value).forEach(x => s.add(new Option("Section " + x.name, x.id))); };
  async function load() {
    const list = $("#clist", c); list.innerHTML = '<div class="spin"></div>';
    try {
      const rows = await api(`/attendance/class?class_id=${$("#cc", c).value}&date=${$("#cd", c).value}` + ($("#cs", c).value ? "&section_id=" + $("#cs", c).value : ""));
      const ST = ["Present", "Absent", "Late", "Leave"], unmarked = rows.filter(r => !r.status).length;
      list.innerHTML = rows.length ? `${unmarked ? `<p class="lbl">⚠ ${unmarked} student(s) have no attendance for this date yet.</p>` : ""}<table><tr><th>Roll</th><th>Name</th>${ST.map(x => `<th>${x}</th>`).join("")}</tr>${rows.map(r => `<tr data-id="${r.student_id}"><td>${esc(r.roll_no ?? "-")}</td><td>${esc(r.name)}</td>${ST.map(x => `<td><input type="radio" name="c${r.student_id}" value="${x}" ${r.status === x ? "checked" : ""} style="width:auto"></td>`).join("")}</tr>`).join("")}</table>` : '<p class="lbl">No students in this class.</p>';
    } catch (e) { list.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
  }
  $("#cc", c).onchange = () => { fillSec(); load(); }; $("#cs", c).onchange = load; $("#cd", c).onchange = load;
  $("#call", c).onclick = () => c.querySelectorAll('input[value="Present"]').forEach(i => i.checked = true);
  $("#csave", c).onclick = async () => {
    const records = [...c.querySelectorAll("#clist tr[data-id]")].map(tr => ({ student_id: +tr.dataset.id, status: tr.querySelector("input:checked")?.value })).filter(r => r.status);
    if (!records.length) return toast("Select a status first", false);
    try { toast((await post("/attendance/mark", { class_id: +$("#cc", c).value, section_id: $("#cs", c).value ? +$("#cs", c).value : null, date: $("#cd", c).value, records })).message); load(); } catch (e) { toast(e.message, false); }
  };
  fillSec(); load();
}





async function tabbedModule(host, tabs, defaultKey) {
  host.innerHTML = "";
  const bar = document.createElement("div");
  bar.className = "mod-tabs";
  const body = document.createElement("div");
  host.appendChild(bar); host.appendChild(body);
  let active = defaultKey || tabs[0].key;
  async function show(key) {
    active = key;
    bar.querySelectorAll("button").forEach(b => b.classList.toggle("on", b.dataset.k === key));
    body.innerHTML = "";
    const tab = tabs.find(x => x.key === key);
    if (!tab) return;
    if (tab.render) await tab.render(body);
    else if (tab.section) await section(tab.section, body);
    else if (tab.sections) for (const s of tab.sections) await section(s, body);
  }
  tabs.forEach(tab => {
    const b = document.createElement("button");
    b.type = "button"; b.dataset.k = tab.key; b.textContent = tab.label;
    if (tab.key === active) b.classList.add("on");
    b.onclick = () => show(tab.key);
    bar.appendChild(b);
  });
  await show(active);
}

function initials(name) {
  return String(name || "?").split(/\s+/).filter(Boolean).map(s => s[0]).slice(0, 2).join("").toUpperCase();
}
function openPersonDrawer(title, fields, extraHtml) {
  document.querySelectorAll(".drawer-root").forEach(el => el.remove());
  const m = document.createElement("div");
  m.className = "drawer-root on";
  m.innerHTML = `<div class="drawer-backdrop" data-c></div>
    <aside class="drawer-panel" style="width:min(440px,100vw)">
      <div class="drawer-head"><div><h3>${esc(title)}</h3></div>
        <button type="button" class="btn ghost sm" data-c>✕</button></div>
      <div class="drawer-body" data-b></div>
      <div class="drawer-foot"><div style="flex:1"></div><button type="button" class="btn ghost" data-c>Close</button></div>
    </aside>`;
  document.body.appendChild(m);
  document.body.classList.add("drawer-open");
  const close = () => { m.remove(); document.body.classList.remove("drawer-open"); };
  m.querySelectorAll("[data-c]").forEach(b => b.onclick = close);
  const body = m.querySelector("[data-b]");
  const name = fields.Name || fields.name || title;
  body.innerHTML = `<div class="profile-drawer-hero">
      <div class="profile-avatar">${fields.photo ? `<img src="${esc(fields.photo)}" alt="">` : esc(initials(name))}</div>
      <div><b style="font-size:16px;font-family:var(--font-heading)">${esc(name)}</b>
        <div class="lbl">${esc(fields.role || "")}</div></div>
    </div>
    <div class="profile-kv">${Object.entries(fields).filter(([k]) => !["Name","name","photo","role"].includes(k)).map(([k,v]) => `<b>${esc(k)}</b><span>${esc(v ?? "—")}</span>`).join("")}</div>
    ${extraHtml || ""}`;
  return { close, body };
}



async function noticesAdminPage(host) {
  host.innerHTML = "";
  const tools = document.createElement("div"); tools.className = "tools";
  tools.innerHTML = `<b style="flex:1;font-family:var(--font-heading);font-size:17px">Notices & events</b>`;
  const addN = document.createElement("button"); addN.className = "btn"; addN.textContent = "+ Notice";
  const addE = document.createElement("button"); addE.className = "btn ghost"; addE.textContent = "+ Event";
  tools.appendChild(addN); tools.appendChild(addE); host.appendChild(tools);

  const grid = document.createElement("div"); grid.className = "notice-grid"; host.appendChild(grid);

  async function load() {
    grid.innerHTML = '<div class="spin"></div>';
    let notices = [], events = [];
    try { notices = await api("/notifications/notices"); } catch (e) { notices = []; }
    try { events = await api("/notifications/events"); } catch (e) { events = []; }
    grid.innerHTML = "";
    const all = [
      ...notices.map(n => ({ ...n, _kind: "Notice" })),
      ...events.map(e => ({ ...e, _kind: "Event", body: e.description || e.body })),
    ];
    if (!all.length) {
      grid.innerHTML = '<div class="empty">No notices or events yet. Post the first one.</div>';
      return;
    }
    all.forEach(n => {
      const card = document.createElement("div"); card.className = "notice-card card";
      card.innerHTML = `<div class="tools" style="margin:0">
        <span class="badge ${n._kind === "Event" ? "b-Late" : "b-Present"}">${n._kind}</span>
        <span class="lbl" style="margin-left:auto">${esc(n.event_date || n.created_at || n.date || "")}</span>
      </div>
      <h3 style="margin:10px 0 6px;font-size:15px;font-family:var(--font-heading)">${esc(n.title || n.name)}</h3>
      <p class="lbl" style="margin:0;line-height:1.5">${esc((n.body || n.description || "").slice(0, 160))}${(n.body || n.description || "").length > 160 ? "…" : ""}</p>
      <div class="cc-actions" style="margin-top:12px"></div>`;
      const acts = card.querySelector(".cc-actions");
      const add = (label, cls, fn) => { const b = document.createElement("button"); b.className = "btn sm " + cls; b.textContent = label; b.onclick = fn; acts.appendChild(b); };
      add("View", "ghost", () => {
        openPersonDrawer(n.title || n.name, {
          name: n.title || n.name, role: n._kind,
          Audience: n.audience || "all", Category: n.category || "—",
          Date: n.event_date || n.created_at || "—",
          Details: n.body || n.description || "—"
        });
      });
      if (n._kind === "Notice") {
        add("Edit", "ghost", () => modal("Edit notice", [F("title", "Title"), F("body", "Body", "textarea"), F("audience", "Audience", "select", { list: ["all", "student", "teacher", "parent", "warden"] })], body => put("/notifications/notices/" + n.id, body), n));
        add("Delete", "ghost danger", async () => {
          if (!confirm("Delete notice?")) return;
          try { await api("/notifications/notices/" + n.id, { method: "DELETE" }); toast("Deleted"); load(); } catch (e) { toast(e.message, false); }
        });
      } else {
        add("Edit", "ghost", () => modal("Edit event", [F("title", "Title"), F("description", "Description", "textarea"), F("event_date", "Date", "date")], body => put("/notifications/events/" + n.id, body), n));
        add("Delete", "ghost danger", async () => {
          if (!confirm("Delete event?")) return;
          try { await api("/notifications/events/" + n.id, { method: "DELETE" }); toast("Deleted"); load(); } catch (e) { toast(e.message, false); }
        });
      }
      grid.appendChild(card);
    });
  }

  addN.onclick = () => modal("Post notice", noticeForm.fields || [F("title", "Title"), F("body", "Body", "textarea"), F("audience", "Audience", "select", { list: ["all", "student", "teacher", "parent", "warden"] })], async body => {
    await post(noticeForm.url || "/notifications/notices", body); toast("Notice posted"); load(); return {};
  });
  addE.onclick = () => modal("Add event", [F("title", "Title"), F("description", "Description", "textarea"), F("event_date", "Date", "date")], async body => {
    await post("/notifications/events", body); toast("Event added"); load(); return {};
  });
  await load();
}

async function examsAdminPage(host) {
  await tabbedModule(host, [
    { key: "schedule", label: "Exam schedule", sections: [
      { title: "1. Exam / test definitions", url: "/exams", cols: [["name", "Exam name"], ["exam_type", "Type"], ["class", "Class"], ["section", "Section"], ["subject", "Subject"], ["max_marks", "Max"], ["internal_max", "Internal"]],
        form: { title: "Create exam", url: "/exams", fields: [
          F("name", "Exam name"), F("exam_type", "Type", "select", { list: ["exam", "test", "Unit Test", "Mid-Term", "Final"] }),
          F("class_id", "Class", "select", CL), F("section_id", "Section (optional)", "select", SEC),
          F("subject_id", "Subject", "select", SUB), F("max_marks", "Exam max marks", "number"), F("internal_max", "Internal max", "number")
        ] },
        edit: { title: "Edit exam", url: "/exams/", fields: [F("name", "Name"), F("max_marks", "Max marks", "number"), F("internal_max", "Internal max", "number")] },
        del: "/exams/", confirm: "Delete this exam?" },
      { title: "2. Subject schedule (date & time)", url: "/exams", cols: [["name", "Exam"], ["subject", "Subject"], ["class", "Class"], ["exam_date", "Date"], ["start_time", "Start"], ["end_time", "End"]],
        form: { title: "Set subject schedule", url: "/exams", fields: [
          F("name", "Exam name (same as above)"), F("exam_type", "Type", "select", { list: ["exam", "test"] }),
          F("class_id", "Class", "select", CL), F("subject_id", "Subject", "select", SUB),
          F("exam_date", "Date", "date"), F("start_time", "Start HH:MM"), F("end_time", "End HH:MM"),
          F("max_marks", "Max marks", "number"), F("internal_max", "Internal max", "number")
        ] },
        edit: { title: "Edit schedule", url: "/exams/", fields: [F("exam_date", "Date", "date"), F("start_time", "Start"), F("end_time", "End")] },
        rowBtn: ["Publish results", "publish"],
        charts: [{ title: "Exams by class", type: "bar", by: "class", single: true }] },
    ]},
    { key: "marks", label: "Mark entry", render: async (body) => {
      body.innerHTML = "";
      const bar = document.createElement("div"); bar.className = "card";
      bar.innerHTML = `<div class="tools" style="margin:0;flex-wrap:wrap;gap:8px">
        <b style="flex:1;min-width:120px">Mark entry</b>
        <select id="mkClass" style="min-width:140px"><option value="">Class</option></select>
        <select id="mkSec" style="min-width:100px"><option value="">Section</option></select>
        <select id="mkExam" style="min-width:200px;flex:1"><option value="">Exam / subject</option></select>
        <button class="btn" type="button" id="mkLoad">Load roster</button>
        <button class="btn ghost" type="button" id="mkSave">Save marks</button>
      </div>
      <p class="lbl" style="margin:8px 0 0">Select <b>Class → Section → Exam</b>, load students, enter marks, then Save.</p>`;
      body.appendChild(bar);
      const grid = document.createElement("div"); grid.className = "card"; body.appendChild(grid);
      let exams = [], classes = [];
      try { exams = await api("/exams"); classes = await api("/admin/classes"); } catch (e) { return errBox(body, e); }
      const selC = $("#mkClass"), selS = $("#mkSec"), selE = $("#mkExam");
      (classes || []).forEach(c => selC.add(new Option(c.name || c.label, c.id)));
      function fillSections() {
        selS.innerHTML = '<option value="">All sections</option>';
        const c = (classes || []).find(x => String(x.id) === String(selC.value));
        const secs = (c && (c.sections || c.section_list)) || [];
        if (Array.isArray(secs)) secs.forEach(s => {
          const id = s.id || s; const name = s.name || s;
          selS.add(new Option(name, id));
        });
        // also from students later
        fillExams();
      }
      function fillExams() {
        selE.innerHTML = '<option value="">Exam / subject</option>';
        const cid = selC.value;
        exams.filter(e => !cid || String(e.class_id) === String(cid) || e.class === (classes.find(c => String(c.id)===String(cid))||{}).name)
          .forEach(e => selE.add(new Option(`${e.name} · ${e.subject || ""} · ${e.exam_date || ""}`, e.id)));
      }
      selC.onchange = fillSections;
      selS.onchange = fillExams;
      fillSections();
      $("#mkLoad").onclick = async () => {
        const exam = exams.find(e => String(e.id) === String(selE.value));
        if (!exam) return toast("Select exam", false);
        grid.innerHTML = '<div class="spin"></div>';
        try {
          let students = await api("/admin/students");
          students = students.filter(s => {
            if (exam.class_id && s.class_id && String(s.class_id) !== String(exam.class_id)) return false;
            if (selC.value && s.class_id && String(s.class_id) !== String(selC.value)) return false;
            if (selS.value && s.section_id && String(s.section_id) !== String(selS.value)) return false;
            if (selS.value && s.section && !String(s.section_id)) {
              const secOpt = selS.options[selS.selectedIndex];
              if (secOpt && s.section !== secOpt.text) return false;
            }
            return true;
          });
          let results = [];
          try { results = await api("/exams/results?exam_id=" + exam.id); } catch (e) { results = []; }
          const byStu = Object.fromEntries((results || []).map(r => [String(r.student_id || r.student), r]));
          if (!students.length) { grid.innerHTML = '<div class="empty">No students for this class/section.</div>'; return; }
          grid.innerHTML = `<div class="tools" style="margin:0 0 8px"><span class="lbl">${students.length} students · ${esc(exam.name)} · max ${exam.internal_max||0}+${exam.max_marks||0}</span></div>
            <div class="scroll"><table class="att-table"><thead><tr>
            <th>Roll</th><th>Student</th><th>Section</th><th>Internal /${exam.internal_max||0}</th><th>Exam /${exam.max_marks||0}</th><th>Total</th></tr></thead><tbody></tbody></table></div>`;
          const tb = grid.querySelector("tbody");
          students.forEach(s => {
            const prev = byStu[String(s.id)] || {};
            const tr = document.createElement("tr");
            tr.innerHTML = `<td>${esc(s.roll_no||"")}</td><td>${esc(s.name)}</td><td>${esc(s.section||"")}</td>
              <td><input type="number" min="0" max="${exam.internal_max||100}" data-st="${s.id}" data-f="internal" value="${prev.internal_marks ?? prev.internal ?? ""}" style="width:72px"></td>
              <td><input type="number" min="0" max="${exam.max_marks||100}" data-st="${s.id}" data-f="exam" value="${prev.exam_marks ?? prev.exam ?? ""}" style="width:72px"></td>
              <td class="lbl" data-tot="${s.id}">—</td>`;
            tb.appendChild(tr);
            const upd = () => {
              const a = +tr.querySelector('[data-f="internal"]').value || 0;
              const b = +tr.querySelector('[data-f="exam"]').value || 0;
              tr.querySelector(`[data-tot="${s.id}"]`).textContent = a + b;
            };
            tr.querySelectorAll("input").forEach(inp => { inp.oninput = upd; });
            upd();
          });
        } catch (e) { grid.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
      };
      $("#mkSave").onclick = async () => {
        const examId = +selE.value;
        if (!examId) return toast("Select exam", false);
        const byId = {};
        grid.querySelectorAll("input[data-st]").forEach(inp => {
          const id = inp.dataset.st; byId[id] = byId[id] || {};
          byId[id][inp.dataset.f] = inp.value === "" ? null : +inp.value;
        });
        let ok = 0, fail = 0;
        for (const [sid, marks] of Object.entries(byId)) {
          if (marks.internal == null && marks.exam == null) continue;
          try {
            await post("/exams/results", { exam_id: examId, student_id: +sid, internal_marks: marks.internal ?? 0, exam_marks: marks.exam ?? 0 });
            ok++;
          } catch (e) { fail++; }
        }
        toast(fail ? `Saved ${ok}, failed ${fail}` : `Saved marks for ${ok} students`, !fail);
      };
    }},
    { key: "results", label: "Results & report card", render: async (body) => {
      body.innerHTML = "";
      const bar = document.createElement("div"); bar.className = "card";
      bar.innerHTML = `<div class="tools" style="margin:0;flex-wrap:wrap;gap:8px">
        <b style="flex:1;min-width:140px">Results & report card</b>
        <select id="rcClass" style="min-width:140px"><option value="">Class</option></select>
        <select id="rcExam" style="min-width:220px;flex:1"><option value="">Exam</option></select>
        <button class="btn" type="button" id="rcLoad">View results</button>
        <button class="btn ghost" type="button" id="rcPdf">Class report PDF</button>
        <button class="btn ghost" type="button" id="rcPub">Publish results</button>
      </div>
      <p class="lbl" style="margin:8px 0 0">Select class and exam to view grades, publish, or download class report card.</p>`;
      body.appendChild(bar);
      const grid = document.createElement("div"); grid.className = "card"; body.appendChild(grid);
      let exams = [], classes = [];
      try { exams = await api("/exams"); classes = await api("/admin/classes"); } catch (e) { return errBox(body, e); }
      const selC = $("#rcClass"), selE = $("#rcExam");
      (classes || []).forEach(c => selC.add(new Option(c.name || c.label, c.id)));
      function fillExams() {
        selE.innerHTML = '<option value="">Exam</option>';
        const cid = selC.value;
        exams.filter(e => !cid || String(e.class_id) === String(cid))
          .forEach(e => selE.add(new Option(`${e.name} · ${e.subject || ""}`, e.id)));
      }
      selC.onchange = fillExams; fillExams();
      $("#rcLoad").onclick = async () => {
        if (!selE.value) return toast("Select exam", false);
        grid.innerHTML = '<div class="spin"></div>';
        try {
          const rows = await api("/exams/results?exam_id=" + selE.value);
          grid.innerHTML = "";
          if (!rows.length) { grid.innerHTML = '<div class="empty">No marks entered yet. Use Mark entry tab first.</div>'; return; }
          const avg = Math.round(rows.reduce((a, r) => a + (+r.percentage || 0), 0) / rows.length);
          const pass = rows.filter(r => r.passed || (+r.percentage || 0) >= 33).length;
          grid.appendChild(statCards({ n: rows.length, avg, pass, fail: rows.length - pass },
            [["n", "Students"], ["avg", "Average %"], ["pass", "Passed"], ["fail", "Failed"]]));
          const tbl = document.createElement("div"); tbl.className = "card";
          tbl.appendChild(table(rows, [
            ["student", "Student"], ["total", "Total"], ["percentage", "%"], ["grade", "Grade"],
            ["result", "Result"], ["published", "Published"]
          ], { noq: true, per: 50 }));
          grid.appendChild(tbl);
        } catch (e) { grid.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
      };
      $("#rcPdf").onclick = () => {
        if (!selE.value) return toast("Select exam", false);
        getPdf("/pdf/class-report-card?exam_id=" + selE.value, "class_result.pdf");
      };
      $("#rcPub").onclick = async () => {
        if (!selE.value) return toast("Select exam", false);
        try {
          await post("/exams/" + selE.value + "/publish", {});
          toast("Results published");
          $("#rcLoad").click();
        } catch (e) { toast(e.message, false); }
      };
    }},
  ], "schedule");
}

async function feesAdminPage(host) {
  await tabbedModule(host, [
    { key: "structure", label: "Fee structure", sections: [
      { title: "Fee structures", url: "/fees/heads", cols: [["name", "Fee name"], ["default_amount", "Amount ₹"], ["frequency", "Frequency"], ["applicable_classes", "Classes"]],
        form: { title: "Add fee structure", url: "/fees/heads", fields: [
          F("name", "Fee name"),
          F("default_amount", "Amount", "number"),
          F("frequency", "Frequency", "select", { list: ["Monthly", "Quarterly", "Annual", "One-time"] }),
          F("applicable_classes", "Applicable classes (comma names)"),
        ] },
        edit: { title: "Edit fee structure", url: "/fees/heads/", fields: [
          F("name", "Fee name"), F("default_amount", "Amount", "number"),
          F("frequency", "Frequency", "select", { list: ["Monthly", "Quarterly", "Annual", "One-time"] }),
          F("applicable_classes", "Applicable classes"),
        ] },
        del: "/fees/heads/", confirm: "Deactivate this fee structure?",
        charts: [{ title: "Default amounts", type: "bar", label: "name", value: "default_amount", single: true }] },
    ]},
    { key: "status", label: "Fee status", render: async (body) => {
      body.innerHTML = '<div class="spin"></div>';
      let rows = [];
      try { rows = await api("/fees/report"); } catch (e) { return errBox(body, e); }
      body.innerHTML = "";
      const tools = document.createElement("div"); tools.className = "tools";
      tools.innerHTML = `<b style="flex:1">Student fee status</b>`;
      const assign = document.createElement("button"); assign.className = "btn"; assign.textContent = "+ Assign fee";
      assign.onclick = () => modal("Assign fee to class", [
        F("class_id", "Class", "select", CL),
        F("fee_type", "Fee head", "select", sel("/fees/heads", "name", "name")),
        F("amount", "Amount", "number"), F("due_date", "Due date", "date")
      ], body => post("/fees", body));
      tools.appendChild(assign); body.appendChild(tools);
      // Stack cards by student
      const byStu = {};
      (rows || []).forEach(r => {
        const k = r.student || "Unknown";
        byStu[k] = byStu[k] || { student: k, class: r.class, items: [], total: 0, paid: 0, pending: 0 };
        byStu[k].items.push(r);
        byStu[k].total += +r.total || 0;
        byStu[k].paid += +r.paid || 0;
        byStu[k].pending += +r.pending || 0;
      });
      const grid = document.createElement("div"); grid.className = "fee-stack-grid";
      Object.values(byStu).forEach(s => {
        const card = document.createElement("div"); card.className = "card fee-stack-card";
        card.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">${esc(s.student)}</b><span class="lbl">${esc(s.class || "")}</span></div>
          <div class="fee-stack-stats">
            <div><span class="lbl">Total</span><b>₹${fmt(s.total)}</b></div>
            <div><span class="lbl">Paid</span><b style="color:var(--accent2)">₹${fmt(s.paid)}</b></div>
            <div><span class="lbl">Pending</span><b style="color:var(--danger)">₹${fmt(s.pending)}</b></div>
          </div>
          <div class="lbl" style="margin-top:8px">${s.items.length} fee line(s)</div>
          <button class="btn sm ghost" type="button" style="margin-top:8px">View details</button>`;
        card.querySelector("button").onclick = () => showDashList(s.student + " · fees", s.items, [["fee_type", "Type"], ["total", "Total"], ["paid", "Paid"], ["pending", "Pending"], ["due_date", "Due"]]);
        grid.appendChild(card);
      });
      if (!Object.keys(byStu).length) grid.innerHTML = '<div class="empty">No fee records yet. Assign a fee structure first.</div>';
      body.appendChild(grid);
      // charts below
      await section({ title: "Overview", url: "/fees/report", cols: [["student", "Student"], ["class", "Class"], ["fee_type", "Type"], ["pending", "Pending"]],
        charts: [{ title: "Collected vs pending", type: "donut", totals: { Collected: "paid", Pending: "pending" }, money: true }, { title: "Pending by class", type: "bar", label: "class", value: "pending", single: true }] }, body);
    }},
    { key: "payment", label: "Record payment", render: async (body) => {
      body.innerHTML = "";
      const form = document.createElement("div"); form.className = "card";
      form.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Record fee payment</b></div>
        <p class="lbl" style="margin:8px 0 12px">Select student → choose pending fee → enter amount & mode → save.</p>
        <div class="tools" style="flex-wrap:wrap;gap:8px;margin:0">
          <select id="payStu" style="min-width:200px;flex:1"><option value="">Select student</option></select>
          <select id="payFee" style="min-width:200px;flex:1"><option value="">Pending fee line</option></select>
          <input id="payAmt" type="number" min="1" placeholder="Amount ₹" style="width:120px">
          <select id="payMode" style="width:110px">
            <option>Cash</option><option>UPI</option><option>Card</option><option>Bank</option>
          </select>
          <button class="btn" type="button" id="payGo">Save payment</button>
        </div>
        <div id="payInfo" class="lbl" style="margin-top:10px"></div>`;
      body.appendChild(form);
      const listCard = document.createElement("div"); listCard.className = "card";
      listCard.innerHTML = `<b>Recent payments (today)</b><div id="payList" style="margin-top:10px"><div class="spin"></div></div>`;
      body.appendChild(listCard);
      let report = [];
      try { report = await api("/fees/report"); } catch (e) { toast(e.message, false); }
      const byStu = {};
      (report || []).forEach(r => {
        if ((+r.pending || 0) <= 0) return;
        const sid = r.student_id || r.student;
        const name = r.student || ("#" + sid);
        byStu[sid] = byStu[sid] || { id: r.student_id, name, class: r.class, fees: [] };
        byStu[sid].fees.push(r);
      });
      const selStu = $("#payStu"), selFee = $("#payFee"), info = $("#payInfo");
      Object.values(byStu).forEach(s => selStu.add(new Option(`${s.name} · ${s.class || ""}`, s.id || s.name)));
      // also include all students with any fee from full report
      if (!Object.keys(byStu).length) {
        (report || []).forEach(r => {
          const sid = r.student_id;
          if (!sid || selStu.querySelector(`option[value="${sid}"]`)) return;
          selStu.add(new Option(`${r.student} · ${r.class || ""}`, sid));
        });
      }
      function fillFees() {
        selFee.innerHTML = '<option value="">Pending fee line</option>';
        info.textContent = "";
        $("#payAmt").value = "";
        const key = selStu.value;
        const rows = (report || []).filter(r => String(r.student_id) === String(key) || r.student === key);
        rows.filter(r => (+r.pending || 0) > 0).forEach(r => {
          selFee.add(new Option(`${r.fee_type} · pending ₹${r.pending} (id ${r.fee_id || r.id})`, r.fee_id || r.id));
        });
        if (!selFee.options.length || selFee.options.length === 1)
          info.textContent = rows.length ? "No pending amount for this student." : "No fee lines found.";
      }
      selStu.onchange = fillFees;
      selFee.onchange = () => {
        const r = (report || []).find(x => String(x.fee_id || x.id) === String(selFee.value));
        if (r) {
          $("#payAmt").value = r.pending || r.amount || "";
          info.textContent = `${r.student || ""} · ${r.fee_type || ""} · total ₹${r.total || r.amount || 0} · paid ₹${r.paid || 0} · pending ₹${r.pending || 0}`;
        }
      };
      async function loadDaybook() {
        const box = $("#payList");
        try {
          const d = await api("/fees/daybook");
          const rows = d.payments || d || [];
          box.innerHTML = "";
          if (!rows.length) { box.innerHTML = '<div class="empty">No payments recorded today.</div>'; return; }
          box.appendChild(statCards({ total: d.total || rows.reduce((a, r) => a + (+r.amount || 0), 0), count: d.count || rows.length },
            [["total", "Collected today ₹"], ["count", "Payments"]]));
          box.appendChild(table(rows, [["paid_on", "Date"], ["student", "Student"], ["fee_type", "Type"], ["amount", "Amount"], ["mode", "Mode"]], { noq: true, per: 20 }));
        } catch (e) { box.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
      }
      $("#payGo").onclick = async () => {
        const fee_id = +selFee.value, amount = +$("#payAmt").value, mode = $("#payMode").value;
        if (!fee_id) return toast("Select a fee line", false);
        if (!amount || amount <= 0) return toast("Enter amount", false);
        try {
          await post("/fees/payment", { fee_id, amount, mode });
          toast("Payment recorded");
          report = await api("/fees/report");
          fillFees();
          loadDaybook();
        } catch (e) { toast(e.message, false); }
      };
      loadDaybook();
    }},
    { key: "report", label: "Finance report", sections: [
      { title: "Class-wise fee report", url: "/fees/class-report", cols: [["class", "Class"], ["students", "Students"], ["total", "Total ₹"], ["paid", "Collected ₹"], ["pending", "Pending ₹"]],
        charts: [{ title: "Collected by class", type: "bar", label: "class", value: "paid", single: true }, { title: "Pending by class", type: "bar", label: "class", value: "pending", single: true }] },
    ]},
  ], "structure");
}

async function academicsAdminPage(host) {
  await tabbedModule(host, [
    { key: "classes", label: "Classes & sections", render: async (body) => {
      body.innerHTML = '<div class="spin"></div>';
      let classes = [], teachers = [];
      try { classes = await api("/admin/classes"); } catch (e) { return errBox(body, e); }
      try { teachers = await api("/admin/teachers"); } catch (e) { teachers = []; }
      body.innerHTML = "";
      const tools = document.createElement("div");
      tools.className = "tools";
      tools.innerHTML = `<b style="flex:1">Classes</b>`;
      const addBtn = document.createElement("button"); addBtn.className = "btn"; addBtn.textContent = "+ Add class";
      addBtn.onclick = () => modal("Add class", [
        F("name", "Class name / grade"),
        F("capacity", "Capacity", "number"),
        F("class_teacher_id", "Class teacher", "select", sel("/admin/teachers")),
      ], body => post("/admin/classes", body));
      tools.appendChild(addBtn);
      body.appendChild(tools);
      const grid = document.createElement("div"); grid.className = "class-cards";
      for (const c of classes) {
        const card = document.createElement("div"); card.className = "class-card";
        card.innerHTML = `<h3>${esc(c.name || c.label)}</h3>
          <div class="lbl">Teacher: ${esc(c.class_teacher || "—")}</div>
          <div class="lbl">Capacity: ${esc(c.capacity ?? 40)} · Students: ${esc(c.students ?? 0)}</div>
          <div class="lbl">Sections: ${esc(c.sections || "—")}</div>
          <div class="cc-actions">
            <button class="btn sm ghost" data-a="stu">Students</button>
            <button class="btn sm ghost" data-a="sec">Sections</button>
            <button class="btn sm ghost" data-a="edit">Edit</button>
            <button class="btn sm ghost danger" data-a="del">Delete</button>
          </div>`;
        card.querySelector('[data-a="edit"]').onclick = () => modal("Edit class", [
          F("name", "Class name"), F("capacity", "Capacity", "number"),
          F("class_teacher_id", "Class teacher", "select", sel("/admin/teachers")),
        ], body => put("/admin/classes/" + c.id, body), {
          name: c.name, capacity: c.capacity, class_teacher_id: c.class_teacher_id
        });
        card.querySelector('[data-a="del"]').onclick = async () => {
          if (!confirm("Delete this class?")) return;
          try { toast((await api("/admin/classes/" + c.id, { method: "DELETE" })).message); academicsAdminPage(host); } catch (e) { toast(e.message, false); }
        };
        card.querySelector('[data-a="sec"]').onclick = async () => {
          const secs = await api("/admin/sections?class_id=" + c.id).catch(() => []);
          showDashList("Sections · " + c.name, secs, [["name", "Section"], ["id", "ID"]]);
        };
        card.querySelector('[data-a="stu"]').onclick = async () => {
          const stus = await api("/admin/classes/" + c.id + "/students").catch(() => []);
          showDashList("Students · " + c.name, stus, [["roll_no", "Roll"], ["name", "Name"], ["section", "Sec"], ["admission_no", "Adm"], ["mobile", "Mobile"]]);
        };
        grid.appendChild(card);
      }
      body.appendChild(grid);
      await section({ title: "Sections", url: "/admin/sections", cols: [["class", "Class"], ["name", "Section"]],
        form: { title: "Add Section", url: "/admin/sections", fields: [F("class_id", "Class", "select", CL), F("name", "Section")] },
        edit: { title: "Rename Section", url: "/admin/sections/", fields: [F("name", "Section")] }, del: "/admin/sections/", confirm: "Delete section?" }, body);
    }},
    { key: "subjects", label: "Subjects", render: async (body) => {
      body.innerHTML = `<div class="page-intro">Add a subject for one class, or use <b>Add to multiple classes</b> to create the same subject across classes.</div>`;
      const tools = document.createElement("div"); tools.className = "tools";
      const multi = document.createElement("button"); multi.className = "btn"; multi.textContent = "+ Add to multiple classes";
      multi.onclick = async () => {
        let classes = []; try { classes = await api("/admin/classes"); } catch (e) { }
        // Custom multi-select drawer
        document.querySelectorAll(".drawer-root").forEach(el => el.remove());
        const m = document.createElement("div"); m.className = "drawer-root on";
        m.innerHTML = `<div class="drawer-backdrop" data-c></div>
          <aside class="drawer-panel"><div class="drawer-head"><div><h3>Subject for multiple classes</h3></div>
          <button type="button" class="btn ghost sm" data-c>✕</button></div>
          <div class="drawer-body">
            <div class="drawer-field"><label>Subject name / code</label><input name="name" type="text"></div>
            <div class="drawer-field"><label>Select classes</label>
              <div class="multi-checks">${classes.map(c => `<label class="check-row"><input type="checkbox" value="${c.id}"> ${esc(c.name)}</label>`).join("") || "<span class='lbl'>No classes</span>"}</div>
            </div>
          </div>
          <div class="drawer-foot"><div style="flex:1"></div>
            <button type="button" class="btn ghost" data-c>Cancel</button>
            <button type="button" class="btn" data-s>Save</button></div></aside>`;
        document.body.appendChild(m); document.body.classList.add("drawer-open");
        const close = () => { m.remove(); document.body.classList.remove("drawer-open"); };
        m.querySelectorAll("[data-c]").forEach(b => b.onclick = close);
        m.querySelector("[data-s]").onclick = async () => {
          const name = m.querySelector("[name=name]").value.trim();
          const ids = [...m.querySelectorAll(".multi-checks input:checked")].map(c => +c.value);
          if (!name) return toast("Enter subject name", false);
          if (!ids.length) return toast("Select at least one class", false);
          let ok = 0;
          for (const id of ids) {
            try { await post("/admin/subjects", { name, class_id: id }); ok++; } catch (e) { }
          }
          toast(`Created on ${ok} class(es)`); close(); academicsAdminPage(host);
        };
      };
      tools.appendChild(multi); body.appendChild(tools);
      await section({ title: "Subjects", url: "/admin/subjects", cols: [["class", "Class"], ["name", "Subject"]],
        form: { title: "Add Subject", url: "/admin/subjects", fields: [F("class_id", "Class", "select", CL), F("name", "Subject name / code")] },
        edit: { title: "Rename Subject", url: "/admin/subjects/", fields: [F("name", "Subject")] }, del: "/admin/subjects/", confirm: "Delete subject?",
        charts: [{ title: "Subjects per class", type: "bar", by: "class", single: true }] }, body);
    }},
    { key: "alloc", label: "Teacher allocation", sections: [
      { title: "Teacher assignments", url: "/admin/teacher-subjects", cols: [["teacher", "Teacher"], ["subject", "Subject"], ["class", "Class"], ["section", "Section"]],
        form: { title: "Assign teacher", url: "/admin/teacher-subjects", fields: [F("teacher_id", "Teacher", "select", sel("/admin/teachers")), F("class_id", "Class", "select", CL), F("subject_id", "Subject", "select", SUB), F("section_id", "Section", "select", SEC)] },
        del: "/admin/teacher-subjects/", confirm: "Remove assignment?",
        charts: [{ title: "Classes per teacher", type: "bar", by: "teacher", single: true }] },
    ]},
  ], "classes");
}

async function hostelAdminPage(host) {
  await tabbedModule(host, [
    { key: "overview", label: "Overview", sections: [
      { title: "Hostel overview", url: "/hostel/dashboard", cards: [["total_students", "Hostel students"], ["total_rooms", "Rooms"], ["occupied_rooms", "Full rooms"], ["available_rooms", "Rooms with space"], ["today_present", "Present today"], ["today_absent", "Absent today"], ["pending_complaints", "Open complaints"]],
        charts: [{ key: "bed_occupancy", type: "donut", title: "Bed occupancy", sub: "beds" }, { key: "attendance_chart", type: "donut", title: "Today's hostel attendance", sub: "marked" }] },
    ]},
    { key: "rooms", label: "Rooms & beds", sections: [
      { title: "Rooms", url: "/hostel/rooms", cols: [["block", "Block"], ["floor", "Floor"], ["room_no", "Room"], ["capacity", "Beds"], ["occupied", "Occupied"], ["available", "Free"]],
        forms: [
          { title: "Add Block", url: "/hostel/blocks", fields: [F("name", "Block name"), F("floors", "Floors", "number")] },
          { title: "Add Room", url: "/hostel/rooms", fields: [F("block", "Block", "select", sel("/hostel/blocks", "name", "name")), F("floor", "Floor", "number"), F("room_no", "Room no"), F("capacity", "Bed capacity", "number")] },
        ],
        edit: { title: "Edit room", url: "/hostel/rooms/", fields: [F("room_no", "Room no"), F("capacity", "Beds", "number")] }, del: "/hostel/rooms/", confirm: "Delete room?" },
    ]},
    { key: "alloc", label: "Allocation", sections: [
      { title: "Hostel students", url: "/hostel/students", cols: [["name", "Name"], ["class", "Class"], ["mobile", "Mobile"], ["room", "Room"]],
        forms: [{ title: "Allocate bed", url: "/hostel/allocate", fields: [F("student_id", "Student", "select", sel("/hostel/students", "name", "student_id")), F("room_id", "Room", "select", sel("/hostel/rooms", "label")), F("bed_no", "Bed no", "number")] }],
        acts: [VACATE] },
    ]},
    { key: "att", label: "Attendance", render: async (body) => { await markPage(body, true); } },
    { key: "visitors", label: "Visitors & outpass", sections: [
      { title: "Outpass", url: "/hostel/outpass", cols: [["student", "Student"], ["from", "From"], ["to", "To"], ["reason", "Reason"], ["status", "Status"]],
        form: { title: "New outpass", url: "/hostel/outpass", fields: [F("student_id", "Student", "select", sel("/hostel/students", "name", "student_id")), F("from_date", "From", "date"), F("to_date", "To", "date"), F("reason", "Reason", "textarea")] } },
      hostelVisitors,
    ]},
    { key: "mess", label: "Mess menu", sections: [messCfg(true)] },
  ], "overview");
}



async function teacherWorkPage(host) {
  await tabbedModule(host, [
    { key: "assign", label: "Assignments", render: async (body) => {
      body.innerHTML = "";
      const tools = document.createElement("div"); tools.className = "tools";
      tools.innerHTML = `<b style="flex:1">Assignments & homework</b>`;
      const addA = document.createElement("button"); addA.className = "btn"; addA.textContent = "+ Assignment";
      const addH = document.createElement("button"); addH.className = "btn ghost"; addH.textContent = "+ Homework";
      tools.appendChild(addA); tools.appendChild(addH); body.appendChild(tools);
      addA.onclick = () => modal("Create assignment", [
        F("class_id", "Class", "select", sel("/teachers/subjects", "label", "class_id")),
        F("subject_id", "Subject", "select", sel("/teachers/subjects", "label")),
        F("title", "Title"), F("description", "Description", "textarea"),
        F("due_date", "Due date", "date"), F("max_marks", "Max marks", "number")
      ], async body => { await post("/assignments", body); toast("Assignment created"); teacherWorkPage(host); return {}; });
      addH.onclick = () => modal("Add homework", [
        F("class_id", "Class", "select", sel("/teachers/subjects", "label", "class_id")),
        F("subject_id", "Subject", "select", sel("/teachers/subjects", "label")),
        F("title", "Title"), F("description", "Description", "textarea"), F("due_date", "Due date", "date")
      ], async body => { await post("/homework", body); toast("Homework added"); teacherWorkPage(host); return {}; });
      await section({ title: "Assignments", url: "/assignments", cols: [["subject","Subject"],["title","Title"],["due_date","Due"],["max_marks","Max"],["submissions","Submitted"]],
        del: "/assignments/", confirm: "Delete assignment?",
        acts: [{ label: "Submissions", cls: "ghost", run: r => { location.hash = ""; sessionStorage.viewAssign = r.id; document.querySelector('.mod-tabs button[data-k="subs"]')?.click(); return false; } }]
      }, body);
      await section({ title: "Homework", url: "/homework", cols: [["subject","Subject"],["title","Title"],["due_date","Due"],["description","Details"]],
        del: "/homework/", confirm: "Delete homework?" }, body);
    }},
    { key: "subs", label: "Submissions", render: async (body) => {
      body.innerHTML = "";
      const bar = document.createElement("div"); bar.className = "card";
      bar.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Review submissions</b>
        <select id="asPick" style="max-width:280px"></select>
        <button class="btn" id="asLoad">Load</button></div>`;
      body.appendChild(bar);
      const grid = document.createElement("div"); body.appendChild(grid);
      let assigns = []; try { assigns = await api("/assignments"); } catch (e) { return errBox(body, e); }
      const sel = $("#asPick");
      assigns.forEach(a => sel.add(new Option(`${a.title} · ${a.subject||""}`, a.id)));
      if (sessionStorage.viewAssign) { sel.value = sessionStorage.viewAssign; delete sessionStorage.viewAssign; }
      async function load() {
        grid.innerHTML = '<div class="spin"></div>';
        try {
          const rows = await api("/assignments/" + sel.value + "/submissions");
          const total = rows.length;
          const graded = rows.filter(r => r.marks != null).length;
          const pending = total - graded;
          grid.innerHTML = "";
          grid.appendChild(statCards({ total, graded, pending }, [["total","Submissions"],["graded","Graded"],["pending","Pending"]]));
          const c = document.createElement("div"); c.className = "card";
          c.appendChild(table(rows, [["student","Student"],["submitted_at","Submitted"],["marks","Marks"],["feedback","Feedback"]], {
            noq: true, per: 40,
            extra: (r, td) => {
              if (r.file) {
                const d = document.createElement("button"); d.className = "btn sm ghost"; d.textContent = "File";
                d.onclick = () => window.open(API + "/files/" + r.file, "_blank");
                td.appendChild(d);
              }
              const b = document.createElement("button"); b.className = "btn sm"; b.textContent = "Review";
              b.onclick = () => modal("Review", [F("marks","Marks","number"), F("feedback","Feedback","textarea")],
                body => post("/assignments/submissions/" + r.id + "/review", body), { marks: r.marks, feedback: r.feedback });
              td.appendChild(b);
            }
          }));
          grid.appendChild(c);
        } catch (e) { grid.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
      }
      $("#asLoad").onclick = load;
      if (sel.value) load();
    }},
  ], "assign");
}

async function teacherMarksPage(host) {
  // reuse bulk mark entry pattern from examsAdmin
  host.innerHTML = "";
  const bar = document.createElement("div"); bar.className = "card";
  bar.innerHTML = `<div class="tools" style="margin:0;flex-wrap:wrap">
    <b style="flex:1">Mark entry</b>
    <select id="tmExam" style="max-width:280px"></select>
    <button class="btn" id="tmLoad">Load students</button>
    <button class="btn ghost" id="tmSave">Save all</button>
    <button class="btn ghost" id="tmPdf">Class result PDF</button>
  </div>
  <p class="lbl" style="margin:8px 0 0">Select exam → load class roster → enter marks → save. Grades are calculated automatically.</p>`;
  host.appendChild(bar);
  const grid = document.createElement("div"); grid.className = "card"; host.appendChild(grid);
  let exams = []; try { exams = await api("/exams"); } catch (e) { return errBox(host, e); }
  const sel = $("#tmExam");
  exams.forEach(e => sel.add(new Option(`${e.name} · ${e.class||""} · ${e.subject||""}`, e.id)));
  $("#tmLoad").onclick = async () => {
    const exam = exams.find(e => String(e.id) === String(sel.value));
    if (!exam) return toast("Select exam", false);
    grid.innerHTML = '<div class="spin"></div>';
    try {
      let students = await api("/teachers/students");
      students = students.filter(s => !exam.class || s.class === exam.class || String(s.class_id) === String(exam.class_id));
      let results = []; try { results = await api("/exams/results?exam_id=" + exam.id); } catch (e) {}
      const byStu = Object.fromEntries((results||[]).map(r => [String(r.student_id), r]));
      if (!students.length) { grid.innerHTML = '<div class="empty">No students for this class.</div>'; return; }
      grid.innerHTML = `<div class="scroll"><table class="att-table"><thead><tr><th>Roll</th><th>Student</th><th>Internal</th><th>Exam</th><th>Total</th></tr></thead><tbody></tbody></table></div>`;
      const tb = grid.querySelector("tbody");
      students.forEach(s => {
        const prev = byStu[String(s.id)] || {};
        const tr = document.createElement("tr");
        tr.innerHTML = `<td>${esc(s.roll_no||"")}</td><td>${esc(s.name)}</td>
          <td><input type="number" data-st="${s.id}" data-f="internal" value="${prev.internal??""}" style="width:80px"></td>
          <td><input type="number" data-st="${s.id}" data-f="exam" value="${prev.exam??""}" style="width:80px"></td>
          <td class="lbl" data-tot="${s.id}">—</td>`;
        tb.appendChild(tr);
        tr.querySelectorAll("input").forEach(inp => {
          inp.oninput = () => {
            const a = +tr.querySelector('[data-f="internal"]').value || 0;
            const b = +tr.querySelector('[data-f="exam"]').value || 0;
            tr.querySelector(`[data-tot="${s.id}"]`).textContent = a + b;
          };
          inp.oninput();
        });
      });
    } catch (e) { grid.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
  };
  $("#tmSave").onclick = async () => {
    const examId = +sel.value;
    if (!examId) return toast("Select exam", false);
    const byId = {};
    grid.querySelectorAll("input[data-st]").forEach(inp => {
      const id = inp.dataset.st; byId[id] = byId[id] || {};
      byId[id][inp.dataset.f] = inp.value === "" ? null : +inp.value;
    });
    let ok = 0, fail = 0;
    for (const [sid, marks] of Object.entries(byId)) {
      if (marks.internal == null && marks.exam == null) continue;
      try {
        await post("/exams/results", { exam_id: examId, student_id: +sid, internal_marks: marks.internal ?? 0, exam_marks: marks.exam ?? 0 });
        ok++;
      } catch (e) { fail++; }
    }
    toast(fail ? `Saved ${ok}, failed ${fail}` : `Saved ${ok} students`, !fail);
  };
  $("#tmPdf").onclick = () => {
    if (!sel.value) return toast("Select exam", false);
    getPdf("/pdf/class-report-card?exam_id=" + sel.value, "class_result.pdf");
  };
}

async function studentWorkPage(host) {
  host.innerHTML = "";
  const tools = document.createElement("div"); tools.className = "tools";
  tools.innerHTML = `<b style="flex:1">Homework & assignments</b><select id="swSub" style="max-width:200px"><option value="">All subjects</option></select>`;
  host.appendChild(tools);
  let hw = [], asg = [];
  try { hw = await api("/students/me/homework"); } catch (e) { hw = []; }
  try { asg = await api("/students/me/assignments"); } catch (e) { asg = []; }
  const subjects = [...new Set([...hw, ...asg].map(x => x.subject).filter(Boolean))];
  const sel = $("#swSub");
  subjects.forEach(s => sel.add(new Option(s, s)));
  const pending = asg.filter(a => (a.status || "").toLowerCase() !== "submitted" && a.marks == null).length;
  const submitted = asg.filter(a => (a.status || "").toLowerCase() === "submitted" || a.marks != null).length;
  host.appendChild(statCards({ pending, submitted, hw: hw.length }, [["pending","Pending"],["submitted","Submitted"],["hw","Homework items"]]));
  const grid = document.createElement("div"); grid.className = "notice-grid"; host.appendChild(grid);
  function render() {
    const filter = sel.value;
    grid.innerHTML = "";
    const items = [
      ...hw.map(h => ({ ...h, _kind: "Homework" })),
      ...asg.map(a => ({ ...a, _kind: "Assignment" })),
    ].filter(x => !filter || x.subject === filter);
    if (!items.length) { grid.innerHTML = '<div class="empty">Nothing here yet.</div>'; return; }
    items.forEach(item => {
      const card = document.createElement("div"); card.className = "notice-card card";
      const st = item.status || (item._kind === "Homework" ? "—" : "Pending");
      card.innerHTML = `<div class="tools" style="margin:0">
          <span class="badge ${item._kind==="Homework"?"b-Late":"b-Present"}">${item._kind}</span>
          <span class="badge ${String(st).toLowerCase().includes("submit")||item.marks!=null?"b-Present":"b-Absent"}">${esc(st)}</span>
        </div>
        <h3 style="margin:10px 0 4px;font-size:15px">${esc(item.title)}</h3>
        <div class="lbl">${esc(item.subject||"")} · Due ${esc(item.due_date||"—")}</div>
        <p class="lbl" style="margin-top:8px">${esc((item.description||"").slice(0,120))}</p>
        <div class="cc-actions" style="margin-top:10px"></div>`;
      const acts = card.querySelector(".cc-actions");
      if (item.file || item.file_path) {
        const b = document.createElement("button"); b.className = "btn sm ghost"; b.textContent = "Download";
        b.onclick = () => window.open(API + "/files/" + (item.file || item.file_path), "_blank");
        acts.appendChild(b);
      }
      if (item._kind === "Assignment" && item.marks == null) {
        const b = document.createElement("button"); b.className = "btn sm"; b.textContent = "Submit";
        b.onclick = () => {
          const inp = document.createElement("input"); inp.type = "file";
          inp.onchange = async () => {
            if (!inp.files[0]) return;
            const fd = new FormData(); fd.append("file", inp.files[0]);
            try {
              await api("/students/me/assignments/" + item.id + "/submit", { method: "POST", body: fd });
              toast("Submitted"); studentWorkPage(host);
            } catch (e) { toast(e.message, false); }
          };
          inp.click();
        };
        acts.appendChild(b);
      }
      if (item.marks != null) {
        acts.insertAdjacentHTML("beforeend", `<span class="lbl">Marks: ${esc(item.marks)}</span>`);
      }
      grid.appendChild(card);
    });
  }
  sel.onchange = render; render();
}

async function studentDocsPage(host) {
  host.innerHTML = "";
  const tools = document.createElement("div"); tools.className = "tools";
  tools.innerHTML = `<b style="flex:1">My documents</b>`;
  const up = document.createElement("button"); up.className = "btn"; up.textContent = "+ Upload";
  tools.appendChild(up); host.appendChild(tools);
  up.onclick = () => modal("Upload document", [
    F("doc_type", "Type", "select", { list: ["photo","aadhaar","birth_cert","marksheet","tc","other"] }),
    F("title", "Title"), F("file", "File", "file", { accept: ".pdf,.jpg,.jpeg,.png,.webp" })
  ], async body => {
    const fd = new FormData();
    Object.entries(body).forEach(([k,v]) => fd.append(k, v));
    await api("/students/me/documents", { method: "POST", body: fd });
    toast("Uploaded"); studentDocsPage(host); return {};
  });
  let rows = []; try { rows = await api("/students/me/documents"); } catch (e) { return errBox(host, e); }
  const submitted = rows.filter(r => r.status === "Verified" || r.status === "Pending").length;
  host.appendChild(statCards({ n: rows.length, submitted }, [["n","Total files"],["submitted","Submitted"]]));
  const grid = document.createElement("div"); grid.className = "notice-grid"; host.appendChild(grid);
  if (!rows.length) grid.innerHTML = '<div class="empty">No documents yet. Upload photo or certificates.</div>';
  rows.forEach(r => {
    const card = document.createElement("div"); card.className = "notice-card card";
    card.innerHTML = `<span class="badge ${r.status==="Verified"?"b-Present":r.status==="Rejected"?"b-Absent":"b-Late"}">${esc(r.status||"Pending")}</span>
      <h3 style="margin:10px 0 4px;font-size:15px">${esc(r.title||r.doc_type)}</h3>
      <div class="lbl">${esc(r.doc_type)}</div>
      <div class="cc-actions" style="margin-top:10px"></div>`;
    if (r.file_path || r.file) {
      const b = document.createElement("button"); b.className = "btn sm ghost"; b.textContent = "View";
      b.onclick = () => window.open(API + "/files/" + (r.file_path||r.file), "_blank");
      card.querySelector(".cc-actions").appendChild(b);
    }
    grid.appendChild(card);
  });
}

async function studentResultsPage(host) {
  host.innerHTML = '<div class="spin"></div>';
  let rows = []; try { rows = await api("/students/me/results"); } catch (e) { return errBox(host, e); }
  host.innerHTML = "";
  const avg = rows.length ? Math.round(rows.reduce((a,r) => a + (+r.percentage||0), 0) / rows.length) : 0;
  host.appendChild(statCards({ avg, n: rows.length }, [["avg","Overall average %"],["n","Results"]]));
  // by subject averages
  const bySub = {};
  rows.forEach(r => {
    const s = r.subject || "—";
    bySub[s] = bySub[s] || [];
    bySub[s].push(+r.percentage||0);
  });
  const subAvg = Object.fromEntries(Object.entries(bySub).map(([k,v]) => [k, Math.round(v.reduce((a,b)=>a+b,0)/v.length)]));
  if (Object.keys(subAvg).length)
    host.appendChild(chartGrid([{ key: "sub", type: "hbar", title: "Subject averages %", unit: "%", max: 100, color: pctColor }], [], { sub: subAvg }));
  const c = document.createElement("div"); c.className = "card";
  c.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Results by exam</b>
    <button class="btn sm ghost" type="button" id="rcPdf">Report card PDF</button></div>`;
  c.appendChild(table(rows, [["exam","Exam"],["subject","Subject"],["total","Total"],["percentage","%"],["grade","Grade"],["result","Result"]], { noq: true, per: 30 }));
  host.appendChild(c);
  $("#rcPdf", c).onclick = () => getPdf("/pdf/report-card", "report_card.pdf");
}

async function wardenRoomsPage(host) {
  host.innerHTML = '<div class="spin"></div>';
  let dash = {}, rooms = [];
  try { dash = await api("/hostel/dashboard"); } catch (e) {}
  try { rooms = await api("/hostel/rooms"); } catch (e) { return errBox(host, e); }
  host.innerHTML = "";
  const tools = document.createElement("div"); tools.className = "tools";
  tools.innerHTML = `<b style="flex:1">Rooms & beds</b>`;
  const addB = document.createElement("button"); addB.className = "btn ghost"; addB.textContent = "+ Block";
  const addR = document.createElement("button"); addR.className = "btn"; addR.textContent = "+ Room";
  const alloc = document.createElement("button"); alloc.className = "btn ghost"; alloc.textContent = "Allocate bed";
  tools.appendChild(addB); tools.appendChild(addR); tools.appendChild(alloc); host.appendChild(tools);
  addB.onclick = () => modal("Add block", [F("name","Block name"), F("floors","Floors","number")], body => post("/hostel/blocks", body));
  addR.onclick = () => modal("Add room", [
    F("block","Block","select", sel("/hostel/blocks","name","name")),
    F("floor","Floor","number"), F("room_no","Room no"), F("capacity","Beds","number")
  ], body => post("/hostel/rooms", body));
  alloc.onclick = () => modal("Allocate bed", [
    F("student_id","Student","select", sel("/hostel/students","name","student_id")),
    F("room_id","Room","select", sel("/hostel/rooms","label")),
    F("bed_no","Bed no","number")
  ], body => post("/hostel/allocate", body));
  // occupancy chart
  if (dash.bed_occupancy)
    host.appendChild(chartGrid([{ key: "bed_occupancy", type: "donut", title: "Beds occupied vs free", sub: "beds" }], [], dash));
  // room cards grid like bed map
  const grid = document.createElement("div"); grid.className = "class-cards"; host.appendChild(grid);
  rooms.forEach(r => {
    const card = document.createElement("div"); card.className = "class-card";
    const occ = r.occupied ?? 0, cap = r.capacity ?? 0, free = r.available ?? (cap - occ);
    card.innerHTML = `<h3>${esc(r.block||"")} · ${esc(r.room_no||r.label||"")}</h3>
      <div class="lbl">Floor ${esc(r.floor??"—")} · ${occ}/${cap} beds · ${free} free</div>
      <div class="bed-map" style="display:flex;flex-wrap:wrap;gap:4px;margin-top:8px">
        ${Array.from({length: cap}, (_,i) => `<span title="Bed ${i+1}" style="width:22px;height:22px;border-radius:6px;background:${i<occ?"var(--accent)":"var(--panel2)"};border:1px solid var(--border)"></span>`).join("")}
      </div>
      <div class="cc-actions">
        <button class="btn sm ghost" data-e>Edit</button>
        <button class="btn sm ghost danger" data-d>Delete</button>
      </div>`;
    card.querySelector("[data-e]").onclick = () => modal("Edit room", [F("room_no","Room no"), F("capacity","Beds","number")], body => put("/hostel/rooms/"+r.id, body), r);
    card.querySelector("[data-d]").onclick = async () => {
      if (!confirm("Delete room?")) return;
      try { await api("/hostel/rooms/"+r.id, { method: "DELETE" }); toast("Deleted"); wardenRoomsPage(host); } catch (e) { toast(e.message, false); }
    };
    grid.appendChild(card);
  });
  if (!rooms.length) grid.innerHTML = '<div class="empty">No rooms yet. Add a block and room.</div>';
}

async function teacherDashPage(host) {
  host.innerHTML = '<div class="spin"></div>';
  let d; try { d = await api("/teachers/dashboard"); } catch (e) { return errBox(host, e); }
  host.innerHTML = "";
  const name = d.name || localStorage.erp_name || "Teacher";
  host.insertAdjacentHTML("beforeend", `<div class="dash-welcome card"><div>
    <h1 class="dash-hello">Welcome back, ${esc(name)}</h1>
    <p class="lbl" style="margin:4px 0 0">Your teaching day at a glance</p></div>
    <span class="lbl">${new Date().toLocaleDateString("en-IN",{weekday:"short",day:"numeric",month:"short"})}</span></div>`);
  host.appendChild(statCards({
    classes: d.classes, sessions: d.today_sessions ?? (d.today_schedule||[]).length,
    pending: d.pending_homework || 0, students: d.students
  }, [["classes","Assigned classes"],["sessions","Today's sessions"],["pending","Pending to grade"],["students","Students"]]));
  // today schedule
  const sch = document.createElement("div"); sch.className = "card";
  sch.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Today's schedule</b>
    <button class="btn sm ghost" type="button" onclick="location.href='timetable.html'">Full timetable</button></div>`;
  const slots = d.today_schedule || [];
  if (!slots.length) sch.insertAdjacentHTML("beforeend", '<p class="lbl" style="margin-top:10px">No lessons scheduled today.</p>');
  else sch.appendChild(table(slots, [["time","Time"],["subject","Subject"],["class","Class"],["section","Sec"],["room","Room"]], {noq:true, per:12}));
  host.appendChild(sch);
  const bot = document.createElement("div"); bot.className = "dash-split";
  const left = document.createElement("div"); left.className = "card";
  left.innerHTML = `<b>My classes</b>`;
  left.appendChild(table(d.my_classes||[], [["label","Class (Subject)"],["students","Students"]], {noq:true, per:10}));
  const right = document.createElement("div"); right.className = "card";
  right.innerHTML = `<b>Recent notices</b>`;
  const notes = d.recent_notices || [];
  if (!notes.length) right.insertAdjacentHTML("beforeend", '<p class="lbl" style="margin-top:8px">No notices</p>');
  else notes.forEach(n => right.insertAdjacentHTML("beforeend", `<div class="activity-row"><div><b>${esc(n.title)}</b><div class="lbl">${esc(n.body||"")}</div></div><span class="lbl">${esc(n.created_at||"")}</span></div>`));
  bot.appendChild(left); bot.appendChild(right); host.appendChild(bot);
}

async function studentDashPage(host) {
  host.innerHTML = '<div class="spin"></div>';
  let d; try { d = await api("/students/me/dashboard"); } catch (e) { return errBox(host, e); }
  host.innerHTML = "";
  const name = localStorage.erp_name || "Student";
  host.insertAdjacentHTML("beforeend", `<div class="dash-welcome card"><div>
    <h1 class="dash-hello">Welcome, ${esc(name)}</h1>
    <p class="lbl" style="margin:4px 0 0">Your school overview</p></div></div>`);
  const pending = d.pending_assignments ?? d.pending ?? 0;
  const cards = document.createElement("div"); cards.className = "dash-alerts";
  function clickCard(title, val, sub, href) {
    const c = document.createElement("div"); c.className = "dash-alert card";
    c.style.cursor = "pointer";
    c.innerHTML = `<div class="da-top"><span class="lbl">${esc(title)}</span><b class="da-val">${esc(val)}</b></div>
      <p class="lbl" style="margin:6px 0 0">${esc(sub)}</p>`;
    c.onclick = () => location.href = href;
    return c;
  }
  cards.appendChild(clickCard("Pending assignments", pending, "Tap to open list", "work.html"));
  cards.appendChild(clickCard("Upcoming exams", d.upcoming_exams_count ?? (d.exams||[]).length ?? d.upcoming_exams ?? "—", "Exam schedule", "exams.html"));
  cards.appendChild(clickCard("Attendance", (d.attendance ?? d.attendance_pct ?? "—") + (typeof d.attendance === "number" ? "%" : ""), "Your rate", "attendance.html"));
  host.appendChild(cards);
  // charts attendance only
  const chartData = {
    attendance_breakdown: d.attendance_breakdown || d.attendance_chart || {},
  };
  if (Object.keys(chartData.attendance_breakdown).length)
    host.appendChild(chartGrid([{ key: "attendance_breakdown", type: "donut", title: "My attendance (days)", sub: "days" }], [], chartData));
  // notices + exams
  const bot = document.createElement("div"); bot.className = "dash-split";
  const left = document.createElement("div"); left.className = "card";
  left.innerHTML = `<b>Upcoming exams</b>`;
  left.appendChild(table(d.exams || d.upcoming_exams || [], [["name","Exam"],["subject","Subject"],["exam_date","Date"]], {noq:true, per:6}));
  const right = document.createElement("div"); right.className = "card";
  right.innerHTML = `<b>Recent notices</b>`;
  const notes = d.recent_notices || d.notices || [];
  if (!notes.length) right.insertAdjacentHTML("beforeend", '<p class="lbl" style="margin-top:8px">No recent notices</p>');
  else notes.slice(0,6).forEach(n => right.insertAdjacentHTML("beforeend", `<div class="activity-row"><div><b>${esc(n.title||n.name)}</b></div><span class="lbl">${esc(n.created_at||n.date||"")}</span></div>`));
  bot.appendChild(left); bot.appendChild(right); host.appendChild(bot);
}

async function parentDashPage(host) {
  host.innerHTML = '<div class="spin"></div>';
  let d; try { d = await api("/parents/dashboard"); } catch (e) { return errBox(host, e); }
  host.innerHTML = "";
  const name = localStorage.erp_name || "Parent";
  host.insertAdjacentHTML("beforeend", `<div class="dash-welcome card"><div>
    <h1 class="dash-hello">Welcome, ${esc(name)}</h1>
    <p class="lbl" style="margin:4px 0 0">Your child's overview</p></div></div>`);
  host.appendChild(statCards({
    att: d.attendance, fees: d.pending_fees, pending: d.pending_assignments
  }, [["att","Attendance %"],["fees","Pending fees ₹"],["pending","Pending assignments"]]));
  if (d.attendance_breakdown)
    host.appendChild(chartGrid([{ key: "attendance_breakdown", type: "donut", title: "Attendance (days)", sub: "days" }], [], d));
  const bot = document.createElement("div"); bot.className = "dash-split";
  const left = document.createElement("div"); left.className = "card";
  left.innerHTML = `<b>Upcoming exams</b>`;
  left.appendChild(table(d.exams || [], [["name","Exam"],["subject","Subject"],["exam_date","Date"]], {noq:true, per:6}));
  const right = document.createElement("div"); right.className = "card";
  right.innerHTML = `<b>Notices</b>`;
  (d.notices || d.recent_notices || []).slice(0,5).forEach(n => right.insertAdjacentHTML("beforeend", `<div class="activity-row"><b>${esc(n.title||n.name)}</b></div>`));
  bot.appendChild(left); bot.appendChild(right); host.appendChild(bot);
}

async function wardenDashPage(host) {
  host.innerHTML = '<div class="spin"></div>';
  let d; try { d = await api("/hostel/dashboard"); } catch (e) { return errBox(host, e); }
  host.innerHTML = "";
  const name = localStorage.erp_name || "Warden";
  host.insertAdjacentHTML("beforeend", `<div class="dash-welcome card"><div>
    <h1 class="dash-hello">Welcome, ${esc(name)}</h1>
    <p class="lbl" style="margin:4px 0 0">Hostel overview</p></div></div>`);
  host.appendChild(statCards({
    students: d.total_students, rooms: d.total_rooms, blocks: d.total_blocks || d.blocks || "—",
    occ: d.occupied_beds || d.occupied_rooms, free: d.available_beds || d.available_rooms,
    comp: d.pending_complaints
  }, [["students","Students"],["rooms","Total rooms"],["blocks","Blocks"],["occ","Occupied beds"],["free","Available beds"],["comp","Pending complaints"]]));
  host.appendChild(chartGrid([
    { key: "bed_occupancy", type: "donut", title: "Bed occupancy", sub: "beds" },
  ], [], d));
}

async function teacherAttPage(host) {
  await tabbedModule(host, [
    { key: "mark", label: "Mark attendance", render: async (body) => { await markPage(body, false); } },
    { key: "report", label: "Attendance reports", render: async (body) => {
      body.innerHTML = '<div class="spin"></div>';
      let d; try { d = await api("/teachers/dashboard"); } catch (e) { return errBox(body, e); }
      body.innerHTML = "";
      const low = d.low_attendance || [];
      const buckets = d.attendance_buckets || {};
      body.appendChild(statCards({
        low: low.length,
        avg: Object.keys(buckets).length ? "—" : "—",
        days: "—"
      }, [["low","Below 75%"],["avg","Class average"],["days","School days"]]));
      const c = document.createElement("div"); c.className = "card";
      c.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Students below 75%</b>
        <button class="btn sm ghost" type="button" id="expCsv">Export CSV</button></div>`;
      c.appendChild(table(low, [["name","Name"],["class","Class"],["attendance","Att %"]], {noq:true, per:30}));
      body.appendChild(c);
      $("#expCsv", c).onclick = () => downloadCSV("low_attendance", [["name","Name"],["class","Class"],["attendance","Att %"]], low);
      if (Object.keys(buckets).length)
        body.appendChild(chartGrid([{ key: "attendance_buckets", type: "donut", title: "Attendance distribution", sub: "students" }], [], d));
    }},
  ], "mark");
}

async function portalSettingsPage(host) {
  host.innerHTML = "";
  const head = document.createElement("div"); head.className = "card";
  head.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1;font-family:var(--font-heading);font-size:17px">Settings</b></div>
    <div class="settings-tabs" id="pstabs">
      <button type="button" data-tab="profile" class="on">Profile</button>
      <button type="button" data-tab="account">Account</button>
      <button type="button" data-tab="display">Theme & display</button>
    </div>`;
  host.appendChild(head);
  const panels = document.createElement("div"); host.appendChild(panels);
  // Profile
  const profile = document.createElement("div"); profile.className = "settings-panel on card"; profile.dataset.tab = "profile";
  profile.innerHTML = `<b>Profile</b><p class="lbl">Signed in as <b>${esc(localStorage.erp_name||"")}</b> · Role: <b>${esc(ROLE)}</b></p>
    <div class="profile-kv" style="margin-top:12px">
      <b>Name</b><span>${esc(localStorage.erp_name||"—")}</span>
      <b>School</b><span>${esc(localStorage.school_name||"—")}</span>
      <b>Code</b><span>${esc(localStorage.school_code||"—")}</span>
    </div>
    <div id="childBox" style="margin-top:14px"></div>`;
  panels.appendChild(profile);
  if (ROLE === "parent") {
    (async () => {
      try {
        const d = await api("/parents/dashboard");
        const box = $("#childBox", profile);
        box.innerHTML = `<b>Linked student</b>
          <div class="profile-kv" style="margin-top:8px">
            <b>Child</b><span>${esc(d.child_name||d.student||d.name||"—")}</span>
            <b>Class</b><span>${esc(d.class||d.child_class||"—")}</span>
            <b>Attendance</b><span>${esc(d.attendance??"—")}%</span>
            <b>Pending fees</b><span>₹${esc(d.pending_fees??0)}</span>
          </div>`;
      } catch (e) {}
    })();
  }
  if (ROLE === "student") {
    (async () => {
      try {
        const d = await api("/students/me/profile");
        const s = d.details || d;
        const box = $("#childBox", profile);
        box.innerHTML = `<b>Student details</b>
          <div class="profile-kv" style="margin-top:8px">
            <b>Admission</b><span>${esc(s.admission_no||"—")}</span>
            <b>Class</b><span>${esc(s.class||"—")} – ${esc(s.section||"")}</span>
            <b>Roll</b><span>${esc(s.roll_no??"—")}</span>
            <b>Mobile</b><span>${esc(s.mobile||"—")}</span>
          </div>`;
      } catch (e) {}
    })();
  }
  // Account
  const account = document.createElement("div"); account.className = "settings-panel card"; account.dataset.tab = "account";
  account.innerHTML = `<b>Account</b><p class="lbl">Session is stored in this browser. Logout clears your token.</p>
    <button class="btn danger" type="button" id="pLogout">Logout</button>`;
  panels.appendChild(account);
  $("#pLogout", account).onclick = logout;
  // Display
  const display = document.createElement("div"); display.className = "settings-panel card"; display.dataset.tab = "display";
  const theme = localStorage.theme || "light";
  const accent = localStorage.accent || "orange";
  display.innerHTML = `<b>Theme & display</b>
    <div class="tools" style="margin-top:12px">
      <button class="btn ${theme==="light"?"":"ghost"}" id="thL">☀ Light</button>
      <button class="btn ${theme==="dark"?"":"ghost"}" id="thD">🌙 Dark</button>
    </div>
    <p class="lbl" style="margin:14px 0 8px">Primary colour</p>
    <div class="tools">
      <button class="btn ${accent==="orange"?"":"ghost"}" data-a="orange">Orange</button>
      <button class="btn ${accent==="blue"?"":"ghost"}" data-a="blue">Blue</button>
      <button class="btn ${accent==="green"?"":"ghost"}" data-a="green">Green</button>
    </div>`;
  panels.appendChild(display);
  const applyA = (key) => {
    localStorage.accent = key;
    const map = { orange:["#D95F0C","#C75609"], blue:["#2563eb","#1d4ed8"], green:["#059669","#047857"] };
    const [a,h] = map[key]||map.orange;
    document.documentElement.style.setProperty("--accent", a);
    document.documentElement.style.setProperty("--accent-hover", h);
    document.documentElement.style.setProperty("--pri", a);
    portalSettingsPage(host);
  };
  $("#thL", display).onclick = () => { localStorage.theme="light"; document.documentElement.dataset.theme="light"; portalSettingsPage(host); };
  $("#thD", display).onclick = () => { localStorage.theme="dark"; document.documentElement.dataset.theme="dark"; portalSettingsPage(host); };
  display.querySelectorAll("[data-a]").forEach(b => b.onclick = () => applyA(b.dataset.a));
  head.querySelectorAll("[data-tab]").forEach(btn => {
    btn.onclick = () => {
      head.querySelectorAll("[data-tab]").forEach(b => b.classList.toggle("on", b===btn));
      panels.querySelectorAll(".settings-panel").forEach(p => p.classList.toggle("on", p.dataset.tab===btn.dataset.tab));
    };
  });
}

async function portalNoticesPage(host) {
  host.innerHTML = "";
  const grid = document.createElement("div"); grid.className = "notice-grid"; host.appendChild(grid);
  grid.innerHTML = '<div class="spin"></div>';
  let notices = [];
  try { notices = await api("/notifications/notices"); } catch (e) {
    try { notices = await api("/students/me/notices"); } catch (e2) { notices = []; }
  }
  grid.innerHTML = "";
  if (!notices.length) { grid.innerHTML = '<div class="empty">No notices yet.</div>'; return; }
  notices.forEach(n => {
    const card = document.createElement("div"); card.className = "notice-card card";
    card.innerHTML = `<span class="badge b-Present">Notice</span>
      <h3 style="margin:10px 0 6px;font-size:15px">${esc(n.title||n.name)}</h3>
      <p class="lbl">${esc((n.body||n.content||"").slice(0,180))}</p>
      <div class="lbl" style="margin-top:8px">${esc(n.created_at||n.date||"")}</div>`;
    grid.appendChild(card);
  });
}

async function adminDashboardPage(host) {
  host.innerHTML = '<div class="spin"></div>';
  let d;
  try { d = await api("/admin/dashboard"); } catch (e) { return errBox(host, e); }
  host.innerHTML = "";
  const name = localStorage.erp_name || "Admin";
  const school = localStorage.school_name || "School ERP";

  // Welcome
  const welcome = document.createElement("div");
  welcome.className = "dash-welcome card";
  welcome.innerHTML = `<div>
      <h1 class="dash-hello">Welcome back, ${esc(name)}</h1>
      <p class="lbl" style="margin:4px 0 0">${esc(school)} · Admin overview</p>
    </div>
    <div class="dash-welcome-meta">
      <span class="badge b-Present">Live</span>
      <span class="lbl">${new Date().toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short", year: "numeric" })}</span>
    </div>`;
  host.appendChild(welcome);

  // Primary stats (4 only)
  host.appendChild(statCards({
    total_students: d.total_students,
    total_teachers: d.total_teachers,
    attendance_rate: d.attendance_rate,
    fee_collected_month: d.fee_collected_month,
    fee_collected_year: d.fee_collected_year,
  }, [
    ["total_students", "Total students"],
    ["total_teachers", "Total teachers"],
    ["attendance_rate", "Attendance rate %"],
    ["fee_collected_month", "Fee collection (month) ₹"],
    ["fee_collected_year", "Fee collection (year) ₹"],
  ]));

  // Quick actions (reference-style)
  const qa = document.createElement("div");
  qa.className = "dash-actions";
  const actions = [
    { l: "Students", href: "students.html", ico: "🎓" },
    { l: "Record payment", href: "fees.html", ico: "💰" },
    { l: "Post notice", href: "notices.html", ico: "📢" },
    { l: "Exams", href: "exams.html", ico: "📝" },
  ];
  actions.forEach(a => {
    const b = document.createElement("button");
    b.className = "dash-action-btn";
    b.innerHTML = `<span class="da-ico">${a.ico}</span><span>${a.l}</span>`;
    b.onclick = () => location.href = a.href;
    qa.appendChild(b);
  });
  host.appendChild(qa);

  // Alert row: low attendance / unpaid / pending docs
  const alerts = document.createElement("div");
  alerts.className = "dash-alerts";
  const lowN = d.low_attendance_count ?? (d.low_attendance || []).length;
  const unpaid = d.pending_fees || 0;
  const docN = d.pending_documents_count || 0;
  function alertCard(title, value, sub, onView) {
    const c = document.createElement("div");
    c.className = "dash-alert card";
    c.innerHTML = `<div class="da-top"><span class="lbl">${esc(title)}</span><b class="da-val">${esc(value)}</b></div>
      <p class="lbl" style="margin:6px 0 10px">${esc(sub)}</p>
      <button type="button" class="btn sm ghost">View list</button>`;
    c.querySelector("button").onclick = onView;
    return c;
  }
  alerts.appendChild(alertCard("Below 75% attendance", lowN, "Students needing attention", () => showDashList("Low attendance", d.low_attendance || [], [["name", "Name"], ["class", "Class"], ["section", "Sec"], ["attendance", "Att %"]])));
  alerts.appendChild(alertCard("Unpaid fee balance", "₹" + fmt(unpaid), "Outstanding across students", () => showDashList("Pending fees", d.pending_fees_list || [], [["student", "Student"], ["class", "Class"], ["fee_type", "Type"], ["due", "Due ₹"], ["due_date", "Due date"]])));
  alerts.appendChild(alertCard("Pending documents", docN, "Photos & files to verify", () => { location.href = "documents.html"; }));
  host.appendChild(alerts);

  // Pending fees preview table
  if ((d.pending_fees_list || []).length) {
    const feeCard = document.createElement("div");
    feeCard.className = "card";
    feeCard.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Pending fee review</b>
      <button class="btn sm ghost" type="button" id="allFees">Open fees</button></div>`;
    feeCard.appendChild(table((d.pending_fees_list || []).slice(0, 8), [["student", "Student"], ["class", "Class"], ["fee_type", "Type"], ["due", "Due ₹"], ["due_date", "Due"]], { noq: true, per: 8 }));
    host.appendChild(feeCard);
    $("#allFees", feeCard).onclick = () => location.href = "fees.html";
  }

  // Charts grid (reference set)
  const chartSpecs = [
    { key: "weekly_attendance", type: "line", title: "Weekly attendance %", unit: "%", max: 100 },
    { key: "fee_by_month", type: "bar", title: "Monthly collection ₹", money: true, single: true },
    { key: "student_status", type: "donut", title: "Student status", sub: "students" },
    { key: "attendance_chart", type: "donut", title: "Attendance distribution", sub: "today" },
    { key: "grade_distribution", type: "donut", title: "Grade distribution", sub: "results" },
    { key: "students_by_class", type: "bar", title: "Students per class", single: true },
  ];
  // Ensure keys exist
  d.student_status = d.student_status || { Active: d.active_students || d.total_students || 0, Inactive: d.inactive_students || 0 };
  d.grade_distribution = d.grade_distribution || {};
  // Attendance distribution fallback from rate if today empty
  const ac = d.attendance_chart || {};
  const acSum = Object.values(ac).reduce((a, v) => a + (+v || 0), 0);
  if (!acSum) {
    const present = d.today_present || 0, absent = d.today_absent || 0;
    if (present || absent) d.attendance_chart = { Present: present, Absent: absent };
    else if (d.total_students && d.attendance_rate != null) {
      const p = Math.round((d.total_students * d.attendance_rate) / 100);
      d.attendance_chart = { Present: p, Absent: Math.max(0, d.total_students - p) };
    }
  }
  host.appendChild(chartGrid(chartSpecs, [], d));

  // Bottom: recent activity + upcoming exams
  const bottom = document.createElement("div");
  bottom.className = "dash-split";
  const left = document.createElement("div");
  left.className = "card";
  left.innerHTML = `<b>Recent activity</b>`;
  const acts = d.recent_activity || [];
  if (!acts.length) left.insertAdjacentHTML("beforeend", '<p class="lbl" style="margin-top:10px">No recent activity logged.</p>');
  else {
    const ul = document.createElement("div");
    ul.className = "activity-list";
    acts.forEach(a => {
      ul.insertAdjacentHTML("beforeend", `<div class="activity-row"><div><b>${esc(a.action)}</b><div class="lbl">${esc(a.detail)}</div></div><span class="lbl">${esc(a.at)}</span></div>`);
    });
    left.appendChild(ul);
  }
  const right = document.createElement("div");
  right.className = "card";
  right.innerHTML = `<b>Upcoming exams</b>`;
  right.appendChild(table(d.upcoming_exams || [], [["name", "Exam"], ["subject", "Subject"], ["class", "Class"], ["exam_date", "Date"]], { noq: true, per: 6 }));
  bottom.appendChild(left);
  bottom.appendChild(right);
  host.appendChild(bottom);
}

function showDashList(title, rows, cols) {
  const m = document.createElement("div");
  m.className = "drawer-root on";
  m.innerHTML = `<div class="drawer-backdrop" data-c></div>
    <aside class="drawer-panel" style="width:min(520px,100vw)">
      <div class="drawer-head"><div><h3>${esc(title)}</h3><p class="lbl" style="margin:4px 0 0">${rows.length} record(s)</p></div>
        <button type="button" class="btn ghost sm" data-c>✕</button></div>
      <div class="drawer-body" data-b></div>
      <div class="drawer-foot"><div style="flex:1"></div><button type="button" class="btn ghost" data-c>Close</button></div>
    </aside>`;
  document.body.appendChild(m);
  document.body.classList.add("drawer-open");
  const close = () => { m.remove(); document.body.classList.remove("drawer-open"); };
  m.querySelectorAll("[data-c]").forEach(b => b.onclick = close);
  const body = m.querySelector("[data-b]");
  if (!rows.length) body.innerHTML = '<div class="empty">No records</div>';
  else body.appendChild(table(rows, cols, { noq: true, per: 15 }));
}

async function documentsPage(host) {
  host.innerHTML = "";
  const head = document.createElement("div"); head.className = "card";
  head.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1;font-family:var(--font-heading);font-size:17px">Student documents</b>
    <span class="lbl">Verify or reject uploads</span></div>
    <div class="settings-tabs" id="docTabs">
      <button type="button" data-s="All" class="on">All</button>
      <button type="button" data-s="Pending">Pending</button>
      <button type="button" data-s="Verified">Verified</button>
      <button type="button" data-s="Rejected">Rejected</button>
    </div>`;
  host.appendChild(head);
  const stats = document.createElement("div"); stats.className = "stats-slot"; host.appendChild(stats);
  const body = document.createElement("div"); body.className = "card"; host.appendChild(body);
  let all = [], tab = "All";

  async function load() {
    body.innerHTML = '<div class="spin"></div>';
    try {
      all = await api("/admin/documents");
      const counts = { All: all.length, Pending: 0, Verified: 0, Rejected: 0 };
      all.forEach(r => { if (counts[r.status] != null) counts[r.status]++; });
      stats.innerHTML = "";
      stats.appendChild(statCards(counts, [["All", "All"], ["Pending", "Pending"], ["Verified", "Verified"], ["Rejected", "Rejected"]]));
      // update tab labels with counts
      head.querySelectorAll("[data-s]").forEach(b => {
        const s = b.dataset.s;
        b.textContent = s === "All" ? `All (${counts.All})` : `${s} (${counts[s] || 0})`;
      });
      draw();
    } catch (e) { body.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
  }

  function draw() {
    const rows = tab === "All" ? all : all.filter(r => r.status === tab);
    body.innerHTML = "";
    if (!rows.length) {
      body.innerHTML = '<div class="empty">No documents in this filter.</div>';
      return;
    }
    body.appendChild(table(rows, [
      ["student", "Student"], ["admission_no", "Adm No"], ["class", "Class"],
      ["doc_type", "Type"], ["title", "Title"], ["status", "Status"], ["uploaded_at", "Uploaded"]
    ], {
      extra: (r, td) => {
        const add = (label, cls, fn) => { const b = document.createElement("button"); b.className = "btn sm " + cls; b.textContent = label; b.onclick = fn; td.appendChild(b); };
        if (r.file_path || r.file) {
          add("Preview", "ghost", async () => {
            const path = r.file_path || r.file;
            try {
              const res = await fetch(API + "/files/" + path, { headers: { Authorization: "Bearer " + localStorage.erp_token } });
              if (!res.ok) return toast("Cannot open file", false);
              const blob = await res.blob();
              const url = URL.createObjectURL(blob);
              modal2("Document · " + (r.title || r.doc_type), `<p class="lbl">${esc(r.student)} · ${esc(r.doc_type)} · ${esc(r.status)}</p>
                ${blob.type.startsWith("image/") ? `<img src="${url}" style="max-width:100%;border-radius:8px;margin-top:8px">` : `<p><a class="btn" href="${url}" target="_blank" rel="noopener">Open / download file</a></p>`}`);
            } catch (e) { toast(e.message, false); }
          });
        }
        if (r.status === "Pending" || r.status === "Rejected") {
          add("Verify", "ok", async () => {
            try { toast((await post("/admin/documents/" + r.id + "/verify?status=Verified", {})).message); load(); }
            catch (e) { toast(e.message, false); }
          });
        }
        if (r.status === "Pending" || r.status === "Verified") {
          add("Reject", "danger", () => {
            modal("Reject document", [F("remarks", "Rejection reason", "textarea")], async body => {
              const q = "status=Rejected&remarks=" + encodeURIComponent(body.remarks || "");
              const res = await post("/admin/documents/" + r.id + "/verify?" + q, {});
              toast(res.message); load();
              return res;
            });
          });
        }
      }
    }));
  }

  head.querySelectorAll("[data-s]").forEach(b => {
    b.onclick = () => {
      tab = b.dataset.s;
      head.querySelectorAll("[data-s]").forEach(x => x.classList.toggle("on", x === b));
      draw();
    };
  });
  load();
}

async function settingsPage(host) {
  host.innerHTML = '<div class="spin"></div>';
  let d;
  try { d = await api("/admin/settings"); } catch (e) { return errBox(host, e); }
  host.innerHTML = "";

  const head = document.createElement("div");
  head.className = "card";
  head.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1;font-family:var(--font-heading);font-size:18px">Settings</b>
    <span class="lbl">School profile, alerts, theme and security</span></div>
    <div class="settings-tabs" id="stabs">
      <button type="button" data-tab="school" class="on">School profile</button>
      <button type="button" data-tab="alerts">Alerts</button>
      <button type="button" data-tab="display">Display</button>
      <button type="button" data-tab="years">Academic years</button>
      <button type="button" data-tab="grading">Grading system</button>
      <button type="button" data-tab="promotion">Year-end promotion</button>
      <button type="button" data-tab="security">Security</button>
    </div>`;
  host.appendChild(head);

  const panels = document.createElement("div"); host.appendChild(panels);

  // School profile
  const school = document.createElement("div"); school.className = "settings-panel on card"; school.dataset.tab = "school";
  const labels = { school_name: "School name", address: "Address", phone: "Phone", email: "Email" };
  school.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">School profile</b>
    <button class="btn" id="sedit">Edit</button></div>
    ${Object.entries(labels).map(([k, l]) => `<div class="bar"><b style="width:180px">${l}</b><span>${esc(d[k] || "—")}</span></div>`).join("")}
    <p class="lbl" style="margin-top:10px">School name appears on receipts, report cards and the sidebar after login.</p>`;
  panels.appendChild(school);
  $("#sedit", school).onclick = () => modal("School profile", Object.entries(labels).map(([k, l]) => F(k, l)), body => put("/admin/settings", Object.fromEntries(Object.entries(body).filter(([, v]) => v !== null))), d);

  // Alerts
  const alerts = document.createElement("div"); alerts.className = "settings-panel card"; alerts.dataset.tab = "alerts";
  alerts.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Attendance alert</b>
    <button class="btn" id="aedit">Edit</button></div>
    <div class="bar"><b style="width:220px">Low attendance below (%)</b><span>${esc(d.low_attendance ?? "75")}</span></div>
    <p class="lbl" style="margin-top:10px">Students under this percentage appear in Low Attendance lists and dashboard alerts.</p>`;
  panels.appendChild(alerts);
  $("#aedit", alerts).onclick = () => modal("Attendance alert", [F("low_attendance", "Low attendance below (%)", "number")], body => put("/admin/settings", body), { low_attendance: d.low_attendance });

  // Display
  const display = document.createElement("div"); display.className = "settings-panel card"; display.dataset.tab = "display";
  const theme = localStorage.theme || "light";
  const accent = localStorage.accent || "orange";
  display.innerHTML = `<b>Display preferences</b>
    <p class="lbl">Theme and primary colour for this browser.</p>
    <div class="tools" style="margin-top:12px">
      <button class="btn ${theme === "light" ? "" : "ghost"}" id="thLight">☀ Light</button>
      <button class="btn ${theme === "dark" ? "" : "ghost"}" id="thDark">🌙 Dark</button>
    </div>
    <p class="lbl" style="margin:14px 0 8px">Primary colour</p>
    <div class="tools">
      <button class="btn ${accent==="orange"?"":"ghost"}" id="accOrange" type="button">Orange</button>
      <button class="btn ${accent==="blue"?"":"ghost"}" id="accBlue" type="button">Blue</button>
      <button class="btn ${accent==="green"?"":"ghost"}" id="accGreen" type="button">Green</button>
    </div>`;
  panels.appendChild(display);
  const applyAccent = (key) => {
    localStorage.accent = key;
    const map = { orange: ["#D95F0C","#C75609"], blue: ["#2563eb","#1d4ed8"], green: ["#059669","#047857"] };
    const [a,h] = map[key] || map.orange;
    document.documentElement.style.setProperty("--accent", a);
    document.documentElement.style.setProperty("--accent-hover", h);
    document.documentElement.style.setProperty("--pri", a);
    settingsPage(host);
  };
  $("#thLight", display).onclick = () => { localStorage.theme = "light"; document.documentElement.dataset.theme = "light"; settingsPage(host); };
  $("#thDark", display).onclick = () => { localStorage.theme = "dark"; document.documentElement.dataset.theme = "dark"; settingsPage(host); };
  $("#accOrange", display).onclick = () => applyAccent("orange");
  $("#accBlue", display).onclick = () => applyAccent("blue");
  $("#accGreen", display).onclick = () => applyAccent("green");
  // apply saved accent on open
  if (accent !== "orange") {
    const map = { blue: ["#2563eb","#1d4ed8"], green: ["#059669","#047857"] };
    if (map[accent]) {
      document.documentElement.style.setProperty("--accent", map[accent][0]);
      document.documentElement.style.setProperty("--accent-hover", map[accent][1]);
      document.documentElement.style.setProperty("--pri", map[accent][0]);
    }
  }

  // Academic years
  const years = document.createElement("div"); years.className = "settings-panel card"; years.dataset.tab = "years";
  years.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Academic years</b>
    <button class="btn sm" type="button" id="addYear">+ Add year</button></div>
    <div id="yearList" style="margin-top:10px"><div class="spin"></div></div>`;
  panels.appendChild(years);
  async function loadYears() {
    const box = $("#yearList", years);
    try {
      const rows = await api("/admin/academic-years");
      if (!rows.length) { box.innerHTML = '<div class="empty">No academic years yet.</div>'; return; }
      box.innerHTML = "";
      box.appendChild(table(rows, [["name", "Year"], ["is_current", "Current"]], {
        noq: true, per: 20,
        extra: (r, td) => {
          if (r.is_current === true || r.is_current === "true" || r.is_current === 1) {
            td.insertAdjacentHTML("beforeend", '<span class="badge b-Present">Current</span>');
          } else {
            const b = document.createElement("button"); b.className = "btn sm"; b.textContent = "Make current";
            b.onclick = async () => { try { toast((await post("/admin/academic-years/" + r.id + "/activate", {})).message); loadYears(); } catch (e) { toast(e.message, false); } };
            td.appendChild(b);
          }
        }
      }));
    } catch (e) { box.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`; }
  }
  loadYears();
  $("#addYear", years).onclick = () => modal("Add academic year", [F("name", "Year (e.g. 2025-26)")], async body => {
    await post("/admin/academic-years", body); toast("Year added"); loadYears(); return {};
  });

  // Grading
  const grading = document.createElement("div"); grading.className = "settings-panel card"; grading.dataset.tab = "grading";
  grading.innerHTML = `<b>Grading system</b>
    <p class="lbl">Default grade bands used on report cards and results (percentage → grade).</p>
    <div class="scroll" style="margin-top:10px"><table class="att-table"><thead><tr><th>Grade</th><th>From %</th><th>To %</th></tr></thead>
    <tbody>
      <tr><td>A+</td><td>90</td><td>100</td></tr>
      <tr><td>A</td><td>80</td><td>89</td></tr>
      <tr><td>B+</td><td>70</td><td>79</td></tr>
      <tr><td>B</td><td>60</td><td>69</td></tr>
      <tr><td>C</td><td>50</td><td>59</td></tr>
      <tr><td>D</td><td>40</td><td>49</td></tr>
      <tr><td>F</td><td>0</td><td>39</td></tr>
    </tbody></table></div>
    <p class="lbl" style="margin-top:10px">Pass mark: <b>40%</b>. Grades are applied automatically when marks are saved.</p>`;
  panels.appendChild(grading);

  // Promotion
  const promo = document.createElement("div"); promo.className = "settings-panel card"; promo.dataset.tab = "promotion";
  promo.innerHTML = `<b>Year-end promotion</b><p class="lbl">Promote students class-by-class at the end of the year. Enter the new academic year only on the first class.</p>
    <button class="btn" type="button" id="openPromo">Open promotion tool</button>`;
  panels.appendChild(promo);
  $("#openPromo", promo).onclick = () => {
    promo.innerHTML = "";
    promotionPage(promo);
  };

  // Security
  const security = document.createElement("div"); security.className = "settings-panel card"; security.dataset.tab = "security";
  security.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Security</b>
    <button class="btn" id="spw">Change password</button></div>
    <p class="lbl">Admin password must be at least 8 characters with a letter and a number. OTP rules are configured in the server <code>.env</code>.</p>`;
  panels.appendChild(security);
  $("#spw", security).onclick = () => modal("Change password", [
    F("old_password", "Current password", "password"),
    F("new_password", "New password", "password"),
    F("confirm", "Repeat new password", "password")
  ], async body => {
    if (body.new_password !== body.confirm) throw new Error("The two new passwords do not match");
    return post("/admin/change-password", { old_password: body.old_password, new_password: body.new_password });
  });

  // Tab switching
  head.querySelectorAll("[data-tab]").forEach(btn => {
    btn.onclick = () => {
      head.querySelectorAll("[data-tab]").forEach(b => b.classList.toggle("on", b === btn));
      panels.querySelectorAll(".settings-panel").forEach(p => p.classList.toggle("on", p.dataset.tab === btn.dataset.tab));
    };
  });
}


async function usersAccessPage(host) {
  host.innerHTML = "";
  const head = document.createElement("div");
  head.className = "card";
  head.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Users &amp; Access</b>
    <span class="lbl">Manage accounts and which modules each role can open</span></div>`;
  host.appendChild(head);

  // Charts + table from users API
  const statsSlot = document.createElement("div"); statsSlot.className = "stats-slot"; host.appendChild(statsSlot);
  const chartsSlot = document.createElement("div"); chartsSlot.className = "charts-slot"; host.appendChild(chartsSlot);
  const tableCard = document.createElement("div"); tableCard.className = "card"; host.appendChild(tableCard);
  tableCard.innerHTML = "<b>All users</b><div class=\"spin\"></div>";

  try {
    const rows = await api("/admin/users");
    const byRole = {}, byStatus = {};
    rows.forEach(r => {
      byRole[r.role] = (byRole[r.role] || 0) + 1;
      byStatus[r.status] = (byStatus[r.status] || 0) + 1;
    });
    chartsSlot.innerHTML = "";
    const g = document.createElement("div"); g.className = "chart-grid";
    if (typeof donut === "function") {
      g.appendChild(donut(byRole, "Users by role", { sub: "users" }));
      g.appendChild(donut(byStatus, "Active vs inactive", { sub: "users" }));
    }
    chartsSlot.appendChild(g);

    tableCard.innerHTML = "<b>All users (" + rows.length + ")</b>";
    const acts = [
      { label: "Deactivate", cls: "ghost danger", show: r => r.status === "Active" && r.role !== "admin",
        confirm: "Deactivate this user?", run: async r => { await post("/admin/users/" + r.id + "/deactivate", {}); toast("Deactivated"); usersAccessPage(host); } },
      { label: "Re-activate", show: r => r.status === "Inactive",
        run: async r => { await post("/admin/users/" + r.id + "/activate", {}); toast("Activated"); usersAccessPage(host); } },
    ];
    tableCard.appendChild(table(rows, [["name","Name"],["role","Role"],["mobile","Mobile"],["email","Email"],["status","Status"],["created","Created"]], acts));
  } catch (e) {
    tableCard.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`;
  }

  // Role matrix below
  const matrixHost = document.createElement("div"); host.appendChild(matrixHost);
  await roleMatrixPage(matrixHost);
}

async function roleMatrixPage(host) {
  host.innerHTML = '<div class="spin"></div>';
  let access;
  try { access = await api("/admin/role-access"); } catch (e) { return errBox(host, e); }
  const modules = {
    admin: MENU.admin.map(x => x[0]),
    teacher: MENU.teacher.map(x => x[0]),
    student: MENU.student.map(x => x[0]),
    parent: MENU.parent.map(x => x[0]),
    warden: MENU.warden.map(x => x[0]),
  };
  host.innerHTML = "";
  const card = document.createElement("div"); card.className = "card section";
  card.innerHTML = "<h2>Role → module access</h2><p class='lbl'>Tick modules each role can open. Admin always has full access.</p>";
  host.appendChild(card);
  const wrap = document.createElement("div"); wrap.className = "scroll"; card.appendChild(wrap);
  const roles = ["teacher", "student", "parent", "warden"];
  roles.forEach(role => {
    const box = document.createElement("div"); box.style.marginBottom = "14px";
    box.innerHTML = `<b style="text-transform:capitalize">${role}</b>`;
    const allowed = new Set(access[role] || []);
    (modules[role] || []).forEach(mod => {
      const id = `ra_${role}_${mod}`;
      const lab = document.createElement("label"); lab.style.display = "inline-flex"; lab.style.alignItems = "center"; lab.style.gap = "6px"; lab.style.margin = "4px 10px 4px 0";
      const cb = document.createElement("input"); cb.type = "checkbox"; cb.id = id; cb.checked = allowed.has(mod) || allowed.has("*");
      cb.dataset.role = role; cb.dataset.mod = mod;
      lab.appendChild(cb); lab.appendChild(document.createTextNode(mod));
      box.appendChild(lab);
    });
    wrap.appendChild(box);
  });
  const btn = document.createElement("button"); btn.className = "btn"; btn.textContent = "Save access matrix";
  btn.onclick = async () => {
    const out = { admin: ["*"] };
    roles.forEach(role => {
      out[role] = [...wrap.querySelectorAll(`input[data-role="${role}"]`)].filter(c => c.checked).map(c => c.dataset.mod);
    });
    try { toast((await post("/admin/role-access", out)).message); } catch (e) { toast(e.message, false); }
  };
  card.appendChild(btn);
}

const PAGE_INTRO = {
  admin: {
    fees: "Workflow: create <b>Fee Heads</b> → <b>Add Fee</b> for a class → <b>Record payment</b> using Fee ID from the report → check Daybook & class report.",
    hostel: "Setup order: <b>1. Add Block</b> → <b>2. Add Room</b> (block + floor + beds) → <b>3. Allocate Bed</b> to a student.",
    timetable: "Select <b>class</b> and <b>section</b>. Click any cell in the full-week grid to choose <b>subject</b> and <b>teacher</b> (and room). Click a filled cell to edit or delete.",
    exams: "Create an exam, then enter marks per subject. Grades (A+…F) are calculated automatically.",
    promotion: "Promote class-by-class at year end. Enter the new academic year only on the <b>first</b> class; leave empty for the rest.",
    attendance: "Filter by class, review charts, and use <b>Correct attendance</b> if a past day needs fixing.",
    documents: "Verify or reject student-uploaded documents (photo, Aadhaar, marksheet, etc.).",
    students: "Search, open a student profile for attendance, results, fees, hostel and report card PDF.",
  },
  teacher: {
    attendance: "Select your class, mark Present / Absent / Late / Leave for each student, then Save.",
    work: "Add homework or assignments. On Assignments, use <b>Review</b> to open submissions, score them and leave feedback.",
    exams: "Create an exam, then use <b>Enter Marks</b> for each student. <b>Publish results</b> when ready so students and parents can see grades.",
    materials: "Upload study material files for your subjects. Students download from Study Material.",
    students: "Students in your assigned classes with attendance % and quick insights.",
  },
  warden: {
    rooms: "Blocks → Rooms → Allocate beds. Vacate when a student leaves the hostel.",
    attendance: "Mark hostel attendance for today. Absent students appear on the dashboard.",
    outpass: "Approve or reject outpass requests from hostel students.",
    visitors: "Log visitor check-in / check-out for hostel students.",
    students: "Students currently living in the hostel with room allocation.",
    mess: "Weekly mess menu — edit any day as needed.",
  },
  student: {
    work: "Submit homework and assignments before the due date. Use <b>Upload</b> on an assignment row. Check marks and feedback after teacher review.",
    documents: "Upload photo, Aadhaar, marksheet, etc. Admin will verify or reject with remarks.",
    outpass: "Request an outpass when you need to leave the hostel. Wait for warden approval.",
    fees: "View pending fees and payment history. Contact the office for payment issues.",
    results: "Published results with grades. Download your report card PDF when available.",
    timetable: "Weekly grid of your class periods (Mon–Sat).",
  },
  parent: {
    fees: "Track your child’s fee status and payment history.",
    attendance: "Monitor daily attendance. Contact the school if something looks wrong.",
    results: "Published exam results and grades for your child.",
    work: "Homework and assignment status for your child.",
    timetable: "Weekly class schedule for your child.",
  },
};

async function render() {
  const cfg = (PAGES[ROLE] || {})[PAGE]; const host = $("#content"); host.innerHTML = "";
  if (!cfg) {
    host.innerHTML = `<div class="empty">Page "${esc(PAGE)}" is not configured for this role.</div>`;
    return;
  }
  const intro = (PAGE_INTRO[ROLE] || {})[PAGE];
  if (intro) host.insertAdjacentHTML("beforeend", `<div class="page-intro">${intro}</div>`);
  if (cfg.roleMatrix) return roleMatrixPage(host);
  if (cfg.dash) return dashboard(cfg, host);
  if (cfg.custom) return custom(cfg.custom, host);
  if (cfg.upload_form) return materialsPage(host);
  if (cfg.sections) for (const s of cfg.sections) s.custom ? await custom(s.custom, host) : await section(s, host); else await section(cfg, host);
}

function renderTimetableGrid(rows, opts = {}) {
  const days = opts.days || ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const times = opts.times || [...new Set(rows.map(r => r.time || ((r.start_time || "") + "-" + (r.end_time || ""))))].filter(Boolean)
    .sort((a, b) => a.localeCompare(b));
  const title = opts.title || "Weekly timetable (Mon – Sat)";
  const editable = !!opts.editable;
  if (!times.length) return `<div class="card"><div class="tt-head"><h2>${esc(title)}</h2></div><div class="empty">No period slots yet. Choose class & section, then click a cell to add subject and teacher.</div></div>`;
  let html = `<div class="card tt-wrap"><div class="tt-head"><h2>${esc(title)}</h2><span class="lbl">${times.length} periods · ${days.length} days${editable ? " · click a cell to edit" : ""}</span></div><div class="scroll"><div class="tt-grid"><div class="h">Time</div>`;
  days.forEach(d => html += `<div class="h">${d.slice(0, 3)}</div>`);
  times.forEach(tm => {
    html += `<div class="h">${esc(tm)}</div>`;
    days.forEach(d => {
      const cell = rows.find(r => r.day === d && (r.time === tm || ((r.start_time || "") + "-" + (r.end_time || "")) === tm));
      const [st, et] = tm.split("-");
      if (cell) {
        html += `<div class="cell filled${editable ? " clickable" : ""}" data-id="${cell.id || ""}" data-day="${esc(d)}" data-start="${esc(cell.start_time || st)}" data-end="${esc(cell.end_time || et)}" data-subject="${cell.subject_id || ""}" data-teacher="${cell.teacher_id || ""}" data-room="${esc(cell.room || "")}" title="${esc(cell.subject || "")} · ${esc(cell.teacher || "")}">
          <div class="sub">${esc(cell.subject || "")}</div>
          <div class="meta">${esc(cell.class_name ? (cell.class_name + (cell.section_name ? "-" + cell.section_name : "")) : (cell.teacher || ""))}</div>
          <div class="meta room">${esc(cell.class_name ? (cell.teacher || cell.room || "") : (cell.room || ""))}</div>
        </div>`;
      } else {
        html += `<div class="cell empty-cell${editable ? " clickable" : ""}" data-day="${esc(d)}" data-start="${esc(st || "")}" data-end="${esc(et || "")}" title="Click to add period"><div class="add-hint">+</div></div>`;
      }
    });
  });
  html += `</div></div></div>`;
  return html;
}

/** Default school-day period slots used when a class has few/no entries yet */
const DEFAULT_TT_SLOTS = [
  "08:00-08:45", "08:45-09:30", "09:30-10:15", "10:30-11:15",
  "11:15-12:00", "12:00-12:45", "13:30-14:15", "14:15-15:00"
];

async function timetablePage(host) {
  host.innerHTML = "";
  const canEdit = ROLE === "admin" || ROLE === "teacher";
  const bar = document.createElement("div"); bar.className = "card";
  const isTeacherRole = ROLE === "teacher";
  bar.innerHTML = `<div class="tools" style="margin:0;flex-wrap:wrap">
    <b style="flex:1;min-width:120px">Weekly timetable</b>
    ${(canEdit || isTeacherRole) ? `<div class="settings-tabs" id="ttView" style="margin:0">
      <button type="button" data-v="class" class="on">Class timetable</button>
      ${isTeacherRole || ROLE === "admin" ? '<button type="button" data-v="teacher">My / Teacher view</button>' : ""}
    </div>` : ""}
    <span id="ttClassWrap"><label class="lbl" style="margin:0">Class</label>
    <select id="ttClass" style="max-width:180px"></select>
    <label class="lbl" style="margin:0">Section</label>
    <select id="ttSec" style="max-width:120px"></select></span>
    <span id="ttTeacherWrap" style="display:none"><label class="lbl" style="margin:0">Teacher</label>
    <select id="ttTeacher" style="max-width:220px"></select></span>
    <button class="btn" type="button" id="ttLoad">Show</button>
    <button class="btn ghost" type="button" id="ttPrint">Print</button>
    ${canEdit ? '<button class="btn ghost" type="button" id="ttAdd">+ Add period</button>' : ""}
  </div>
  <p class="lbl" style="margin:10px 0 0" id="ttHint">${canEdit
    ? "Select <b>class</b> and <b>section</b>. Click any cell to set <b>subject</b>, <b>teacher</b> and <b>room</b>."
    : "Your weekly schedule (Mon–Sat)."}</p>`;
  host.appendChild(bar);
  const gridHost = document.createElement("div"); host.appendChild(gridHost);
  const tableHost = document.createElement("div"); tableHost.className = "card"; host.appendChild(tableHost);

  let classes = [];
  try { classes = await api("/admin/classes"); } catch (e) {
    try { classes = await api("/teachers/me/classes"); } catch (e2) { return errBox(host, e); }
  }
  const clsSel = $("#ttClass");
  classes.forEach(c => clsSel.add(new Option(c.name || c.label, c.id || c.class_id)));
  const c8 = classes.find(c => /8/.test(c.name || c.label || ""));
  if (c8) clsSel.value = c8.id || c8.class_id;

  let ttMode = "class"; // class | teacher
  let teachers = [];
  try { teachers = await api("/admin/teachers"); } catch (e) { teachers = []; }
  const tSel = $("#ttTeacher");
  if (tSel) {
    teachers.forEach(x => tSel.add(new Option(x.name || x.label, x.id)));
    if (ROLE === "teacher") {
      // Prefer current user's teacher id if present
      try {
        const me = await api("/auth/me");
        const match = teachers.find(x => x.user_id === me.id || x.name === me.name);
        if (match) tSel.value = match.id;
      } catch (e) { }
    }
  }
  const viewTabs = $("#ttView");
  if (viewTabs) {
    viewTabs.querySelectorAll("[data-v]").forEach(btn => {
      btn.onclick = () => {
        ttMode = btn.dataset.v;
        viewTabs.querySelectorAll("[data-v]").forEach(b => b.classList.toggle("on", b === btn));
        const showClass = ttMode === "class";
        $("#ttClassWrap").style.display = showClass ? "" : "none";
        $("#ttTeacherWrap").style.display = showClass ? "none" : "";
        $("#ttHint").innerHTML = showClass
          ? (canEdit ? "Select <b>class</b> and <b>section</b>. Click any cell to set subject, teacher and room." : "Class weekly schedule.")
          : "Teacher view — periods this teacher teaches across classes (Mon–Sat).";
        if (ROLE === "teacher" && ttMode === "teacher") {
          // auto
        }
        loadTT();
      };
    });
    if (ROLE === "teacher") {
      // default could stay class; teacher can switch
    }
  }

  async function loadSections() {
    const cid = +clsSel.value;
    const secSel = $("#ttSec"); secSel.innerHTML = "";
    let secs = [];
    try { secs = await api("/admin/sections?class_id=" + cid); } catch (e) {
      try { secs = (await api("/admin/sections")).filter(s => s.class_id === cid); } catch (e2) { secs = []; }
    }
    secs.forEach(s => secSel.add(new Option(s.name || s.label, s.id)));
    if (!secSel.options.length) secSel.add(new Option("—", ""));
  }

  function openCellEditor(cell) {
    if (!canEdit) return;
    const cid = +clsSel.value;
    const sid = +$("#ttSec").value || null;
    if (!cid) return toast("Select a class first", false);
    const isEdit = !!cell.dataset.id;
    const day = cell.dataset.day;
    const start = cell.dataset.start;
    const end = cell.dataset.end;
    const fields = [
      F("subject_id", "Subject", "select", SUB),
      F("teacher_id", "Teacher", "select", sel("/admin/teachers")),
      F("room", "Room (e.g. R101)"),
      F("start_time", "Start (HH:MM)"),
      F("end_time", "End (HH:MM)"),
    ];
    const values = {
      subject_id: cell.dataset.subject || "",
      teacher_id: cell.dataset.teacher || "",
      room: cell.dataset.room || "",
      start_time: start || "",
      end_time: end || "",
    };
    const extra = isEdit ? {
      label: "Delete period",
      onClick: async (close) => {
        if (!confirm("Remove this period from the timetable?")) return;
        try {
          await api("/timetable/" + cell.dataset.id, { method: "DELETE" });
          toast("Period removed"); close(); loadTT();
        } catch (e) { toast(e.message, false); }
      }
    } : null;
    modal(isEdit ? `Edit · ${day} ${start}-${end}` : `Add · ${day} ${start}-${end}`, fields, async body => {
      const payload = {
        class_id: cid,
        section_id: sid || null,
        subject_id: +body.subject_id,
        teacher_id: body.teacher_id ? +body.teacher_id : null,
        room: body.room || null,
        day,
        start_time: body.start_time || start,
        end_time: body.end_time || end,
      };
      if (!payload.subject_id) throw new Error("Select a subject");
      if (!payload.start_time || !payload.end_time) throw new Error("Start and end time required");
      if (isEdit) {
        await put("/timetable/" + cell.dataset.id, payload);
        toast("Period updated");
      } else {
        await post("/timetable", payload);
        toast("Period added");
      }
      loadTT();
    }, values, extra);
  }

  async function loadTT() {
    gridHost.innerHTML = '<div class="spin"></div>';
    tableHost.innerHTML = "";
    try {
      let rows = [];
      let title = "";
      let editable = canEdit;
      if (ttMode === "teacher") {
        const tid = $("#ttTeacher")?.value;
        if (!tid) { gridHost.innerHTML = '<div class="empty">Select a teacher to view their timetable.</div>'; return; }
        // fetch all visible and filter by teacher_id client-side
        rows = await api("/timetable");
        rows = rows.filter(r => String(r.teacher_id) === String(tid));
        const tname = $("#ttTeacher").selectedOptions[0]?.text || "Teacher";
        title = `${tname} · Teaching schedule`;
        editable = false; // edit from class view
      } else {
        const cid = clsSel.value;
        const sid = $("#ttSec").value;
        let url = "/timetable?class_id=" + cid;
        if (sid) url += "&section_id=" + sid;
        rows = await api(url);
        const cname = clsSel.selectedOptions[0]?.text || "Class";
        const sname = $("#ttSec").selectedOptions[0]?.text || "";
        title = `${cname}${sname ? " – " + sname : ""} · Full week`;
      }
      const existing = [...new Set(rows.map(r => r.time || (r.start_time + "-" + r.end_time)).filter(Boolean))];
      const times = [...new Set([...DEFAULT_TT_SLOTS, ...existing])].sort((a, b) => a.localeCompare(b));
      // In teacher view show class name in cell meta
      if (ttMode === "teacher") {
        rows = rows.map(r => ({ ...r, teacher: r.teacher, subject: r.subject, room: r.room, _classLabel: true }));
      }
      gridHost.innerHTML = renderTimetableGrid(rows, {
        title,
        times,
        editable: editable && ttMode === "class",
      });
      gridHost.querySelectorAll(".cell.clickable").forEach(el => {
        el.onclick = () => openCellEditor(el);
      });
      if (rows.length) {
        tableHost.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Period list</b><span class="lbl">${rows.length} entries</span></div>`;
        const opts = canEdit ? {
          extra: (r, td) => {
            const e = document.createElement("button"); e.className = "btn sm ghost"; e.textContent = "Edit";
            e.onclick = () => {
              const fake = document.createElement("div");
              fake.dataset.id = r.id; fake.dataset.day = r.day;
              fake.dataset.start = r.start_time; fake.dataset.end = r.end_time;
              fake.dataset.subject = r.subject_id || ""; fake.dataset.teacher = r.teacher_id || "";
              fake.dataset.room = r.room || "";
              openCellEditor(fake);
            };
            const d = document.createElement("button"); d.className = "btn sm ghost danger"; d.textContent = "Delete";
            d.onclick = async () => {
              if (!confirm("Remove this period?")) return;
              try { await api("/timetable/" + r.id, { method: "DELETE" }); toast("Removed"); loadTT(); }
              catch (err) { toast(err.message, false); }
            };
            td.appendChild(e); td.appendChild(d);
          }
        } : {};
        tableHost.appendChild(table(rows, [["day", "Day"], ["time", "Time"], ["subject", "Subject"], ["teacher", "Teacher"], ["room", "Room"]], opts));
      } else {
        tableHost.innerHTML = `<div class="empty">No periods saved yet for this class/section. Click empty cells in the grid above to add subject and teacher for each day and time.</div>`;
      }
    } catch (e) {
      gridHost.innerHTML = `<p style="color:var(--bad)">${esc(e.message)}</p>`;
    }
  }

  clsSel.onchange = async () => { await loadSections(); await loadTT(); };
  $("#ttSec").onchange = loadTT;
  if ($("#ttTeacher")) $("#ttTeacher").onchange = loadTT;
  $("#ttLoad").onclick = loadTT;
  $("#ttPrint").onclick = () => {
    const w = window.open("", "_blank");
    w.document.write(`<html><head><title>Timetable</title><style>body{font-family:sans-serif;padding:16px} table{border-collapse:collapse;width:100%} td,th{border:1px solid #ccc;padding:6px;font-size:12px}</style></head><body>`);
    w.document.write(document.getElementById("content")?.querySelector(".tt-wrap")?.outerHTML || "<p>No timetable loaded</p>");
    w.document.write("</body></html>");
    w.document.close(); w.focus(); w.print();
  };
  const addBtn = $("#ttAdd");
  if (addBtn) addBtn.onclick = () => {
    const fields = [
      F("class_id", "Class", "select", CL), F("section_id", "Section", "select", SEC),
      F("subject_id", "Subject", "select", SUB), F("teacher_id", "Teacher", "select", sel("/admin/teachers")),
      F("day", "Day", "select", { list: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] }),
      F("start_time", "Start (HH:MM)"), F("end_time", "End (HH:MM)"), F("room", "Room (e.g. R101)"),
    ];
    modal("Add period", fields, async body => {
      body.class_id = body.class_id || +clsSel.value;
      body.section_id = body.section_id || +$("#ttSec").value || null;
      await post("/timetable", body);
      toast("Period added");
      loadTT();
    }, { class_id: clsSel.value, section_id: $("#ttSec").value });
  };

  await loadSections();
  await loadTT();
}




function ensureChartJs() {
  if (window.Chart) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js";
    s.onload = resolve; s.onerror = () => resolve(); // fail soft – SVG charts still work
    document.head.appendChild(s);
  });
}
function applySavedAccent() {
  const accent = localStorage.accent || "orange";
  const map = { orange: ["#D95F0C","#C75609"], blue: ["#2563eb","#1d4ed8"], green: ["#059669","#047857"] };
  const [a,h] = map[accent] || map.orange;
  document.documentElement.style.setProperty("--accent", a);
  document.documentElement.style.setProperty("--accent-hover", h);
  document.documentElement.style.setProperty("--pri", a);
}

async function messGridPage(host, editable) {
  host.innerHTML = '<div class="spin"></div>';
  let rows = [];
  try { rows = await api("/hostel/mess"); } catch (e) { return errBox(host, e); }
  host.innerHTML = "";
  const head = document.createElement("div"); head.className = "card";
  head.innerHTML = `<div class="tools" style="margin:0"><b style="flex:1">Weekly mess menu</b>
    ${editable ? '<span class="lbl">Click a meal cell to edit</span>' : '<span class="lbl">This week\'s menu</span>'}
  </div>`;
  host.appendChild(head);
  const days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
  const meals = ["Breakfast","Lunch","Snacks","Dinner"];
  const byDay = {};
  (rows || []).forEach(r => { byDay[r.day || r.name] = r; });
  const card = document.createElement("div"); card.className = "card";
  let html = `<div class="scroll"><table class="att-table mess-grid"><thead><tr><th>Day</th>${meals.map(m=>`<th>${m}</th>`).join("")}</tr></thead><tbody>`;
  days.forEach(day => {
    const r = byDay[day] || {};
    html += `<tr><td><b>${day}</b></td>`;
    meals.forEach(meal => {
      const val = r[meal] || r[meal.toLowerCase()] || "—";
      if (editable) {
        html += `<td class="mess-cell" data-day="${esc(day)}" data-meal="${esc(meal)}" title="Click to edit">${esc(val)}</td>`;
      } else {
        html += `<td>${esc(val)}</td>`;
      }
    });
    html += `</tr>`;
  });
  html += `</tbody></table></div>`;
  card.innerHTML = html;
  host.appendChild(card);
  if (editable) {
    card.querySelectorAll(".mess-cell").forEach(td => {
      td.style.cursor = "pointer";
      td.onclick = async () => {
        const day = td.dataset.day, meal = td.dataset.meal;
        const cur = td.textContent === "—" ? "" : td.textContent;
        const v = prompt(`${day} · ${meal}`, cur);
        if (v == null) return;
        try {
          // load full day row then put
          const row = byDay[day] || { day };
          const payload = { Breakfast: row.Breakfast || row.breakfast || "", Lunch: row.Lunch || row.lunch || "", Snacks: row.Snacks || row.snacks || "", Dinner: row.Dinner || row.dinner || "" };
          payload[meal] = v;
          if (row.id) await put("/hostel/mess/" + row.id, payload);
          else await post("/hostel/mess", { day, ...payload });
          toast("Menu updated");
          messGridPage(host, true);
        } catch (e) { toast(e.message, false); }
      };
    });
  }
}

function shell() {
  ensureChartJs();
  applySavedAccent();
  const tk = localStorage.getItem("erp_token");
  if (!tk || localStorage.getItem("erp_role") !== ROLE) return logout();
  document.documentElement.dataset.theme = localStorage.theme || "light";
  // Keep hostel flag & school name fresh
  api("/auth/me").then(me => {
    if (!me) return;
    if ("is_hostel" in me) localStorage.is_hostel = me.is_hostel ? "1" : "0";
    if (me.school_name) localStorage.school_name = me.school_name;
    if (me.school_code) localStorage.school_code = me.school_code;
  }).catch(() => {});
  const HOSTEL_ONLY = new Set(["outpass", "mess"]);
  const isHostelUser = () => localStorage.is_hostel === "1" || ROLE === "warden" || ROLE === "admin";
  const menuItems = (MENU[ROLE] || []).filter(([p]) => {
    if ((ROLE === "student" || ROLE === "parent") && HOSTEL_ONLY.has(p) && !isHostelUser()) return false;
    return true;
  });
  if ((ROLE === "student" || ROLE === "parent") && HOSTEL_ONLY.has(PAGE) && !isHostelUser()) {
    location.replace("dashboard.html");
    return;
  }
  const pc = (PAGES[ROLE] || {})[PAGE] || {};
  const title = (menuItems.find(x => x[0] === PAGE) || (MENU[ROLE] || []).find(x => x[0] === PAGE) || [])[1] || pc.title || "";
  const brandName = localStorage.school_name || localStorage.getItem("school_name") || "School ERP";
  const NAV_SECTIONS = {
    admin: {
      "Main": ["dashboard"],
      "People": ["students", "documents", "teachers", "parents", "wardens"],
      "Academics": ["classes", "attendance", "exams", "timetable"],
      "Finance": ["fees"],
      "Hostel": ["hostel"],
      "Communication": ["notices", "complaints"],
      "System": ["reports", "users", "audit", "settings"],
    }
  };
  function buildNav() {
    const items = menuItems;
    const sections = NAV_SECTIONS[ROLE];
    if (!sections) {
      return items.map(([p, l]) => {
        const label = l.replace(/^\S+\s/, "");
        const ico = NAV_ICON[p] || DEFAULT_NAV_ICON;
        return `<a href="${p}.html" class="${p === PAGE || p === pc.parent ? "active" : ""}" title="${esc(label)}"><span class="nav-icon">${ico}</span> <span class="nav-label">${esc(label)}</span></a>`;
      }).join("");
    }
    const byKey = Object.fromEntries(items.map(x => [x[0], x]));
    let html = "";
    for (const [sec, keys] of Object.entries(sections)) {
      html += `<div class="nav-section">${esc(sec)}</div>`;
      for (const k of keys) {
        const row = byKey[k]; if (!row) continue;
        const [p, l] = row;
        const label = l.replace(/^\S+\s/, "");
        const ico = NAV_ICON[p] || DEFAULT_NAV_ICON;
        html += `<a href="${p}.html" class="${p === PAGE || p === pc.parent ? "active" : ""}" title="${esc(label)}"><span class="nav-icon">${ico}</span> <span class="nav-label">${esc(label)}</span></a>`;
      }
    }
    return html;
  }
  const navLinks = buildNav();
  document.body.innerHTML = `<div class="layout anim-shell"><aside class="sidebar" id="sb"><div class="brand" id="brand"><span class="brand-icon">${NAV_ICON.classes || DEFAULT_NAV_ICON}</span> <span class="brand-text">${esc(brandName)}</span></div>${localStorage.school_code ? `<div class="scode">${esc(localStorage.school_code)}</div>` : ""}${navLinks}</aside>
  <div class="main"><div class="top"><button class="btn ghost sm" id="mb" title="Toggle menu">☰</button><h2>${title}</h2>${ROLE === "admin" ? '<div class="gs"><input id="gs" placeholder="Search students, teachers, parents…" autocomplete="off"><div id="gsr"></div></div>' : ""}<span class="lbl" style="font-weight:600;color:var(--text2)">${esc(localStorage.erp_name || "")}</span><button class="btn ghost sm" id="bell" title="Notifications">🔔</button><button class="btn ghost sm" id="th" title="Toggle theme">🌓</button><button class="btn sm" id="lo">Logout</button></div><div class="content" id="content"></div></div></div>
  <button class="btn" id="aiBtn" title="AI Assistant">🤖</button><div id="aiPanel"><div style="padding:12px 14px;border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:8px"><b style="flex:1">AI Assistant</b><span id="aiMode" class="badge">…</span></div><div id="aiLog"><div class="msg a">Hi ${esc(localStorage.erp_name || "")}! Ask me about your school data — tap a suggestion or type a question.</div></div><div class="chips" id="aiChips"></div><div style="display:flex;gap:8px;padding:10px 12px;border-top:1px solid var(--bd)"><input id="aiIn" autocomplete="off" placeholder="Type a question…"><button class="btn" id="aiSend">Send</button></div></div>`;
  document.title = brandName + " · " + title;
  if (localStorage.sb_collapsed === "1") $("#sb").classList.add("collapsed");
  api("/auth/me").then(me => {
    if (me.school_name) {
      localStorage.school_name = me.school_name;
      const bt = document.querySelector(".brand-text"); if (bt) bt.textContent = me.school_name;
      document.title = me.school_name + " · " + title;
    }
    if (me.school_code) {
      localStorage.school_code = me.school_code;
      let sc = document.querySelector(".scode");
      if (!sc) { sc = document.createElement("div"); sc.className = "scode"; $("#sb").insertBefore(sc, $("#sb").children[1] || null); }
      sc.textContent = me.school_code;
    }
    if (me.school_id) localStorage.school_id = me.school_id;
  }).catch(() => { });
  if (ROLE === "admin") {
    const gs = $("#gs"), box = $("#gsr"); let timer, seq = 0;
    const close = () => { box.style.display = "none"; };
    gs.addEventListener("input", () => { clearTimeout(timer); const v = gs.value.trim(); if (v.length < 2) return close();
      timer = setTimeout(async () => { const my = ++seq; try { const res = await api("/admin/search?q=" + encodeURIComponent(v)); if (my !== seq) return;
        box.innerHTML = res.length ? res.map(x => `<a href="${esc(x.url)}"><span class="badge">${esc(x.type)}</span><b>${esc(x.title)}</b><small>${esc(x.sub)}</small></a>`).join("") : '<div class="none">No matches</div>'; box.style.display = "block"; } catch (e) { close(); } }, 250); });
    gs.addEventListener("keydown", e => { if (e.key === "Escape") { gs.value = ""; close(); } if (e.key === "Enter") { const a = box.querySelector("a"); if (a) location.href = a.getAttribute("href"); } });
    document.addEventListener("click", e => { if (!e.target.closest(".gs")) close(); });
  }
  $("#lo").onclick = logout;
  $("#mb").onclick = () => {
    const sb = $("#sb");
    if (window.innerWidth <= 800) {
      sb.classList.toggle("open");
    } else {
      sb.classList.toggle("collapsed");
      localStorage.sb_collapsed = sb.classList.contains("collapsed") ? "1" : "0";
    }
  };
  $("#th").onclick = () => { const t = document.documentElement.dataset.theme === "dark" ? "light" : "dark"; document.documentElement.dataset.theme = t; localStorage.theme = t; };
  $("#bell").onclick = async () => { const n = await api("/notifications/my"); modal2("Notifications", n.map(x => `<div class="card" style="margin:6px 0"><b>${esc(x.title)}</b><div class="lbl">${esc(x.message || "")}</div></div>`).join("") || "None"); };
  const TIPS = { admin: ["How many students are absent today?", "Students below 75% attendance", "Pending fees", "Generate report"], student: ["My attendance", "Make a 7 day study plan", "My weak subjects", "Pending assignments"],
    teacher: ["Generate 5 MCQ for Class 8 Science", "Class attendance analysis", "Lesson plan for Maths", "Homework ideas for English"], parent: ["My child's attendance", "Pending fees", "How is my child doing?"], warden: ["Available rooms", "Absent students today", "Complaint summary"] };
  const setMode = (mode, note, label) => { const b = $("#aiMode"); b.textContent = mode === "online" ? "🟢 " + (label || "AI") : "🟠 Offline mode"; b.title = note || ""; b.className = "badge " + (mode === "online" ? "b-Present" : "b-Pending"); };
  let conv = null, loaded = false;
  $("#aiBtn").onclick = async () => { $("#aiPanel").classList.toggle("on"); if (!loaded) { loaded = true; try { const st = await api("/ai/status"); setMode(st.mode, st.note, st.label); } catch (e) { setMode("offline", "Could not check AI status"); } } };
  const md = t => esc(t).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>").replace(/^[-*] /gm, "• ");
  const send = async () => { const i = $("#aiIn"), t = i.value.trim(); if (!t) return; i.value = ""; const log = $("#aiLog"); log.insertAdjacentHTML("beforeend", `<div class="msg u">${esc(t)}</div>`); const w = document.createElement("div"); w.className = "msg a"; w.textContent = "…"; log.appendChild(w);
    try { const r = await post("/ai/chat", { message: t, conversation_id: conv }); conv = r.conversation_id; w.innerHTML = md(r.reply) + (r.note && !/^Offline mode/.test(r.note) ? `<div class="lbl" style="margin-top:6px">⚠ ${esc(r.note)}</div>` : ""); setMode(r.mode, r.note, r.label); } catch (e) { w.textContent = e.message; } log.scrollTop = 1e6; };
  (TIPS[ROLE] || []).forEach(t => { const b = document.createElement("button"); b.textContent = t; b.onclick = () => { $("#aiIn").value = t; send(); }; $("#aiChips").appendChild(b); });
  $("#aiSend").onclick = send;
  $("#aiIn").addEventListener("keydown", e => { if (e.key === "Enter" && !e.isComposing) { e.preventDefault(); send(); } });   // NOTE: never return false from a keydown handler - it blocks typing
  render();
}
function modal2(t, html) { const m = document.createElement("div"); m.className = "modal on"; m.innerHTML = `<div class="box"><h3 style="margin-top:0">${t}</h3>${html}<br><button class="btn ghost" data-c>Close</button></div>`; document.body.appendChild(m); m.querySelector("[data-c]").onclick = () => m.remove(); }
if (typeof ROLE !== "undefined") shell();
