# School ERP – Full Setup Guide (Windows + XAMPP)

## Requirements
- XAMPP (MySQL running)
- Python **3.12 64-bit** (not 32-bit)

```powershell
py -0p
python -c "import struct; print(struct.calcsize('P')*8, 'bit')"
```

## 1. Extract
Unzip to `C:\xampp\htdocs\school_erp`

## 2. Database
phpMyAdmin → SQL:

```sql
DROP DATABASE IF EXISTS school_erp;
CREATE DATABASE school_erp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Leave empty — do **not** import old schema.sql.

## 3. Environment
```powershell
cd C:\xampp\htdocs\school_erp\backend
copy .env.example .env
```

Edit `.env` for XAMPP (empty password):

```env
DATABASE_URL=mysql+pymysql://root:@localhost:3306/school_erp
SECRET_KEY=school-erp-local-dev-secret-key-change-in-production
OTP_PROVIDER=console
DEV_FIXED_OTP=123456
```

## 4. Install
```powershell
Remove-Item -Recurse -Force venv -ErrorAction SilentlyContinue
py -3.12 -m venv venv
.\venv\Scripts\activate
python -c "import struct; print(struct.calcsize('P')*8, 'bit')"
pip install -r requirements.txt
python seed.py
```

Success message includes: `Seeded successfully!` and counts (30 students, 12 teachers…).

## 5. Run
```powershell
uvicorn app.main:app --reload --port 8000
```

Open **http://localhost:8000**

## Demo logins (OTP = 123456)
| Role | Login | Password |
|------|-------|----------|
| Admin | admin@school.com | Admin@123 + OTP |
| Teacher | 9000000011 | OTP |
| Student | 9100000001 | OTP |
| Parent | 9200000001 | OTP |
| Warden | 9300000001 | OTP |

School code: **SCH-DEMO1**

## Features
- Multi-school registration + landing
- Collapsible admin sidebar, school name/code
- Dashboard: stats, charts, calendar, pending fees, exams
- Students (address), Teachers (qualification/experience/class)
- Documents: student upload + admin verify/reject
- Fees: daybook + class report
- Exams & Tests (type, section, time, auto-grade A+…F)
- Hostel: block / floor / room / bed capacity + allocation
- Homework & Assignments merged menus
- Attendance, timetable, notices, events, mess, complaints, AI, PDFs
- Rich seed data for demo views

## Email OTP (optional)
```env
OTP_PROVIDER=email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your.email@gmail.com
SMTP_PASSWORD=gmail_app_password_16_chars
SMTP_FROM=your.email@gmail.com
```
Gmail: enable 2FA → App passwords (not normal password).

## AI Assistant (optional)
```env
AI_PROVIDER=gemini
AI_API_KEY=AIza_...
AI_MODEL=gemini-1.5-flash
```
Or Groq / Ollama — see `.env.example`.

## Reseed
```sql
DROP DATABASE IF EXISTS school_erp;
CREATE DATABASE school_erp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
```powershell
python seed.py
```

## Common errors
| Error | Fix |
|-------|-----|
| Unknown column school_id | DROP + recreate DB, seed again |
| Access denied root password | Use `root:@localhost` (empty password) in DATABASE_URL |
| greenlet / C++ | Use 64-bit Python |
| Dashboard 500 filter/limit | Use latest zip (already fixed) |
| documents.html 404 | Use latest zip |

## Project layout
```
school_erp/
  frontend/     HTML/CSS/JS portals
  backend/      FastAPI API + seed.py
  HOW_TO_RUN.md
  README.md
```

## New in this build
- **Hostel flow**: Add Block → Add Room (select block + floor) → Allocate bed
- **Custom fee heads**: Fees → Fee Heads → add any head name; use when assigning fees
- **Timetable weekly grid** view on Timetable page
- **Roles & Access**: Admin → Users & Access → tick modules per role and Save
- Dark UI theme refresh, merged homework/assignments, documents verify

### Hostel setup order
1. Hostel / Rooms → **Add Block** (name A, floors 2)
2. **Add Room** → choose Block, Floor, room no, bed capacity
3. **Allocate Bed** → student + room (+ optional bed no)

### Reseed required if upgrading from older DB
New tables: `hostel_blocks`, `fee_heads`
```sql
DROP DATABASE IF EXISTS school_erp;
CREATE DATABASE school_erp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
```powershell
python seed.py
```

## Interactive timetable (latest)
Admin / Teacher → Timetable → pick class & section → click cells to assign subject + teacher.

## UI polish (latest)
- Light/dark theme on all pages (toggle 🌓)
- Refined cards, tables, badges, toasts, modals
- Polished landing, login, register
- Sticky sidebar with collapse (desktop) / drawer (mobile)
- Timetable weekly grid, clearer hostel & fees forms
