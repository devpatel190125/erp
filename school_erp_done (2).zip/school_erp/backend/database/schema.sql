-- School ERP - MySQL schema (generated from the SQLAlchemy models)
CREATE DATABASE IF NOT EXISTS school_erp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE school_erp;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE academic_years (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	name VARCHAR(20) NOT NULL, 
	is_current BOOL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE classes (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	name VARCHAR(30) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE events (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	title VARCHAR(150) NOT NULL, 
	description TEXT, 
	event_date DATE, 
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE hostels (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	name VARCHAR(80) NOT NULL, 
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE otp_verifications (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	identifier VARCHAR(120) NOT NULL, 
	purpose VARCHAR(20) NOT NULL, 
	otp_hash VARCHAR(64) NOT NULL, 
	attempts INTEGER, 
	used BOOL, 
	expires_at DATETIME NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_otp_verifications_identifier ON otp_verifications (identifier);
CREATE TABLE users (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	`role` VARCHAR(20) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	email VARCHAR(120), 
	mobile VARCHAR(15), 
	password_hash VARCHAR(255), 
	is_active BOOL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (email), 
	UNIQUE (mobile)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_users_role ON users (`role`);
CREATE TABLE ai_conversations (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_ai_conversations_user_id ON ai_conversations (user_id);
CREATE TABLE complaints (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	subject VARCHAR(150) NOT NULL, 
	description TEXT, 
	status VARCHAR(15), 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_complaints_user_id ON complaints (user_id);
CREATE TABLE hostel_rooms (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	hostel_id INTEGER NOT NULL, 
	room_no VARCHAR(10) NOT NULL, 
	capacity INTEGER, 
	PRIMARY KEY (id), 
	UNIQUE (hostel_id, room_no), 
	FOREIGN KEY(hostel_id) REFERENCES hostels (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE hostel_wardens (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	hostel_id INTEGER, 
	PRIMARY KEY (id), 
	UNIQUE (user_id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	FOREIGN KEY(hostel_id) REFERENCES hostels (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE notices (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	title VARCHAR(150) NOT NULL, 
	body TEXT, 
	audience VARCHAR(20), 
	category VARCHAR(20), 
	created_by INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE notifications (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	title VARCHAR(150) NOT NULL, 
	message TEXT, 
	type VARCHAR(30), 
	is_read BOOL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_notifications_user_id ON notifications (user_id);
CREATE TABLE parents (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (user_id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE sections (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	class_id INTEGER NOT NULL, 
	name VARCHAR(10) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (class_id, name), 
	FOREIGN KEY(class_id) REFERENCES classes (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE subjects (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	name VARCHAR(80) NOT NULL, 
	class_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (class_id, name), 
	FOREIGN KEY(class_id) REFERENCES classes (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE teachers (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	employee_no VARCHAR(30), 
	PRIMARY KEY (id), 
	UNIQUE (user_id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	UNIQUE (employee_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE ai_messages (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	conversation_id INTEGER NOT NULL, 
	sender VARCHAR(10) NOT NULL, 
	content TEXT NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(conversation_id) REFERENCES ai_conversations (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_ai_messages_conversation_id ON ai_messages (conversation_id);
CREATE TABLE assignments (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	class_id INTEGER NOT NULL, 
	section_id INTEGER, 
	subject_id INTEGER NOT NULL, 
	teacher_id INTEGER NOT NULL, 
	title VARCHAR(150) NOT NULL, 
	description TEXT, 
	due_date DATE, 
	max_marks INTEGER, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(section_id) REFERENCES sections (id), 
	FOREIGN KEY(subject_id) REFERENCES subjects (id), 
	FOREIGN KEY(teacher_id) REFERENCES teachers (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_assignments_class_id ON assignments (class_id);
CREATE TABLE exams (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	name VARCHAR(100) NOT NULL, 
	class_id INTEGER NOT NULL, 
	subject_id INTEGER NOT NULL, 
	exam_date DATE, 
	internal_max INTEGER, 
	max_marks INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(subject_id) REFERENCES subjects (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_exams_class_id ON exams (class_id);
CREATE TABLE homework (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	class_id INTEGER NOT NULL, 
	section_id INTEGER, 
	subject_id INTEGER NOT NULL, 
	teacher_id INTEGER NOT NULL, 
	title VARCHAR(150) NOT NULL, 
	description TEXT, 
	due_date DATE, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(section_id) REFERENCES sections (id), 
	FOREIGN KEY(subject_id) REFERENCES subjects (id), 
	FOREIGN KEY(teacher_id) REFERENCES teachers (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_homework_class_id ON homework (class_id);
CREATE TABLE students (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	user_id INTEGER NOT NULL, 
	admission_no VARCHAR(30) NOT NULL, 
	roll_no INTEGER, 
	class_id INTEGER NOT NULL, 
	section_id INTEGER, 
	parent_id INTEGER, 
	dob DATE, 
	gender VARCHAR(10), 
	is_hostel BOOL, 
	PRIMARY KEY (id), 
	UNIQUE (user_id), 
	FOREIGN KEY(user_id) REFERENCES users (id), 
	UNIQUE (admission_no), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(section_id) REFERENCES sections (id), 
	FOREIGN KEY(parent_id) REFERENCES parents (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_students_parent_id ON students (parent_id);
CREATE INDEX ix_students_class_id ON students (class_id);
CREATE TABLE study_materials (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	class_id INTEGER NOT NULL, 
	subject_id INTEGER NOT NULL, 
	teacher_id INTEGER, 
	title VARCHAR(150) NOT NULL, 
	file_path VARCHAR(255) NOT NULL, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(subject_id) REFERENCES subjects (id), 
	FOREIGN KEY(teacher_id) REFERENCES teachers (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_study_materials_class_id ON study_materials (class_id);
CREATE TABLE teacher_subjects (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	teacher_id INTEGER NOT NULL, 
	subject_id INTEGER NOT NULL, 
	class_id INTEGER NOT NULL, 
	section_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(teacher_id) REFERENCES teachers (id), 
	FOREIGN KEY(subject_id) REFERENCES subjects (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(section_id) REFERENCES sections (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_teacher_subjects_teacher_id ON teacher_subjects (teacher_id);
CREATE INDEX ix_teacher_subjects_class_id ON teacher_subjects (class_id);
CREATE TABLE timetable (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	class_id INTEGER NOT NULL, 
	section_id INTEGER, 
	subject_id INTEGER NOT NULL, 
	teacher_id INTEGER, 
	room VARCHAR(20), 
	day VARCHAR(10) NOT NULL, 
	start_time VARCHAR(5) NOT NULL, 
	end_time VARCHAR(5) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(section_id) REFERENCES sections (id), 
	FOREIGN KEY(subject_id) REFERENCES subjects (id), 
	FOREIGN KEY(teacher_id) REFERENCES teachers (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_timetable_class_id ON timetable (class_id);
CREATE TABLE assignment_submissions (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	assignment_id INTEGER NOT NULL, 
	student_id INTEGER NOT NULL, 
	file_path VARCHAR(255), 
	submitted_at DATETIME, 
	marks FLOAT, 
	feedback TEXT, 
	PRIMARY KEY (id), 
	UNIQUE (assignment_id, student_id), 
	FOREIGN KEY(assignment_id) REFERENCES assignments (id), 
	FOREIGN KEY(student_id) REFERENCES students (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE attendance (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	student_id INTEGER NOT NULL, 
	date DATE NOT NULL, 
	status VARCHAR(10) NOT NULL, 
	subject_id INTEGER, 
	marked_by INTEGER, 
	PRIMARY KEY (id), 
	UNIQUE (student_id, date, subject_id), 
	FOREIGN KEY(student_id) REFERENCES students (id), 
	FOREIGN KEY(subject_id) REFERENCES subjects (id), 
	FOREIGN KEY(marked_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_att_sd ON attendance (student_id, date);
CREATE TABLE exam_results (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	exam_id INTEGER NOT NULL, 
	student_id INTEGER NOT NULL, 
	internal_marks FLOAT, 
	exam_marks FLOAT, 
	total FLOAT, 
	percentage FLOAT, 
	grade VARCHAR(3), 
	passed BOOL, 
	published BOOL, 
	PRIMARY KEY (id), 
	UNIQUE (exam_id, student_id), 
	FOREIGN KEY(exam_id) REFERENCES exams (id), 
	FOREIGN KEY(student_id) REFERENCES students (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_exam_results_exam_id ON exam_results (exam_id);
CREATE INDEX ix_exam_results_student_id ON exam_results (student_id);
CREATE TABLE fees (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	student_id INTEGER NOT NULL, 
	fee_type VARCHAR(30) NOT NULL, 
	amount FLOAT NOT NULL, 
	due_date DATE, 
	PRIMARY KEY (id), 
	FOREIGN KEY(student_id) REFERENCES students (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_fees_student_id ON fees (student_id);
CREATE TABLE hostel_allocations (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	student_id INTEGER NOT NULL, 
	room_id INTEGER NOT NULL, 
	allocated_on DATE, 
	PRIMARY KEY (id), 
	UNIQUE (student_id), 
	FOREIGN KEY(student_id) REFERENCES students (id), 
	FOREIGN KEY(room_id) REFERENCES hostel_rooms (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_hostel_allocations_room_id ON hostel_allocations (room_id);
CREATE TABLE hostel_attendance (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	student_id INTEGER NOT NULL, 
	date DATE NOT NULL, 
	status VARCHAR(10) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (student_id, date), 
	FOREIGN KEY(student_id) REFERENCES students (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE hostel_complaints (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	student_id INTEGER, 
	description TEXT NOT NULL, 
	category VARCHAR(30), 
	priority VARCHAR(10), 
	status VARCHAR(15), 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(student_id) REFERENCES students (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE hostel_visitors (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	student_id INTEGER NOT NULL, 
	visitor_name VARCHAR(100) NOT NULL, 
	relation VARCHAR(40), 
	purpose VARCHAR(200), 
	in_time DATETIME, 
	out_time DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(student_id) REFERENCES students (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE student_classes (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	student_id INTEGER NOT NULL, 
	class_id INTEGER NOT NULL, 
	section_id INTEGER, 
	academic_year_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(student_id) REFERENCES students (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(section_id) REFERENCES sections (id), 
	FOREIGN KEY(academic_year_id) REFERENCES academic_years (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE fee_payments (
	id INTEGER NOT NULL AUTO_INCREMENT, 
	fee_id INTEGER NOT NULL, 
	amount FLOAT NOT NULL, 
	paid_on DATE, 
	mode VARCHAR(20), 
	PRIMARY KEY (id), 
	FOREIGN KEY(fee_id) REFERENCES fees (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX ix_fee_payments_fee_id ON fee_payments (fee_id);

-- ---- added in v2: settings, audit log, hostel outpass, mess menu (also created automatically at server start) ----
CREATE TABLE IF NOT EXISTS school_settings (
	`key` VARCHAR(50) NOT NULL,
	value TEXT,
	PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_log (
	id INTEGER NOT NULL AUTO_INCREMENT,
	user_id INTEGER,
	user_name VARCHAR(120),
	`role` VARCHAR(20),
	action VARCHAR(200) NOT NULL,
	method VARCHAR(8),
	path VARCHAR(200),
	status_code INTEGER,
	ip VARCHAR(45),
	created_at DATETIME,
	PRIMARY KEY (id),
	INDEX ix_audit_log_user_id (user_id),
	INDEX ix_audit_log_created_at (created_at),
	FOREIGN KEY(user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS hostel_outpass (
	id INTEGER NOT NULL AUTO_INCREMENT,
	student_id INTEGER NOT NULL,
	from_date DATE NOT NULL,
	to_date DATE NOT NULL,
	reason VARCHAR(250) NOT NULL,
	status VARCHAR(15),
	remarks VARCHAR(250),
	decided_by INTEGER,
	created_at DATETIME,
	PRIMARY KEY (id),
	INDEX ix_hostel_outpass_student_id (student_id),
	FOREIGN KEY(student_id) REFERENCES students (id),
	FOREIGN KEY(decided_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mess_menu (
	id INTEGER NOT NULL AUTO_INCREMENT,
	day VARCHAR(10) NOT NULL,
	meal VARCHAR(15) NOT NULL,
	items VARCHAR(250),
	PRIMARY KEY (id),
	UNIQUE (day, meal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS=1;
-- Sample data: run  python seed.py  (creates admin, teachers, students, parents, warden, fees, exams ...)