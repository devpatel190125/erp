"""Creates tables + rich realistic demo data (10+ per module). Run: python seed.py"""
import random
from datetime import date, timedelta
from app.database import Base, engine, SessionLocal
from app.models import models as m
from app.auth.security import hash_password
from app.utils.helpers import grade_for

FIRST = [
    "Aarav", "Vivaan", "Aditya", "Ishaan", "Kabir", "Arjun", "Reyansh", "Sai", "Ayaan", "Krishna",
    "Riya", "Ananya", "Diya", "Meera", "Saanvi", "Aadhya", "Pari", "Anvi", "Myra", "Kiara",
    "Rohan", "Kavya", "Dev", "Ira", "Yash", "Nisha", "Om", "Sara", "Veer", "Tara",
    "Harsh", "Isha", "Kunal", "Neha", "Pranav", "Ritu", "Siddharth", "Tanvi", "Uday", "Zara",
]
LAST = ["Kumar", "Sharma", "Patel", "Shah", "Mehta", "Joshi", "Desai", "Rana", "Trivedi", "Gupta",
        "Singh", "Nair", "Iyer", "Reddy", "Khan"]
TEACHER_NAMES = [
    ("Anita Sharma", "M.Sc. B.Ed", "8 years"),
    ("Rahul Verma", "M.A. English", "5 years"),
    ("Meena Patel", "M.A. History", "12 years"),
    ("Suresh Iyer", "M.Sc. Maths", "6 years"),
    ("Priya Nair", "B.Sc. B.Ed", "4 years"),
    ("Amit Desai", "M.Sc. Physics", "9 years"),
    ("Neha Joshi", "M.A. Hindi", "7 years"),
    ("Vikram Shah", "M.Com", "3 years"),
    ("Kavita Rana", "M.Sc. Chemistry", "10 years"),
    ("Deepak Gupta", "B.P.Ed", "15 years"),
    ("Sunita Mehta", "M.A. Geography", "5 years"),
    ("Rajesh Trivedi", "M.Tech", "6 years"),
    ("Pooja Reddy", "M.Sc. Biology", "4 years"),
    ("Imran Khan", "B.Ed Computer", "8 years"),
    ("Lakshmi Iyer", "M.A. Sanskrit", "11 years"),
]
# Subjects by Indian school stage
SUBS_PRIMARY = ["English", "Mathematics", "EVS", "Hindi", "Drawing", "General Knowledge"]  # 1–5
SUBS_MIDDLE = ["English", "Mathematics", "Science", "Social Science", "Hindi", "Computer", "Sanskrit"]  # 6–8
SUBS_SECONDARY = ["English", "Mathematics", "Science", "Social Science", "Hindi", "Computer", "Sanskrit", "Physical Education"]  # 9–10
SUBS_SENIOR = [
    "English", "Mathematics", "Physics", "Chemistry", "Biology", "Computer Science",
    "Accountancy", "Business Studies", "Economics", "Hindi", "Physical Education",
]  # 11–12

def subjects_for_class(n: int):
    if n <= 5:
        return SUBS_PRIMARY
    if n <= 8:
        return SUBS_MIDDLE
    if n <= 10:
        return SUBS_SECONDARY
    return SUBS_SENIOR

SUBS = SUBS_MIDDLE  # default alias for any leftover references
NOTICE_TITLES = [
    "Annual Day practice starts next week", "Fee due reminder – this month",
    "Sports meet registration open", "Parent-teacher meeting on Saturday",
    "Library week – borrow free", "Science exhibition call for projects",
    "Holiday notice – Diwali break", "Bus route change for sector 5",
    "Exam timetable published", "Health checkup camp on campus",
    "New mess menu from Monday", "Uniform compliance reminder",
    "School reopens after break", "Workshop on cyber safety",
    "Inter-house quiz competition", "Blood donation camp",
]
EVENTS = [
    ("Independence Day", 20), ("Sports Day", 35), ("Science Fair", 15),
    ("Annual Function", 50), ("PTM", 7), ("Unit Test Week", 5),
    ("Republic Day", 100), ("Picnic", 40), ("Book Fair", 25),
    ("Yoga Day", 60), ("Cultural Night", 45), ("Farewell", 80),
    ("Founders Day", 55), ("Environment Day", 90), ("Math Olympiad", 18),
]
HW_TITLES = [
    "Chapter summary", "Practice worksheet", "Read and answer", "Map work",
    "Lab notebook entry", "Essay writing", "Problem set", "Grammar exercise",
    "Diagram drawing", "Oral presentation prep", "Revision notes", "Project outline",
]


def _u(db, role, name, mobile, email=None, pw=None, school_id=None):
    u = m.User(school_id=school_id, role=role, name=name, mobile=mobile, email=email,
               password_hash=hash_password(pw) if pw else None, is_active=True)
    db.add(u)
    db.flush()
    return u


def run(db=None):
    # Create missing tables only (skip ones that already exist)
    try:
        Base.metadata.create_all(bind=engine, checkfirst=True)
    except Exception as e:
        # MySQL 1050 = table already exists — safe to continue
        msg = str(e)
        if "1050" not in msg and "already exists" not in msg.lower():
            raise
        print("Note: some tables already exist — continuing…")
    db = db or SessionLocal()
    try:
        has_users = db.query(m.User).count()
    except Exception:
        has_users = 0
    if has_users:
        print("Data already present — skipping seed.")
        print("To reseed from scratch, in MySQL run:")
        print("  DROP DATABASE school_erp;")
        print("  CREATE DATABASE school_erp CHARACTER SET utf8mb4;")
        print("Then: python seed.py")
        return

    random.seed(42)
    today = date.today()

    school = m.School(
        code="SCH-DEMO1", name="Demo Public School", address="12 Education Road",
        city="Ahmedabad", state="Gujarat", pincode="380001", phone="9000000001",
        email="admin@school.com", is_active=True,
    )
    db.add(school)
    db.flush()
    SID = school.id
    U = lambda role, name, mob, email=None, pw=None: _u(db, role, name, mob, email, pw, SID)

    admin = U("admin", "School Admin", "9000000001", "admin@school.com", "Admin@123")
    db.add(m.AcademicYear(school_id=SID, name="2026-27", is_current=True))
    from app.services import settings_service as ss
    ss.set_many(db, {
        "school_name": school.name,
        "address": "12 Education Road, Ahmedabad, Gujarat 380001",
        "phone": "9000000001", "email": "admin@school.com",
        "school_code": "SCH-DEMO1", "low_attendance": "75",
    }, SID)

    # Classes 1–12, sections A/B/C, subjects as per standard
    cls = {}
    for n in range(1, 13):
        cap = 35 if n <= 5 else (40 if n <= 10 else 45)
        c = m.SchoolClass(school_id=SID, name=f"Class {n}", capacity=cap)
        db.add(c)
        db.flush()
        cls[n] = c
        secs = ("A", "B") if n <= 5 else ("A", "B", "C")
        for sec in secs:
            db.add(m.Section(class_id=c.id, name=sec))
        for sub in subjects_for_class(n):
            db.add(m.Subject(name=sub, class_id=c.id))
    db.flush()

    # Teachers — assign across classes 1–12
    teachers = []
    class_nums = list(range(1, 13))
    for i, (nm, qual, exp) in enumerate(TEACHER_NAMES):
        u = U("teacher", nm, f"91{10000000 + 11 + i}", f"t{i + 1}@school.com")
        cn = class_nums[i % len(class_nums)]
        class_id = cls[cn].id
        tch = m.Teacher(user_id=u.id, employee_no=f"EMP{100 + i}",
                        qualification=qual, experience=exp, class_id=class_id)
        db.add(tch)
        db.flush()
        # class teacher for first 12
        if i < 12 and getattr(cls[cn], "class_teacher_id", None) is None:
            cls[cn].class_teacher_id = tch.id
        teachers.append(tch)
        # assign 2 subjects on this class + one neighbouring class
        for cn2 in {cn, min(12, cn + 1)}:
            subs = db.query(m.Subject).filter_by(class_id=cls[cn2].id).all()
            if not subs:
                continue
            for sub in random.sample(subs, k=min(2, len(subs))):
                secs = db.query(m.Section).filter_by(class_id=cls[cn2].id).all()
                for sec in secs[:2]:
                    db.add(m.TeacherSubject(
                        teacher_id=tch.id, subject_id=sub.id,
                        class_id=cls[cn2].id, section_id=sec.id,
                    ))
    db.flush()

    # Hostel: 3 blocks, 18 rooms
    hostel = m.Hostel(school_id=SID, name="Boys Hostel")
    db.add(hostel)
    db.flush()
    for bn, fl in (("A", 3), ("B", 3), ("C", 2)):
        db.add(m.HostelBlock(hostel_id=hostel.id, name=bn, floors=fl))
    db.flush()

    for hn, amt, freq, classes in (
        ("Tuition", 15000, "Monthly", "1-12"),
        ("Exam", 2000, "Quarterly", "1-12"),
        ("Transport", 3000, "Monthly", "1-12"),
        ("Hostel", 8000, "Monthly", "6-12"),
        ("Lab", 1500, "Annual", "6-12"),
        ("Library", 500, "Annual", "1-12"),
        ("Sports", 800, "Annual", "1-12"),
        ("Uniform", 1200, "Annual", "1-12"),
        ("Activity", 600, "Annual", "1-12"),
        ("Computer Lab", 1000, "Annual", "6-12"),
        ("Smart Class", 700, "Annual", "1-12"),
        ("Admission", 5000, "One-time", "1-12"),
    ):
        db.add(m.FeeHead(
            school_id=SID, name=hn, default_amount=amt,
            frequency=freq, applicable_classes=classes,
        ))

    rooms = []
    for block, base, max_floor in (("A", 100, 3), ("B", 200, 3), ("C", 300, 2)):
        for floor in range(1, max_floor + 1):
            for k in range(1, 3):  # 2 rooms per floor
                rno = f"{block}{floor}{k}"  # unique: A11, A12, B21, C21...
                r = m.HostelRoom(hostel_id=hostel.id, room_no=rno, capacity=3,
                                 block=block, floor=floor)
                db.add(r)
                rooms.append(r)
    wu = U("warden", "Suresh Warden", "9300000001", "warden@school.com")
    db.add(m.HostelWarden(user_id=wu.id, hostel_id=hostel.id))
    db.flush()

    # ~96 students across classes 1–12 (about 8 per class)
    students = []
    for i in range(96):
        fn = FIRST[i % len(FIRST)]
        ln = LAST[(i * 3) % len(LAST)]
        nm = f"{fn} {ln}"
        pu = U("parent", f"Parent of {fn}", f"92{10000000 + i + 1}", f"p{i + 1}@mail.com")
        p = m.Parent(user_id=pu.id)
        db.add(p)
        db.flush()
        su = U("student", nm, f"91{20000000 + i + 1}", f"s{i + 1}@school.com")
        cn = (i % 12) + 1  # Class 1..12 evenly
        # extra students in 8, 10, 12 for demo density
        if i >= 72:
            cn = [8, 10, 12][i % 3]
        sec_list = db.query(m.Section).filter_by(class_id=cls[cn].id).all()
        sec = sec_list[i % len(sec_list)]
        birth_year = 2026 - (5 + cn)  # approximate age
        s = m.Student(
            user_id=su.id, admission_no=f"ADM{2026000 + i + 1}", roll_no=(i % 20) + 1,
            class_id=cls[cn].id, section_id=sec.id, parent_id=p.id,
            dob=date(birth_year, 1 + (i % 11), 1 + (i % 27)),
            gender="M" if i % 2 == 0 else "F",
            is_hostel=(i % 5 == 0),  # ~20% hostel
            address_line1=f"{10 + i} Lake View Society",
            address_line2="Near City Park",
            city=random.choice(["Ahmedabad", "Gandhinagar", "Surat", "Vadodara", "Rajkot"]),
            state="Gujarat", pincode=f"38000{(i % 9) + 1}",
        )
        db.add(s)
        db.flush()
        students.append(s)
        db.add(m.StudentClass(student_id=s.id, class_id=cls[cn].id, section_id=sec.id))
    db.flush()

    # Hostel allocation for hostel students
    for i, s in enumerate([x for x in students if x.is_hostel]):
        room = rooms[i % len(rooms)]
        bed = (i // len(rooms)) % room.capacity + 1
        db.add(m.HostelAllocation(student_id=s.id, room_id=room.id, bed_no=bed))

    # Attendance last 40 weekdays
    for s in students:
        p_absent = 0.35 if s is students[2] else (0.18 if s is students[5] else 0.07)
        for d in range(40):
            day = today - timedelta(days=d)
            if day.weekday() >= 5:
                continue
            st = "Absent" if random.random() < p_absent else (
                "Late" if random.random() < 0.06 else (
                    "Leave" if random.random() < 0.03 else "Present"))
            db.add(m.Attendance(student_id=s.id, date=day, status=st))
            if s.is_hostel:
                db.add(m.HostelAttendance(
                    student_id=s.id, date=day,
                    status="Present" if st not in ("Absent",) else "Absent",
                ))

    # Exams for classes 5, 8, 10, 12 — unit tests + half yearly (full results)
    for cn in (5, 8, 10, 12):
        subs_n = db.query(m.Subject).filter_by(class_id=cls[cn].id).all()
        class_students = [x for x in students if x.class_id == cls[cn].id]
        for si, sub in enumerate(subs_n):
            for name, etype, days_ago, imax, emax, st, et in (
                (f"Unit Test 1 - {sub.name}", "test", 25 + (cn % 3), 10, 20, "09:00", "10:00"),
                (f"Unit Test 2 - {sub.name}", "test", 8 + (cn % 2), 10, 20, "11:00", "12:00"),
                (f"Half Yearly - {sub.name}", "exam", -10 - (cn % 5), 20, 80, "10:00", "13:00"),
            ):
                ed = today - timedelta(days=days_ago) if days_ago >= 0 else today + timedelta(days=-days_ago)
                ex = m.Exam(
                    name=name, exam_type=etype, class_id=cls[cn].id, subject_id=sub.id,
                    exam_date=ed, start_time=st, end_time=et, internal_max=imax, max_marks=emax,
                )
                db.add(ex)
                db.flush()
                if days_ago >= 0 and class_students:  # past exams get results
                    for s in class_students:
                        im = random.randint(max(1, imax // 2), imax)
                        em = random.randint(max(1, emax // 3), emax)
                        if s.roll_no and s.roll_no <= 2:
                            em = random.randint(1, max(2, emax // 4))
                        tot = im + em
                        mx = imax + emax
                        pct = round(tot / mx * 100, 1)
                        db.add(m.ExamResult(
                            exam_id=ex.id, student_id=s.id, internal_marks=im, exam_marks=em,
                            total=tot, percentage=pct, grade=grade_for(pct),
                            passed=pct >= 33, published=True,
                        ))

    # Fees for all students
    fee_types = [
        ("Tuition", 15000), ("Exam", 2000), ("Lab", 1500), ("Library", 500),
        ("Sports", 800), ("Activity", 600),
    ]
    for s in students:
        extra = []
        if s.is_hostel:
            extra.append(("Hostel", 8000))
        else:
            extra.append(("Transport", 3000))
        for ftype, amt in fee_types + extra:
            fee = m.Fee(student_id=s.id, fee_type=ftype, amount=amt,
                        due_date=today + timedelta(days=15 + random.randint(0, 20)))
            db.add(fee)
            db.flush()
            paid_ratio = random.choice([0.0, 0.3, 0.5, 0.7, 1.0, 1.0])
            paid = round(amt * paid_ratio, 0)
            if paid > 0:
                parts = [paid] if paid_ratio == 1.0 else [round(paid * 0.6, 2), round(paid * 0.4, 2)]
                for part in parts:
                    if part < 1:
                        continue
                    db.add(m.FeePayment(
                        fee_id=fee.id, amount=part,
                        mode=random.choice(["Cash", "UPI", "Card", "Bank"]),
                        paid_on=today - timedelta(days=random.randint(1, 35)),
                    ))

    # Homework & assignments across classes 5, 8, 10, 12
    for cn in (5, 8, 10, 12):
        subs_n = db.query(m.Subject).filter_by(class_id=cls[cn].id).all()
        class_students = [x for x in students if x.class_id == cls[cn].id]
        if not subs_n:
            continue
        for i in range(6):
            sub = subs_n[i % len(subs_n)]
            tch = teachers[i % len(teachers)]
            db.add(m.Homework(
                class_id=cls[cn].id, subject_id=sub.id, teacher_id=tch.id,
                title=f"{sub.name}: {HW_TITLES[i % len(HW_TITLES)]}",
                description=f"Class {cn} – complete work for {sub.name}. Chapter {i + 1}.",
                due_date=today + timedelta(days=2 + i),
            ))
            a = m.Assignment(
                class_id=cls[cn].id, subject_id=sub.id, teacher_id=tch.id,
                title=f"Class {cn} {sub.name} assignment {i + 1}",
                description="Submit as PDF or handwritten scan.",
                due_date=today + timedelta(days=5 + i), max_marks=20,
            )
            db.add(a)
            db.flush()
            for s in class_students[:10]:
                if random.random() < 0.55:
                    marks = random.randint(10, 20) if random.random() < 0.45 else None
                    db.add(m.AssignmentSubmission(
                        assignment_id=a.id, student_id=s.id, file_path="demo_submit.pdf", marks=marks,
                        feedback="Good work" if marks and marks >= 15 else (None if marks is None else "Needs improvement"),
                    ))

    # Study materials across classes 5–12
    for cn in range(5, 13):
        subs_n = db.query(m.Subject).filter_by(class_id=cls[cn].id).all()
        for i, sub in enumerate(subs_n[:4]):
            db.add(m.StudyMaterial(
                class_id=cls[cn].id, subject_id=sub.id, teacher_id=teachers[i % len(teachers)].id,
                title=f"Class {cn} {sub.name} notes – Chapter {i + 1}",
                file_path=f"material_c{cn}_{sub.name.lower().replace(' ', '_')}_{i + 1}.pdf",
            ))

    # Full-week timetables for classes 1, 5, 8, 10, 12 (all sections)
    periods = [
        ("08:00", "08:45"), ("08:45", "09:30"), ("09:45", "10:30"), ("10:30", "11:15"),
        ("11:30", "12:15"), ("12:15", "13:00"), ("13:30", "14:15"),
    ]
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    for cn in (1, 5, 8, 10, 12):
        subs_n = db.query(m.Subject).filter_by(class_id=cls[cn].id).all()
        secs = db.query(m.Section).filter_by(class_id=cls[cn].id).all()
        if not subs_n or not secs:
            continue
        for si, sec in enumerate(secs):
            home_room = f"R{cn}{si + 1:02d}"
            for di, day in enumerate(days):
                for pi, (st, et) in enumerate(periods):
                    sub = subs_n[(pi + di + si) % len(subs_n)]
                    teach = teachers[(pi + si + cn) % len(teachers)]
                    db.add(m.Timetable(
                        class_id=cls[cn].id, section_id=sec.id, subject_id=sub.id,
                        teacher_id=teach.id, day=day, start_time=st, end_time=et, room=home_room,
                    ))

    # Notices (16)
    for i, title in enumerate(NOTICE_TITLES):
        db.add(m.Notice(
            school_id=SID, title=title,
            body=f"Dear all, please note: {title}. Contact office for details.",
            audience=random.choice(["all", "student", "teacher", "parent", "all"]),
            category=random.choice(["general", "exam", "fee", "hostel", "event"]),
            created_by=admin.id,
        ))

    # Events (15)
    for title, days_ahead in EVENTS:
        db.add(m.Event(
            school_id=SID, title=title,
            description=f"School event: {title}. All students and staff are informed.",
            event_date=today + timedelta(days=days_ahead),
        ))

    # Mess menu full week
    meals = {
        "Monday": ("Poha + Tea", "Dal Rice + Roti + Salad", "Khichdi + Curd"),
        "Tuesday": ("Idli Sambar", "Veg Thali", "Upma"),
        "Wednesday": ("Paratha + Curd", "Rajma Rice", "Sandwich"),
        "Thursday": ("Puri Bhaji", "Sambar Rice", "Noodles"),
        "Friday": ("Bread Butter + Jam", "Paneer Curry + Roti", "Poha"),
        "Saturday": ("Dosa + Chutney", "Chole Rice", "Pasta"),
        "Sunday": ("Pancake", "Special Thali", "Soup + Bread"),
    }
    for day, (b, l, d) in meals.items():
        for meal, item in (("breakfast", b), ("lunch", l), ("dinner", d)):
            db.add(m.MessMenu(school_id=SID, day=day, meal=meal, items=item))

    # General complaints (12)
    subjects = [
        "Bus late frequently", "Classroom fan not working", "Library book missing",
        "Canteen hygiene", "Sports equipment request", "WiFi in lab",
        "Washroom cleanliness", "Homework load", "Seating issue",
        "Projector problem", "Water cooler", "Parking congestion",
    ]
    for i, subj in enumerate(subjects):
        s = students[i % len(students)]
        db.add(m.Complaint(
            user_id=s.user_id, subject=subj,
            description=f"Details regarding: {subj}. Raised for demo.",
            status=random.choice(["Open", "Open", "Resolved"]),
        ))

    # Hostel complaints (12)
    for i, s in enumerate([x for x in students if x.is_hostel][:12]):
        db.add(m.HostelComplaint(
            student_id=s.id,
            description=f"Hostel issue {i + 1}: needs attention in room/area.",
            category=random.choice(["Food", "Room", "Water", "Electricity", "Other"]),
            priority=random.choice(["Low", "Medium", "High"]),
            status=random.choice(["Open", "Resolved", "Open"]),
        ))

    # Visitors (12)
    for i, s in enumerate([x for x in students if x.is_hostel][:12]):
        db.add(m.HostelVisitor(
            student_id=s.id,
            visitor_name=random.choice(["Ramesh", "Sita", "Mahesh", "Geeta", "Anil"]) + f" {LAST[i % len(LAST)]}",
            relation=random.choice(["Father", "Mother", "Uncle", "Guardian", "Aunt"]),
            purpose=random.choice(["Meeting", "Drop belongings", "Medical", "Festival leave"]),
        ))

    # Outpass (12)
    for i, s in enumerate([x for x in students if x.is_hostel][:12]):
        db.add(m.HostelOutpass(
            student_id=s.id,
            from_date=today + timedelta(days=i % 5),
            to_date=today + timedelta(days=(i % 5) + 2),
            reason=random.choice(["Family function", "Medical", "Festival", "Personal"]),
            status=random.choice(["Pending", "Approved", "Rejected", "Pending"]),
            remarks="" if random.random() < 0.6 else "Carry ID card",
        ))

    # Documents (20+)
    for i, s in enumerate(students[:25]):
        for j, dtype in enumerate(random.sample(
            ["photo", "aadhaar", "birth_cert", "marksheet", "tc", "other"], k=random.randint(1, 2)
        )):
            db.add(m.StudentDocument(
                student_id=s.id, doc_type=dtype,
                title=f"{dtype.replace('_', ' ').title()} – {s.admission_no}",
                file_path=f"docs/{s.admission_no}_{dtype}.pdf",
                status=random.choice(["Pending", "Verified", "Pending", "Rejected", "Verified"]),
                remarks="" if random.random() < 0.75 else "Please upload clearer copy",
            ))

    # Notifications for admin + few students
    for i, title in enumerate([
        "Low attendance alert", "Fee reminder batch sent", "New complaint received",
        "Exam results published", "Hostel room full – Block A", "Document pending verify",
        "PTM scheduled", "Backup completed", "New student registered", "Payment received",
        "Outpass request", "Mess menu updated",
    ]):
        db.add(m.Notification(
            user_id=admin.id, title=title,
            message=f"{title} – please review in the portal.",
            type=random.choice(["general", "fee", "attendance", "exam", "hostel"]),
            is_read=i % 3 == 0,
        ))
    for s in students[:10]:
        db.add(m.Notification(
            user_id=s.user_id, title="Welcome to School ERP",
            message="Your student account is active. Check timetable and homework.",
            type="general", is_read=False,
        ))

    db.commit()

    print("=" * 56)
    print("Seeded successfully — Classes 1–12 + full demo data!")
    print(" School code : SCH-DEMO1")
    print(" Classes     : 1 to 12 (subjects as per Indian school standards)")
    print("   1–5  : English, Maths, EVS, Hindi, Drawing, GK")
    print("   6–8  : + Science, Social Science, Computer, Sanskrit")
    print("   9–10 : + Physical Education")
    print("   11–12: Science & Commerce streams (Physics, Chemistry, Biology,")
    print("          CS, Accountancy, Business Studies, Economics, …)")
    print(" Students    : ~96 across all classes (~8+ per class)")
    print(" Teachers    : 24 with multi-class subject allocations")
    print(" Admin       : 9000000001 / Admin@123  (OTP 123456)")
    print(" Teachers    : e.g. 9110000011")
    print(" Students    : e.g. 9120000001")
    print(" Parents     : e.g. 9210000001")
    print(" Warden      : 9300000001")
    print(" Data        : fees, payments, attendance, exams+results,")
    print("               homework, assignments, materials, timetable,")
    print("               hostel rooms/beds, outpass, notices, documents")
if __name__ == "__main__":
    run()
