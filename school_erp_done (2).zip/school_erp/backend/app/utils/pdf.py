"""Tiny dependency-free PDF writer (A4, Helvetica). Enough for receipts and report cards.

No pip packages needed, so it installs everywhere (also 32-bit Windows Python without a C++ compiler).
Limitation: the standard PDF fonts only cover Latin letters - Gujarati/Hindi characters show as '?'.
"""
import zlib

W, H = 595.28, 841.89          # A4 in points
_REG = dict(zip(" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",
                [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278] + [556] * 10 +
                [278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722,
                 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500,
                 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584]))
_BOLD = dict(zip(" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",
                 [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278] + [556] * 10 +
                 [333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722,
                  667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556, 333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556,
                  278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584]))


def text_width(s, size=10, bold=False):
    t = _BOLD if bold else _REG
    return sum(t.get(ch, 556) for ch in s) * size / 1000.0


def _esc(s):
    b = str(s).encode("cp1252", "replace")
    return b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")


def _rgb(c):
    return " ".join(f"{v:.3f}" for v in c)


class PDF:
    def __init__(self, title="Document"):
        self.title, self.pages, self.cur = title, [], None
        self.page()

    def page(self):
        self.cur = []
        self.pages.append(self.cur)

    # all coordinates are measured from the TOP-LEFT corner, in points
    def rect(self, x, y, w, h, fill=None, stroke=None, lw=0.6):
        ops = []
        if fill:
            ops.append(f"{_rgb(fill)} rg")
        if stroke:
            ops.append(f"{_rgb(stroke)} RG {lw} w")
        paint = "B" if fill and stroke else "f" if fill else "S" if stroke else "n"
        ops.append(f"{x:.2f} {H - y - h:.2f} {w:.2f} {h:.2f} re {paint}")
        self.cur.append("\n".join(ops))

    def line(self, x1, y1, x2, y2, color=(0.7, 0.7, 0.7), lw=0.6):
        self.cur.append(f"{_rgb(color)} RG {lw} w {x1:.2f} {H - y1:.2f} m {x2:.2f} {H - y2:.2f} l S")

    def text(self, x, y, s, size=10, bold=False, color=(0, 0, 0), align="l", maxw=None):
        s = str(s)
        if maxw:                                              # shorten with ... instead of overflowing
            while len(s) > 1 and text_width(s, size, bold) > maxw:
                s = s[:-2] + "…" if not s.endswith("…") else s[:-2] + "…"
        w = text_width(s, size, bold)
        x = x - w / 2 if align == "c" else x - w if align == "r" else x
        self.cur.append(b"BT /%s %s Tf %s rg %.2f %.2f Td (" % (b"F2" if bold else b"F1", str(size).encode(), _rgb(color).encode(), x, H - y)
                        + bytes(_esc(s)) + b") Tj ET")

    def output(self) -> bytes:
        objs = []                                  # index = object number - 1

        def add(b):
            objs.append(b if isinstance(b, bytes) else b.encode("latin-1"))
            return len(objs)
        cat, pages_id = add(b""), add(b"")
        f1 = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        f2 = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
        info = add(b"<< /Title (" + _esc(self.title) + b") /Producer (School ERP) >>")
        kids = []
        for ops in self.pages:
            body = b"\n".join(o if isinstance(o, bytes) else o.encode("latin-1") for o in ops)
            z = zlib.compress(body)
            cid = add(b"<< /Length %d /Filter /FlateDecode >>\nstream\n" % len(z) + z + b"\nendstream")
            kids.append(add(f"<< /Type /Page /Parent {pages_id} 0 R /MediaBox [0 0 {W} {H}] /Contents {cid} 0 R "
                            f"/Resources << /Font << /F1 {f1} 0 R /F2 {f2} 0 R >> >> >>"))
        objs[cat - 1] = f"<< /Type /Catalog /Pages {pages_id} 0 R >>".encode()
        objs[pages_id - 1] = f"<< /Type /Pages /Kids [{' '.join(f'{k} 0 R' for k in kids)}] /Count {len(kids)} >>".encode()
        out, offs = bytearray(b"%PDF-1.4\n"), []
        for i, o in enumerate(objs, 1):
            offs.append(len(out))
            out += b"%d 0 obj\n" % i + o + b"\nendobj\n"
        xref = len(out)
        out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
        for off in offs:
            out += b"%010d 00000 n \n" % off
        out += b"trailer\n<< /Size %d /Root %d 0 R /Info %d 0 R >>\nstartxref\n%d\n%%%%EOF" % (len(objs) + 1, cat, info, xref)
        return bytes(out)


_ONES = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen",
         "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
_TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]


def _below_1000(n):
    out = []
    if n >= 100:
        out.append(_ONES[n // 100] + " Hundred")
        n %= 100
    if n >= 20:
        out.append(_TENS[n // 10] + (" " + _ONES[n % 10] if n % 10 else ""))
    elif n:
        out.append(_ONES[n])
    return " ".join(out)


def rupees_in_words(amount):
    """12500.50 -> 'Rupees Twelve Thousand Five Hundred and Fifty Paise Only' (Indian system: lakh, crore)."""
    rupees, paise = int(amount), int(round((amount - int(amount)) * 100))
    if paise == 100:
        rupees, paise = rupees + 1, 0
    parts, n = [], rupees
    for div, name in ((10000000, "Crore"), (100000, "Lakh"), (1000, "Thousand")):
        if n >= div:
            parts.append(_below_1000(n // div) + " " + name)
            n %= div
    if n:
        parts.append(_below_1000(n))
    words = "Rupees " + (" ".join(parts) if parts else "Zero")
    if paise:
        words += " and " + _below_1000(paise) + " Paise"
    return words + " Only"


def money(v):
    """12345.5 -> 'Rs. 12,345.50' in the Indian grouping (the rupee sign is not in the standard PDF font)."""
    s = f"{abs(v):.2f}"
    whole, dec = s.split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    return ("-" if v < 0 else "") + "Rs. " + whole + "." + dec
