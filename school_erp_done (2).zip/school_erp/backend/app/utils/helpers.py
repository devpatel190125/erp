import uuid
from datetime import date, datetime
from pathlib import Path
from fastapi import HTTPException, UploadFile
from sqlalchemy import func
from ..config import settings
from ..models import models as m
from ..services.settings_service import low_threshold

ALLOWED_EXT = {".pdf", ".doc", ".docx", ".png", ".jpg", ".jpeg", ".txt", ".ppt", ".pptx"}


def ser(o, *fields):
    out = {}
    for f in fields:
        v = getattr(o, f)
        out[f] = v.isoformat() if hasattr(v, "isoformat") else v
    return out


def grade_for(p):
    """Auto grade from percentage. F = below pass mark (PASS_PERCENT, default 33)."""
    if p >= 90: return "A+"
    if p >= 80: return "A"
    if p >= 70: return "B+"
    if p >= 60: return "B"
    if p >= 50: return "C"
    if p >= settings.PASS_PERCENT: return "D"
    return "F"


def att_stats(db, sid):
    rows = db.query(m.Attendance.status, func.count()).filter(
        m.Attendance.student_id == sid, m.Attendance.subject_id.is_(None)).group_by(m.Attendance.status).all()
    c = dict(rows)
    total = sum(c.values())
    pct = round((c.get("Present", 0) + c.get("Late", 0)) / total * 100, 1) if total else 100.0
    return {"total": total, "present": c.get("Present", 0), "absent": c.get("Absent", 0),
            "late": c.get("Late", 0), "leave": c.get("Leave", 0), "percentage": pct}


def notify(db, uid, title, msg, typ="general"):
    if uid:
        db.add(m.Notification(user_id=uid, title=title, message=msg, type=typ))


def student_label(s):
    return {"student_id": s.id, "name": s.user.name, "class": s.klass.name if s.klass else None,
            "section": s.section.name if s.section else None}


def class_students(db, class_id, section_id=None):
    q = db.query(m.Student).join(m.User).filter(m.Student.class_id == class_id, m.User.is_active == True)  # noqa
    if section_id:
        q = q.filter(m.Student.section_id == section_id)
    return q.order_by(m.Student.roll_no).all()


def notify_class(db, class_id, title, msg, typ, section_id=None):
    for s in class_students(db, class_id, section_id):
        notify(db, s.user_id, title, msg, typ)
        if s.parent:
            notify(db, s.parent.user_id, title, msg, typ)


def low_attendance(db, class_ids=None):
    q = db.query(m.Student).join(m.User).filter(m.User.is_active == True)  # noqa
    if class_ids is not None:
        q = q.filter(m.Student.class_id.in_(class_ids))
    out, limit = [], low_threshold(db)
    for s in q.all():
        st = att_stats(db, s.id)
        if st["total"] >= 1 and st["percentage"] < limit:
            out.append({**student_label(s), "attendance": st["percentage"]})
    return sorted(out, key=lambda x: x["attendance"])


def check_low_attendance(db, s):
    st, limit = att_stats(db, s.id), low_threshold(db)
    if st["total"] < 5 or st["percentage"] >= limit:
        return
    title = "Low attendance alert"
    start = datetime.combine(date.today(), datetime.min.time())
    if db.query(m.Notification).filter(m.Notification.user_id == s.user_id, m.Notification.title == title,
                                       m.Notification.created_at >= start).first():
        return
    msg = f"{s.user.name}'s attendance is {st['percentage']}% (below {limit:.0f}%)."
    targets = [s.user_id]
    if s.parent:
        targets.append(s.parent.user_id)
    for ts_ in db.query(m.TeacherSubject).filter_by(class_id=s.class_id).all():
        targets.append(ts_.teacher.user_id)
    targets += [u.id for u in db.query(m.User).filter_by(role="admin").all()]
    for uid in set(targets):
        notify(db, uid, title, msg, "attendance")


def student_of(db, user):
    return db.query(m.Student).filter_by(user_id=user.id).first()


def parent_children(db, user):
    p = db.query(m.Parent).filter_by(user_id=user.id).first()
    return db.query(m.Student).filter_by(parent_id=p.id).all() if p else []


def teacher_of(db, user):
    return db.query(m.Teacher).filter_by(user_id=user.id).first()


def teacher_class_ids(db, user):
    t = teacher_of(db, user)
    if not t:
        return []
    return list({r.class_id for r in db.query(m.TeacherSubject).filter_by(teacher_id=t.id).all()})


def same_school(user, other_user_or_school_id) -> bool:
    """True if caller's school matches target school_id or target user's school_id."""
    if user is None:
        return False
    sid = user.school_id
    if sid is None:
        return False  # school users must always have school_id
    if isinstance(other_user_or_school_id, int):
        return other_user_or_school_id == sid
    target = other_user_or_school_id
    if target is None:
        return False
    return getattr(target, "school_id", None) == sid


def require_school(user):
    if not user or user.school_id is None:
        raise HTTPException(403, "No school context for this account")
    return user.school_id

def school_class_or_404(db, user, class_id):
    """Class must exist and belong to caller's school."""
    row = db.get(m.SchoolClass, class_id)
    if not row:
        raise HTTPException(404, "Class not found")
    if user.school_id is not None and row.school_id != user.school_id:
        raise HTTPException(404, "Class not found")
    return row


def school_scope_users(db, user):
    """Users of the same school (active)."""
    sid = require_school(user)
    return db.query(m.User).filter(m.User.school_id == sid, m.User.is_active == True)  # noqa



def school_hostel(db, user, create=False):
    """Hostel for the caller's school only. Never falls back to another school."""
    sid = require_school(user)
    h = db.query(m.Hostel).filter_by(school_id=sid).first()
    if not h and create:
        h = m.Hostel(school_id=sid, name="Main Hostel")
        db.add(h)
        db.flush()
    return h


def school_students_query(db, user):
    """Base query of students belonging to caller's school."""
    sid = require_school(user)
    return (db.query(m.Student).join(m.User)
            .filter(m.User.school_id == sid, m.User.is_active == True))  # noqa


def can_access_student(db, user, sid):
    s = db.get(m.Student, sid)
    if not s or not s.user:
        raise HTTPException(404, "Student not found")
    # Tenant boundary first — never cross schools
    if user.school_id is not None and s.user.school_id != user.school_id:
        raise HTTPException(404, "Student not found")
    ok = (user.role == "admin"
          or (user.role == "student" and s.user_id == user.id)
          or (user.role == "parent" and s.id in [c.id for c in parent_children(db, user)])
          or (user.role == "teacher" and s.class_id in teacher_class_ids(db, user))
          or (user.role == "warden" and s.is_hostel and same_school(user, s.user)))
    if not ok:
        raise HTTPException(403, "You are not allowed to view this student")
    return s


def visible_class_ids(db, user):
    """None = unrestricted (admin)."""
    if user.role == "admin":
        return None
    if user.role == "student":
        s = student_of(db, user)
        return [s.class_id] if s else []
    if user.role == "parent":
        return [c.class_id for c in parent_children(db, user)]
    if user.role == "teacher":
        return teacher_class_ids(db, user)
    return []


def save_upload(file: UploadFile) -> str:
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(400, f"File type not allowed. Allowed: {', '.join(sorted(ALLOWED_EXT))}")
    data = file.file.read(settings.MAX_UPLOAD_MB * 1024 * 1024 + 1)
    if len(data) > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(400, f"File too large (max {settings.MAX_UPLOAD_MB} MB)")
    Path(settings.UPLOAD_DIR).mkdir(exist_ok=True)
    name = f"{uuid.uuid4().hex}{ext}"
    (Path(settings.UPLOAD_DIR) / name).write_bytes(data)
    return name
