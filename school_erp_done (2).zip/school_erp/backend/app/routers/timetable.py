from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import TimetableIn
from ..auth.deps import roles, current_user
from ..utils.helpers import visible_class_ids, school_class_or_404

router = APIRouter(prefix="/timetable", tags=["timetable"])


def _serialize(t):
    return {
        "id": t.id,
        "class_id": t.class_id,
        "section_id": t.section_id,
        "subject_id": t.subject_id,
        "teacher_id": t.teacher_id,
        "start_time": t.start_time,
        "end_time": t.end_time,
        "day": t.day,
        "time": f"{t.start_time}-{t.end_time}",
        "subject": t.subject.name if t.subject else None,
        "teacher": t.teacher.user.name if t.teacher and t.teacher.user else None,
        "room": t.room,
    }


@router.post("")
def add(d: TimetableIn, db: Session = Depends(get_db), u=Depends(roles("admin", "teacher"))):
    school_class_or_404(db, u, d.class_id)
    if d.start_time >= d.end_time:
        raise HTTPException(400, "End time must be after start time")
    clash = db.query(m.Timetable).filter_by(
        class_id=d.class_id, section_id=d.section_id, day=d.day, start_time=d.start_time
    ).first()
    if clash:
        raise HTTPException(409, "A period already exists at that time — edit or delete it first")
    row = m.Timetable(**d.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return {"message": "Timetable entry added", "id": row.id}


@router.put("/{tid}")
def update(tid: int, d: TimetableIn, db: Session = Depends(get_db), u=Depends(roles("admin", "teacher"))):
    t = db.get(m.Timetable, tid)
    if not t:
        raise HTTPException(404, "Period not found")
    school_class_or_404(db, u, t.class_id)
    school_class_or_404(db, u, d.class_id)
    if d.start_time >= d.end_time:
        raise HTTPException(400, "End time must be after start time")
    clash = (
        db.query(m.Timetable)
        .filter_by(class_id=d.class_id, section_id=d.section_id, day=d.day, start_time=d.start_time)
        .filter(m.Timetable.id != tid)
        .first()
    )
    if clash:
        raise HTTPException(409, "Another period already exists at that time")
    for k, v in d.model_dump().items():
        setattr(t, k, v)
    db.commit()
    return {"message": "Period updated"}


@router.delete("/{tid}")
def delete(tid: int, db: Session = Depends(get_db), u=Depends(roles("admin", "teacher"))):
    t = db.get(m.Timetable, tid)
    if not t:
        raise HTTPException(404, "Period not found")
    school_class_or_404(db, u, t.class_id)
    db.delete(t)
    db.commit()
    return {"message": "Period removed"}


@router.get("")
def get(class_id: int | None = None, section_id: int | None = None, db: Session = Depends(get_db), u=Depends(current_user)):
    ids = visible_class_ids(db, u)
    q = db.query(m.Timetable)
    if class_id:
        school_class_or_404(db, u, class_id)
        if ids is not None and class_id not in ids:
            raise HTTPException(403, "Not allowed")
        q = q.filter_by(class_id=class_id)
    elif ids is not None:
        if not ids:
            return []
        q = q.filter(m.Timetable.class_id.in_(ids))
    elif u.school_id:
        q = q.join(m.SchoolClass, m.SchoolClass.id == m.Timetable.class_id).filter(m.SchoolClass.school_id == u.school_id)
    if section_id:
        q = q.filter_by(section_id=section_id)
    rows = []
    for trow in q.order_by(m.Timetable.day, m.Timetable.start_time):
        item = _serialize(trow)
        cls = db.get(m.SchoolClass, trow.class_id)
        sec = db.get(m.Section, trow.section_id) if trow.section_id else None
        item["class_name"] = cls.name if cls else None
        item["section_name"] = sec.name if sec else None
        rows.append(item)
    return rows
