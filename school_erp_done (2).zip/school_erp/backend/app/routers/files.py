from pathlib import Path
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from ..config import settings
from ..database import get_db
from ..models import models as m
from ..auth.deps import roles, current_user
from ..utils.helpers import (save_upload, teacher_of, teacher_class_ids, notify_class, visible_class_ids,
                             can_access_student, student_of)

router = APIRouter(prefix="/files", tags=["files"])


def allowed(db, u, fn):
    """A file may only be opened by people who are meant to see it (previously ANY logged-in user could)."""
    if u.role == "admin":
        return True
    mat = db.query(m.StudyMaterial).filter_by(file_path=fn).first()
    if mat:
        return mat.class_id in (visible_class_ids(db, u) or [])
    sub = db.query(m.AssignmentSubmission).filter_by(file_path=fn).first()
    if sub:
        try:
            can_access_student(db, u, sub.student_id)     # the student, their parent, or the class teacher
            return True
        except HTTPException:
            return False
    return False


@router.get("/{name}")
def download(name: str, db: Session = Depends(get_db), u=Depends(current_user)):
    fn = Path(name).name  # blocks path traversal
    p = Path(settings.UPLOAD_DIR) / fn
    if not p.is_file():
        raise HTTPException(404, "File not found")
    if not allowed(db, u, fn):
        raise HTTPException(403, "You are not allowed to open this file")
    return FileResponse(p)


@router.post("/materials")
def upload_material(title: str = Form(...), class_id: int = Form(...), subject_id: int = Form(...),
                    file: UploadFile = File(...), db: Session = Depends(get_db), u=Depends(roles("teacher"))):
    if class_id not in teacher_class_ids(db, u):
        raise HTTPException(403, "You are not assigned to this class")
    db.add(m.StudyMaterial(title=title, class_id=class_id, subject_id=subject_id,
                           teacher_id=teacher_of(db, u).id, file_path=save_upload(file)))
    notify_class(db, class_id, "New study material", title, "material")
    db.commit()
    return {"message": "Uploaded"}
