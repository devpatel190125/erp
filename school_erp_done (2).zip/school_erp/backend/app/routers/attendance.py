from datetime import date as Date
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import AttendanceIn
from ..auth.deps import roles, current_user
from ..utils.helpers import (teacher_class_ids, class_students, check_low_attendance, low_attendance,
                             can_access_student, att_stats, ser, school_class_or_404)

router = APIRouter(prefix="/attendance", tags=["attendance"])


def guard_class(db, u, class_id):
    school_class_or_404(db, u, class_id)
    if u.role == "teacher" and class_id not in teacher_class_ids(db, u):
        raise HTTPException(403, "You are not assigned to this class")


@router.post("/mark")
def mark(d: AttendanceIn, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    guard_class(db, u, d.class_id)
    valid = {s.id: s for s in class_students(db, d.class_id, d.section_id)}
    for r in d.records:
        if r.student_id not in valid:
            raise HTTPException(400, f"Student {r.student_id} is not in this class/section")
        row = db.query(m.Attendance).filter_by(student_id=r.student_id, date=d.date, subject_id=d.subject_id).first()
        if row:
            row.status, row.marked_by = r.status, u.id
        else:
            db.add(m.Attendance(student_id=r.student_id, date=d.date, status=r.status, subject_id=d.subject_id, marked_by=u.id))
    db.flush()
    for r in d.records:
        check_low_attendance(db, valid[r.student_id])
    db.commit()
    return {"message": f"Attendance saved for {len(d.records)} students"}


@router.get("/class")
def class_attendance(class_id: int, date: Date | None = None, section_id: int | None = None, subject_id: int | None = None,
                     db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    guard_class(db, u, class_id)
    day = date or Date.today()
    out = []
    for s in class_students(db, class_id, section_id):
        r = db.query(m.Attendance).filter_by(student_id=s.id, date=day, subject_id=subject_id).first()
        out.append({"student_id": s.id, "roll_no": s.roll_no, "name": s.user.name, "status": r.status if r else None})
    return out


@router.get("/student/{sid}")
def student_attendance(sid: int, month: int | None = None, year: int | None = None,
                       db: Session = Depends(get_db), u=Depends(current_user)):
    s = can_access_student(db, u, sid)
    q = db.query(m.Attendance).filter_by(student_id=s.id)
    if month and year:
        q = q.filter(m.Attendance.date >= Date(year, month, 1),
                     m.Attendance.date < (Date(year + 1, 1, 1) if month == 12 else Date(year, month + 1, 1)))
    return {**att_stats(db, s.id), "records": [ser(r, "date", "status", "subject_id") for r in q.order_by(m.Attendance.date.desc()).limit(200)]}


@router.get("/summary")
def summary(date: Date | None = None, db: Session = Depends(get_db), u=Depends(roles("admin"))):
    day = date or Date.today()
    out = []
    for c in db.query(m.SchoolClass).all():
        for sec in db.query(m.Section).filter_by(class_id=c.id):
            ids = [s.id for s in class_students(db, c.id, sec.id)]
            rows = db.query(m.Attendance).filter(m.Attendance.student_id.in_(ids), m.Attendance.date == day,
                                                 m.Attendance.subject_id.is_(None)).all() if ids else []
            cnt = lambda st: sum(1 for r in rows if r.status == st)  # noqa
            out.append({"class": c.name, "section": sec.name, "students": len(ids), "present": cnt("Present"),
                        "absent": cnt("Absent"), "late": cnt("Late"), "leave": cnt("Leave"), "date": day.isoformat()})
    return out


@router.get("/low")
def low(db: Session = Depends(get_db), u=Depends(roles("admin", "teacher"))):
    return low_attendance(db, None if u.role == "admin" else teacher_class_ids(db, u))
