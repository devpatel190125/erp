from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import WorkIn, ReviewIn
from ..auth.deps import roles, current_user
from ..utils.helpers import teacher_of, teacher_class_ids, visible_class_ids, notify_class, notify, ser

router = APIRouter(prefix="/assignments", tags=["assignments"])


@router.post("")
def create(d: WorkIn, db: Session = Depends(get_db), u=Depends(roles("teacher"))):
    if d.class_id not in teacher_class_ids(db, u):
        raise HTTPException(403, "You are not assigned to this class")
    db.add(m.Assignment(teacher_id=teacher_of(db, u).id, **d.model_dump()))
    notify_class(db, d.class_id, "New assignment", f"{d.title} (due {d.due_date})", "assignment", d.section_id)
    db.commit()
    return {"message": "Assignment created"}


@router.get("")
def list_(db: Session = Depends(get_db), u=Depends(current_user)):
    ids = visible_class_ids(db, u)
    q = db.query(m.Assignment)
    if ids is not None:
        q = q.filter(m.Assignment.class_id.in_(ids))
    return [{**ser(a, "id", "title", "description", "due_date", "max_marks", "class_id"), "subject": a.subject.name,
             "submissions": db.query(m.AssignmentSubmission).filter_by(assignment_id=a.id).count()}
            for a in q.order_by(m.Assignment.id.desc()).limit(100)]


def own(db, u, aid):
    a = db.get(m.Assignment, aid)
    if not a:
        raise HTTPException(404, "Assignment not found")
    if u.role == "teacher" and a.teacher_id != teacher_of(db, u).id:
        raise HTTPException(403, "Not your assignment")
    return a


@router.get("/{aid}/submissions")
def submissions(aid: int, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    own(db, u, aid)
    return [{"id": s.id, "student": s.student.user.name, "file": s.file_path, "submitted_at": s.submitted_at.isoformat(),
             "marks": s.marks, "feedback": s.feedback}
            for s in db.query(m.AssignmentSubmission).filter_by(assignment_id=aid)]


@router.post("/submissions/{sub_id}/review")
def review(sub_id: int, d: ReviewIn, db: Session = Depends(get_db), u=Depends(roles("teacher"))):
    sub = db.get(m.AssignmentSubmission, sub_id)
    if not sub:
        raise HTTPException(404, "Submission not found")
    a = own(db, u, sub.assignment_id)
    if d.marks > a.max_marks:
        raise HTTPException(400, f"Marks cannot exceed {a.max_marks}")
    sub.marks, sub.feedback = d.marks, d.feedback
    notify(db, sub.student.user_id, "Assignment reviewed", f"{a.title}: {d.marks}/{a.max_marks}", "assignment")
    db.commit()
    return {"message": "Review saved"}
