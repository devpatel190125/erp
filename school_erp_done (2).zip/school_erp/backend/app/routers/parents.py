from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import ComplaintIn
from ..auth.deps import roles
from ..services import student_data as sd
from ..utils.helpers import parent_children, att_stats, notify, can_access_student

router = APIRouter(prefix="/parents", tags=["parents"])
par = Depends(roles("parent"))


def pick(db, u, student_id):
    kids = parent_children(db, u)
    if not kids:
        raise HTTPException(404, "No child linked to this account")
    if student_id is None:
        return kids[0]
    return can_access_student(db, u, student_id)


@router.get("/children")
def children(db: Session = Depends(get_db), u=par):
    return [{"student_id": s.id, "name": s.user.name, "class": s.klass.name,
             "section": s.section.name if s.section else "-", "is_hostel": bool(s.is_hostel)} for s in parent_children(db, u)]


@router.get("/dashboard")
def dashboard(student_id: int | None = None, db: Session = Depends(get_db), u=par):
    s = pick(db, u, student_id)
    fees = sd.fees(db, s)
    return {"child": s.user.name, "child_name": s.user.name, "class": s.klass.name, "attendance": att_stats(db, s.id)["percentage"],
            "is_hostel": bool(s.is_hostel),
            "pending_fees": sum(f["pending"] for f in fees),
            "subject_performance": sd.subject_performance(db, s),
            "pending_assignments": sum(1 for a in sd.assignments(db, s) if a["status"] == "Pending"),
            **sd.chart_extras(db, s, fees)}


@router.post("/concerns")
def concern(d: ComplaintIn, db: Session = Depends(get_db), u=par):
    db.add(m.Complaint(user_id=u.id, subject=d.subject, description=d.description))
    for a in db.query(m.User).filter_by(role="admin"):
        notify(db, a.id, "Parent concern", d.subject, "complaint")
    db.commit()
    return {"message": "Concern submitted to the school"}


@router.post("/message-teacher")
def message_teacher(d: ComplaintIn, student_id: int | None = None, db: Session = Depends(get_db), u=par):
    s = pick(db, u, student_id)
    for t in db.query(m.TeacherSubject).filter_by(class_id=s.class_id).all():
        notify(db, t.teacher.user_id, f"Message from parent of {s.user.name}: {d.subject}", d.description, "message")
    db.commit()
    return {"message": "Message sent to your child's teachers"}


@router.get("/child/{what}")
def child_data(what: str, student_id: int | None = None, db: Session = Depends(get_db), u=par):
    if what not in sd.DATA:
        raise HTTPException(404, "Unknown resource")
    return sd.DATA[what](db, pick(db, u, student_id))
