from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import WorkIn
from ..auth.deps import roles, current_user
from ..utils.helpers import teacher_of, teacher_class_ids, visible_class_ids, notify_class, ser

router = APIRouter(prefix="/homework", tags=["homework"])


@router.post("")
def create(d: WorkIn, db: Session = Depends(get_db), u=Depends(roles("teacher"))):
    if d.class_id not in teacher_class_ids(db, u):
        raise HTTPException(403, "You are not assigned to this class")
    t = teacher_of(db, u)
    db.add(m.Homework(teacher_id=t.id, **d.model_dump(exclude={"max_marks"})))
    notify_class(db, d.class_id, "New homework", d.title, "homework", d.section_id)
    db.commit()
    return {"message": "Homework created"}


@router.get("")
def list_(db: Session = Depends(get_db), u=Depends(current_user)):
    ids = visible_class_ids(db, u)
    q = db.query(m.Homework)
    if ids is not None:
        q = q.filter(m.Homework.class_id.in_(ids))
    return [{**ser(h, "id", "title", "description", "due_date"), "subject": h.subject.name, "class_id": h.class_id}
            for h in q.order_by(m.Homework.id.desc()).limit(100)]
