from datetime import date
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import ComplaintIn
from ..auth.deps import roles
from ..services import student_data as sd
from ..utils.helpers import student_of, att_stats, save_upload, ser

router = APIRouter(prefix="/students", tags=["students"])
me_dep = Depends(roles("student"))


def me(db, user):
    s = student_of(db, user)
    if not s:
        raise HTTPException(404, "Student profile not found")
    return s


@router.get("/me/dashboard")
def dashboard(db: Session = Depends(get_db), u=me_dep):
    s = me(db, u)
    fees = sd.fees(db, s)
    return {"name": u.name, "class": s.klass.name, "attendance": att_stats(db, s.id)["percentage"],
            "is_hostel": bool(s.is_hostel),
            "pending_fees": sum(f["pending"] for f in fees),
            "pending_assignments": sum(1 for a in sd.assignments(db, s) if a["status"] == "Pending"),
            "upcoming_exams": sum(1 for e in sd.exams(db, s) if e["exam_date"] and e["exam_date"] >= date.today().isoformat()),
            "subject_performance": sd.subject_performance(db, s),
            "exams": [e for e in sd.exams(db, s) if e["exam_date"] and e["exam_date"] >= date.today().isoformat()][:5],
            **sd.chart_extras(db, s, fees)}


@router.get("/me/complaints")
def my_complaints(db: Session = Depends(get_db), u=me_dep):
    return [{"subject": c.subject, "description": c.description, "status": c.status, "created_at": c.created_at.isoformat()}
            for c in db.query(m.Complaint).filter_by(user_id=u.id).order_by(m.Complaint.id.desc())]


@router.post("/me/complaints")
def complaint(d: ComplaintIn, db: Session = Depends(get_db), u=me_dep):
    db.add(m.Complaint(user_id=u.id, subject=d.subject, description=d.description))
    db.commit()
    return {"message": "Complaint submitted"}


@router.post("/me/assignments/{aid}/submit")
def submit(aid: int, file: UploadFile = File(...), db: Session = Depends(get_db), u=me_dep):
    s = me(db, u)
    a = db.get(m.Assignment, aid)
    if not a or a.class_id != s.class_id:
        raise HTTPException(404, "Assignment not found")
    name = save_upload(file)
    sub = db.query(m.AssignmentSubmission).filter_by(assignment_id=aid, student_id=s.id).first()
    if sub and sub.marks is not None:
        raise HTTPException(400, "Already reviewed; cannot resubmit")
    if sub:
        sub.file_path = name
    else:
        db.add(m.AssignmentSubmission(assignment_id=aid, student_id=s.id, file_path=name))
    db.commit()
    return {"message": "Assignment submitted"}


@router.get("/me/documents")
def my_documents(db: Session = Depends(get_db), u=me_dep):
    s = me(db, u)
    return [{**ser(d, "id", "doc_type", "title", "file_path", "status", "remarks", "uploaded_at")}
            for d in db.query(m.StudentDocument).filter_by(student_id=s.id).order_by(m.StudentDocument.id.desc())]


@router.post("/me/documents")
def upload_document(
    doc_type: str = Form("other"),
    title: str = Form(""),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    u=me_dep,
):
    s = me(db, u)
    path = save_upload(file)
    d = m.StudentDocument(student_id=s.id, doc_type=doc_type or "other",
                          title=title or file.filename, file_path=path, status="Pending")
    db.add(d)
    db.commit()
    return {"message": "Document uploaded – pending admin verification", "id": d.id}


@router.get("/me/{what}")
def data(what: str, db: Session = Depends(get_db), u=me_dep):
    if what not in sd.DATA:
        raise HTTPException(404, "Unknown resource")
    return sd.DATA[what](db, me(db, u))

