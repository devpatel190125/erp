from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..config import settings
from ..database import get_db
from ..models import models as m
from ..schemas import ExamIn, MarksIn
from ..auth.deps import roles, current_user
from ..utils.helpers import teacher_class_ids, visible_class_ids, notify_class, grade_for, class_students, ser, school_class_or_404, can_access_student

router = APIRouter(prefix="/exams", tags=["exams", "results"])


def guard(db, u, class_id):
    school_class_or_404(db, u, class_id)
    if u.role == "teacher" and class_id not in teacher_class_ids(db, u):
        raise HTTPException(403, "You are not assigned to this class")


@router.post("")
def create(d: ExamIn, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    guard(db, u, d.class_id)
    db.add(m.Exam(**d.model_dump()))
    notify_class(db, d.class_id, "Exam announced", f"{d.name} on {d.exam_date}", "exam")
    db.commit()
    return {"message": "Exam created"}


@router.get("")
def list_(db: Session = Depends(get_db), u=Depends(current_user)):
    ids = visible_class_ids(db, u)
    q = db.query(m.Exam)
    if ids is not None:
        if not ids:
            return []
        q = q.filter(m.Exam.class_id.in_(ids))
    elif u.school_id:
        q = q.join(m.SchoolClass, m.SchoolClass.id == m.Exam.class_id).filter(m.SchoolClass.school_id == u.school_id)
    out = []
    for e in q.order_by(m.Exam.exam_date.desc()):
        out.append({
            **ser(e, "id", "name", "exam_date", "internal_max", "max_marks", "class_id"),
            "exam_type": getattr(e, "exam_type", None) or "exam",
            "section_id": e.section_id,
            "section": e.section.name if e.section else "",
            "start_time": getattr(e, "start_time", None) or "",
            "end_time": getattr(e, "end_time", None) or "",
            "subject": e.subject.name if e.subject else "",
            "class": e.klass.name if e.klass else "",
        })
    return out


@router.post("/results")
def enter_marks(d: MarksIn, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    e = db.get(m.Exam, d.exam_id)
    if not e:
        raise HTTPException(400, "Invalid exam/student combination")
    s = can_access_student(db, u, d.student_id)
    if s.class_id != e.class_id:
        raise HTTPException(400, "Invalid exam/student combination")
    guard(db, u, e.class_id)
    if d.internal_marks > e.internal_max or d.exam_marks > e.max_marks:
        raise HTTPException(400, f"Max internal {e.internal_max}, max exam {e.max_marks}")
    total = d.internal_marks + d.exam_marks
    pct = round(total / (e.internal_max + e.max_marks) * 100, 1)
    r = db.query(m.ExamResult).filter_by(exam_id=e.id, student_id=s.id).first() or m.ExamResult(exam_id=e.id, student_id=s.id)
    r.internal_marks, r.exam_marks, r.total, r.percentage = d.internal_marks, d.exam_marks, total, pct
    r.grade, r.passed = grade_for(pct), pct >= settings.PASS_PERCENT
    db.add(r)
    db.commit()
    return {"total": total, "percentage": pct, "grade": r.grade, "result": "Pass" if r.passed else "Fail"}


@router.get("/results")
def marks_list(exam_id: int, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    e = db.get(m.Exam, exam_id)
    if not e:
        raise HTTPException(404, "Exam not found")
    guard(db, u, e.class_id)
    return [{"student_id": r.student_id, "student": r.student.user.name, "internal": r.internal_marks, "exam": r.exam_marks,
             "total": r.total, "percentage": r.percentage, "grade": r.grade, "published": r.published}
            for r in db.query(m.ExamResult).filter_by(exam_id=exam_id)]


@router.post("/{exam_id}/publish")
def publish(exam_id: int, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    e = db.get(m.Exam, exam_id)
    if not e:
        raise HTTPException(404, "Exam not found")
    guard(db, u, e.class_id)
    db.query(m.ExamResult).filter_by(exam_id=exam_id).update({"published": True})
    notify_class(db, e.class_id, "Result published", f"Results of {e.name} ({e.subject.name}) are out", "result")
    db.commit()
    return {"message": "Results published"}
