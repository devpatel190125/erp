from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..auth.deps import roles
from ..services import student_data as sd
from ..utils.helpers import (teacher_of, teacher_class_ids, class_students, low_attendance, att_stats)

router = APIRouter(prefix="/teachers", tags=["teachers"])
tch = Depends(roles("teacher"))


@router.get("/me/classes")
def my_classes(db: Session = Depends(get_db), u=tch):
    t = teacher_of(db, u)
    rows = db.query(m.TeacherSubject).filter_by(teacher_id=t.id).all() if t else []
    return [{"class_id": r.class_id, "section_id": r.section_id, "subject_id": r.subject_id, "class": r.klass.name,
             "section": r.section.name if r.section else "All", "subject": r.subject.name,
             "label": f"{r.klass.name}{'-' + r.section.name if r.section else ''} ({r.subject.name})",
             "students": len(class_students(db, r.class_id, r.section_id))} for r in rows]


@router.get("/subjects")
def my_subjects(db: Session = Depends(get_db), u=tch):
    seen, out = set(), []
    for r in my_classes(db, u):
        if r["subject_id"] not in seen:
            seen.add(r["subject_id"])
            out.append({"id": r["subject_id"], "label": f"{r['class']} - {r['subject']}", "class_id": r["class_id"]})
    return out


@router.get("/students")
def students(class_id: int | None = None, section_id: int | None = None, db: Session = Depends(get_db), u=tch):
    allowed = teacher_class_ids(db, u)
    cids = [class_id] if class_id else allowed
    out = []
    for c in cids:
        if c not in allowed:
            raise HTTPException(403, "Not your class")
        for s in class_students(db, c, section_id):
            out.append({"student_id": s.id, "roll_no": s.roll_no, "name": s.user.name, "class": s.klass.name,
                        "section": s.section.name if s.section else "-", "attendance": att_stats(db, s.id)["percentage"]})
    return out


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), u=tch):
    from datetime import date as _date
    cls = my_classes(db, u)
    cids = teacher_class_ids(db, u)
    buckets = {"90% and above": 0, "75% - 89%": 0, "Below 75%": 0}
    for cid in cids:
        for s in class_students(db, cid):
            p = att_stats(db, s.id)["percentage"]
            buckets["90% and above" if p >= 90 else "75% - 89%" if p >= 75 else "Below 75%"] += 1
    pending_hw = 0
    today_slots = []
    notices = []
    try:
        tch_row = db.query(m.Teacher).filter_by(user_id=u.id).first()
        if tch_row:
            assigns = db.query(m.Assignment).filter_by(teacher_id=tch_row.id).all()
            for a in assigns:
                if cids and a.class_id not in cids:
                    continue
                for s in db.query(m.AssignmentSubmission).filter_by(assignment_id=a.id).all():
                    if getattr(s, "marks", None) is None:
                        pending_hw += 1
            today_name = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"][_date.today().weekday()]
            for row in db.query(m.Timetable).filter_by(teacher_id=tch_row.id, day=today_name).order_by(m.Timetable.start_time):
                today_slots.append({
                    "time": f"{row.start_time}-{row.end_time}",
                    "subject": row.subject.name if row.subject else "",
                    "class": row.klass.name if getattr(row, "klass", None) else "",
                    "section": row.section.name if row.section else "",
                    "room": row.room or "",
                })
        for n in db.query(m.Notice).order_by(m.Notice.id.desc()).limit(5):
            notices.append({"title": n.title, "body": (n.body or "")[:120], "created_at": str(getattr(n, "created_at", "") or "")[:10]})
    except Exception:
        pass
    return {
        "name": u.name, "classes": len(cls), "students": sum(c["students"] for c in cls),
        "today_sessions": len(today_slots), "pending_homework": pending_hw,
        "my_classes": cls, "low_attendance": low_attendance(db, cids)[:8],
        "attendance_buckets": buckets, "students_per_class": {c["label"]: c["students"] for c in cls},
        "today_schedule": today_slots, "recent_notices": notices,
    }


@router.get("/performance/{sid}")
def performance(sid: int, db: Session = Depends(get_db), u=tch):
    from ..utils.helpers import can_access_student
    s = can_access_student(db, u, sid)
    return {"attendance": att_stats(db, sid), "subjects": sd.subject_performance(db, s), "results": sd.results(db, s)}
