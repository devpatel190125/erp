import re
from datetime import date
from fastapi import APIRouter, Depends, HTTPException
from ..auth.deps import roles, current_user
from fastapi.responses import Response
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..auth.deps import current_user
from ..services import settings_service as ss
from ..services import student_data as sd
from ..utils.helpers import can_access_student, att_stats, grade_for, student_of, parent_children
from ..utils.pdf import PDF, W, money, rupees_in_words, text_width

router = APIRouter(prefix="/pdf", tags=["pdf"])

INK, MUTED, BRAND, LIGHT, LINE = (0.1, 0.1, 0.15), (0.42, 0.45, 0.5), (0.31, 0.27, 0.9), (0.93, 0.94, 1.0), (0.82, 0.84, 0.88)
GREEN, RED, AMBER = (0.13, 0.62, 0.3), (0.85, 0.2, 0.2), (0.85, 0.55, 0.05)


def send(pdf: PDF, name: str):
    safe = re.sub(r"[^\w.-]+", "_", name)
    return Response(pdf.output(), media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{safe}"'})


def header(p, db, title, sub=None):
    cfg = ss.get_all(db)
    p.rect(0, 0, W, 86, fill=BRAND)
    p.text(40, 40, cfg["school_name"], 21, True, (1, 1, 1), maxw=W - 80)
    line2 = "  |  ".join(x for x in (cfg["address"], cfg["phone"], cfg["email"]) if x)
    if line2:
        p.text(40, 60, line2, 9, False, (0.9, 0.92, 1), maxw=W - 80)
    p.text(W / 2, 122, title, 17, True, INK, "c")
    if sub:
        p.text(W / 2, 138, sub, 10, False, MUTED, "c")


def kv_grid(p, x, y, items, col_w=250, row_h=34):
    """items = [(label, value), ...] laid out in two columns."""
    for i, (k, v) in enumerate(items):
        cx, cy = x + (i % 2) * col_w, y + (i // 2) * row_h
        p.text(cx, cy, k, 8.5, False, MUTED)
        p.text(cx, cy + 13, v or "-", 10.5, True, INK, maxw=col_w - 14)
    return y + ((len(items) + 1) // 2) * row_h


def footer(p, y, left="Authorised signatory"):
    p.line(W - 200, y, W - 40, y, MUTED, 0.6)
    p.text(W - 120, y + 13, left, 8.5, False, MUTED, "c")
    p.text(W / 2, 820, "This is a computer-generated document.", 8, False, MUTED, "c")


def local(db, dt=None):
    return (dt or date.today()).strftime("%d %b %Y")


# ----------------------------------------------------------------- fee receipt
@router.get("/receipt/{pid}")
def receipt(pid: int, db: Session = Depends(get_db), u=Depends(current_user)):
    if u.role not in ("admin", "student", "parent"):
        raise HTTPException(403, "Receipts can be opened by the school office, the student or the parent")
    pay = db.get(m.FeePayment, pid)
    if not pay:
        raise HTTPException(404, "Payment not found")
    fee = db.get(m.Fee, pay.fee_id)
    s = can_access_student(db, u, fee.student_id)
    paid_till = sum(x.amount for x in db.query(m.FeePayment).filter(m.FeePayment.fee_id == fee.id, m.FeePayment.id <= pid))
    balance = max(0.0, fee.amount - paid_till)
    p = PDF(f"Fee receipt {pid}")
    header(p, db, "FEE RECEIPT", f"Receipt No. R-{pid:05d}   |   Date: {local(db, pay.paid_on)}")
    y = kv_grid(p, 40, 175, [("Student", s.user.name), ("Admission No.", s.admission_no),
                              ("Class / Section", f"{s.klass.name}" + (f" - {s.section.name}" if s.section else "")),
                              ("Parent / Guardian", s.parent.user.name if s.parent else "-"),
                              ("Fee type", fee.fee_type), ("Payment mode", pay.mode or "Cash")])
    p.rect(40, y + 12, W - 80, 74, fill=LIGHT)
    p.text(56, y + 34, "AMOUNT RECEIVED", 8.5, False, MUTED)
    p.text(56, y + 62, money(pay.amount), 24, True, BRAND)
    p.text(56, y + 78, rupees_in_words(pay.amount), 8.5, False, INK, maxw=W - 190)
    tag, col = ("PAID IN FULL", GREEN) if balance < 0.005 else ("PART PAYMENT", AMBER)
    p.rect(W - 160, y + 28, 104, 26, stroke=col, lw=1.4)
    p.text(W - 108, y + 45, tag, 9.5, True, col, "c")
    y += 112
    p.text(40, y, "FEE SUMMARY", 8.5, True, MUTED)
    p.line(40, y + 6, W - 40, y + 6, LINE)
    for i, (k, v, c) in enumerate([("Total fee", fee.amount, INK), ("Paid till this receipt", paid_till, GREEN), ("Balance due", balance, RED if balance else GREEN)]):
        p.text(40, y + 26 + i * 22, k, 10.5, False, INK)
        p.text(W - 40, y + 26 + i * 22, money(v), 10.5, True, c, "r")
    if fee.due_date:
        p.text(40, y + 100, f"Fee due date: {local(db, fee.due_date)}", 9, False, MUTED)
    footer(p, y + 150)
    return send(p, f"receipt_{pid}_{s.admission_no}.pdf")


# ----------------------------------------------------------------- report card
def _pick_student(db, u, student_id):
    if u.role == "student":
        return student_of(db, u)
    if u.role == "parent":
        kids = parent_children(db, u)
        if student_id:
            return can_access_student(db, u, student_id)
        if not kids:
            raise HTTPException(404, "No child linked to this parent")
        return kids[0]
    if not student_id:
        raise HTTPException(400, "student_id is required")
    return can_access_student(db, u, student_id)


@router.get("/report-card")
def report_card(student_id: int | None = None, db: Session = Depends(get_db), u=Depends(current_user)):
    if u.role == "warden":
        raise HTTPException(403, "Not allowed")
    s = _pick_student(db, u, student_id)
    rows = sd.results(db, s)
    if not rows:
        raise HTTPException(404, "No published results yet for this student")
    ay = db.query(m.AcademicYear).filter_by(is_current=True).first()
    att = att_stats(db, s.id)
    avg = round(sum(r["percentage"] for r in rows) / len(rows), 1)
    all_pass = all(r["result"] == "Pass" for r in rows)
    p = PDF(f"Report card {s.admission_no}")
    header(p, db, "REPORT CARD", f"Academic year {ay.name}" if ay else None)
    y = kv_grid(p, 40, 170, [("Student", s.user.name), ("Admission No.", s.admission_no),
                              ("Class / Section", f"{s.klass.name}" + (f" - {s.section.name}" if s.section else "")), ("Roll No.", str(s.roll_no or "-")),
                              ("Date of birth", s.dob.strftime("%d %b %Y") if s.dob else "-"), ("Parent / Guardian", s.parent.user.name if s.parent else "-")])
    cols = [("Subject", 40, "l"), ("Internal", 300, "r"), ("Exam", 355, "r"), ("Total", 410, "r"), ("%", 460, "r"), ("Grade", 500, "r"), ("Result", 555, "r")]

    def table_header(yy, title):
        p.rect(40, yy, W - 80, 20, fill=BRAND)
        p.text(46, yy + 14, title, 9.5, True, (1, 1, 1), maxw=240)
        for name, x, al in cols[1:]:
            p.text(x, yy + 14, name, 8.5, True, (1, 1, 1), al)
        return yy + 20
    y += 14
    groups = {}
    for r in rows:
        groups.setdefault(r["exam"], []).append(r)
    for exam, items in groups.items():
        if y + 20 * (len(items) + 2) > 770:
            p.page()
            y = 50
        y = table_header(y, exam)
        for i, r in enumerate(items):
            if i % 2:
                p.rect(40, y, W - 80, 19, fill=(0.97, 0.97, 0.99))
            p.text(46, y + 13, r["subject"], 9.5, False, INK, maxw=240)
            for (name, x, al), val in zip(cols[1:], (f"{r['internal']:g}", f"{r['exam_marks']:g}", f"{r['total']:g}", f"{r['percentage']:g}", r["grade"], r["result"])):
                p.text(x, y + 13, val, 9.5, name in ("Grade", "Result"), (GREEN if val == "Pass" else RED if val == "Fail" else INK), al)
            y += 19
        p.line(40, y, W - 40, y, LINE)
        y += 16
    if y > 600:
        p.page()
        y = 50
    # summary
    p.rect(40, y, W - 80, 62, fill=LIGHT)
    for i, (k, v, c) in enumerate([("OVERALL %", f"{avg:g}%", BRAND), ("GRADE", grade_for(avg), BRAND), ("ATTENDANCE", f"{att['percentage']:g}%", GREEN if att["percentage"] >= ss.low_threshold(db) else RED),
                                   ("RESULT", "PASS" if all_pass else "NEEDS IMPROVEMENT", GREEN if all_pass else RED)]):
        cx = 60 + i * 125
        p.text(cx, y + 22, k, 8.5, False, MUTED)
        p.text(cx, y + 46, v, 15 if i < 3 else 11, True, c)
    y += 84
    # subject bars
    perf = sd.subject_performance(db, s)
    if perf and y < 650:
        p.text(40, y, "SUBJECT PERFORMANCE", 8.5, True, MUTED)
        y += 12
        for k, v in list(perf.items())[:8]:
            p.text(40, y + 9, k, 9, False, INK, maxw=120)
            p.rect(165, y, 300, 10, fill=(0.9, 0.91, 0.95))
            p.rect(165, y, 300 * min(v, 100) / 100, 10, fill=GREEN if v >= 75 else AMBER if v >= 50 else RED)
            p.text(472, y + 9, f"{v:g}%", 9, True, INK)
            y += 17
        y += 8
    y = max(y + 30, 740)
    for i, label in enumerate(("Class teacher", "Parent / Guardian", "Principal")):
        x = 40 + i * 180
        p.line(x, y, x + 140, y, MUTED, 0.6)
        p.text(x + 70, y + 12, label, 8.5, False, MUTED, "c")
    p.text(W / 2, 820, "This is a computer-generated document.", 8, False, MUTED, "c")
    return send(p, f"report_card_{s.admission_no}.pdf")


@router.get("/class-report-card")
def class_report_card(exam_id: int, db: Session = Depends(get_db), u=Depends(roles("admin", "teacher"))):
    """PDF: all students marks for one exam."""
    e = db.get(m.Exam, exam_id)
    if not e:
        raise HTTPException(404, "Exam not found")
    results = db.query(m.ExamResult).filter_by(exam_id=exam_id).all()
    school = db.get(m.School, u.school_id) if u.school_id else None
    pdf = PDF()
    pdf.add_page()
    title = school.name if school else "School ERP"
    pdf.text(W / 2, 40, title, 16, True, BRAND, "c")
    pdf.text(W / 2, 58, f"Class result — {e.name}", 12, True, INK, "c")
    sub = e.subject.name if e.subject else ""
    cls = e.klass.name if getattr(e, "klass", None) else ""
    pdf.text(W / 2, 74, f"{cls} · {sub} · {e.exam_date or ''}", 9, False, MUTED, "c")
    y = 95
    headers = [("Roll", 50), ("Student", 160), ("Int", 45), ("Exam", 45), ("Total", 50), ("%", 45), ("Grade", 50)]
    x = 40
    for h, w in headers:
        pdf.text(x, y, h, 8, True, MUTED)
        x += w
    y += 14
    pdf.line(40, y - 4, W - 40, y - 4, MUTED, 0.5)
    for r in sorted(results, key=lambda r: (r.student.roll_no or 0) if r.student else 0):
        if y > 780:
            pdf.add_page()
            y = 50
        x = 40
        vals = [
            str(r.student.roll_no or "") if r.student else "",
            ((r.student.user.name if r.student and r.student.user else "") or "")[:22],
            f"{r.internal_marks:g}" if r.internal_marks is not None else "",
            f"{r.exam_marks:g}" if r.exam_marks is not None else "",
            f"{r.total:g}" if r.total is not None else "",
            f"{r.percentage:g}" if r.percentage is not None else "",
            r.grade or "",
        ]
        for (h, w), v in zip(headers, vals):
            pdf.text(x, y, str(v), 9, False, INK)
            x += w
        y += 16
    pdf.text(W / 2, 820, "Computer-generated class result sheet.", 8, False, MUTED, "c")
    return send(pdf, f"class_result_exam_{exam_id}.pdf")

