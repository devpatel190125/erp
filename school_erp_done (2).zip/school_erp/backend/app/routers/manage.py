"""Edit / delete endpoints (the original project could only add + list).

Rules used everywhere:
 - people are never hard-deleted (is_active=False) so old attendance / marks / fees stay intact
 - master data (class, section, subject, room ...) can only be deleted when nothing uses it (409 otherwise)
 - PUT bodies are partial: send only the fields you want to change
"""
from datetime import date
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import MOB, TimetableIn, NoticeIn, EventIn
from ..auth.deps import roles
from ..utils.helpers import teacher_of, teacher_class_ids
from .admin import make_user

router = APIRouter(tags=["manage"])
adm = Depends(roles("admin"))


# ---------------- helpers ----------------
def get_or_404(db, model, oid, what="Record"):
    o = db.get(model, oid)
    if not o:
        raise HTTPException(404, f"{what} not found")
    return o


def in_use(db, what, *checks):
    for model, col, val in checks:
        if db.query(model).filter(col == val).count():
            raise HTTPException(409, f"Cannot delete: {what} is still used by {model.__tablename__.replace('_', ' ')}. "
                                     "Remove or move those first.")


def set_contact(db, user, name=None, mobile=None, email=None, email_given=False):
    if mobile and mobile != user.mobile:
        if db.query(m.User).filter(m.User.mobile == mobile, m.User.id != user.id).first():
            raise HTTPException(409, f"Mobile {mobile} is already registered")
        user.mobile = mobile
    if email_given:
        email = (email or "").strip() or None
        if email and "@" not in email:
            raise HTTPException(422, "Invalid email address")
        if email and db.query(m.User).filter(m.User.email == email, m.User.id != user.id).first():
            raise HTTPException(409, "Email already registered")
        user.email = email
    if name:
        user.name = name


class PersonUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=120)
    mobile: Optional[str] = Field(None, pattern=MOB)
    email: Optional[str] = None
    employee_no: Optional[str] = None


def update_person(db, user, d: PersonUpdate):
    v = d.model_dump(exclude_unset=True)
    set_contact(db, user, v.get("name"), v.get("mobile"), v.get("email"), "email" in v)


# ---------------- students ----------------
class StudentUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=120)
    mobile: Optional[str] = Field(None, pattern=MOB)
    email: Optional[str] = None
    admission_no: Optional[str] = Field(None, min_length=1, max_length=30)
    roll_no: Optional[int] = None
    class_id: Optional[int] = None
    section_id: Optional[int] = None
    dob: Optional[date] = None
    gender: Optional[str] = Field(None, pattern="^(M|F)$")
    is_hostel: Optional[bool] = None
    parent_name: Optional[str] = None
    parent_mobile: Optional[str] = Field(None, pattern=MOB)


@router.get("/admin/students/{sid}")
def student_detail(sid: int, db: Session = Depends(get_db), u=adm):
    s = get_or_404(db, m.Student, sid, "Student")
    return {"id": s.id, "name": s.user.name, "mobile": s.user.mobile, "email": s.user.email,
            "admission_no": s.admission_no, "roll_no": s.roll_no, "class_id": s.class_id, "section_id": s.section_id,
            "dob": s.dob.isoformat() if s.dob else None, "gender": s.gender, "is_hostel": bool(s.is_hostel),
            "parent_name": s.parent.user.name if s.parent else None,
            "parent_mobile": s.parent.user.mobile if s.parent else None}


@router.put("/admin/students/{sid}")
def edit_student(sid: int, d: StudentUpdate, db: Session = Depends(get_db), u=adm):
    s = get_or_404(db, m.Student, sid, "Student")
    v = d.model_dump(exclude_unset=True)
    if "admission_no" in v and v["admission_no"] != s.admission_no:
        if db.query(m.Student).filter(m.Student.admission_no == v["admission_no"], m.Student.id != s.id).first():
            raise HTTPException(409, "Admission number already exists")
        s.admission_no = v["admission_no"]
    new_class = v.get("class_id") or s.class_id
    if not db.get(m.SchoolClass, new_class):
        raise HTTPException(400, "Invalid class")
    class_changed = new_class != s.class_id
    new_sec = v["section_id"] if "section_id" in v else (None if class_changed else s.section_id)
    if new_sec:
        sec = db.get(m.Section, new_sec)
        if not sec or sec.class_id != new_class:
            raise HTTPException(400, "That section does not belong to the selected class")
    set_contact(db, s.user, v.get("name"), v.get("mobile"), v.get("email"), "email" in v)
    for f in ("roll_no", "dob", "gender"):
        if f in v:
            setattr(s, f, v[f])
    if "is_hostel" in v and v["is_hostel"] is not None:
        s.is_hostel = v["is_hostel"]
        if not s.is_hostel:   # leaving the hostel frees the bed
            db.query(m.HostelAllocation).filter_by(student_id=s.id).delete()
    # parent: link to (or create) the parent with this mobile; plain rename otherwise
    if v.get("parent_mobile"):
        pu = db.query(m.User).filter_by(mobile=v["parent_mobile"], role="parent").first()
        if not pu:
            pu = make_user(db, "parent", v.get("parent_name") or f"Parent of {s.user.name}", v["parent_mobile"])
            db.add(m.Parent(user_id=pu.id))
            db.flush()
        elif v.get("parent_name"):
            pu.name = v["parent_name"]
        s.parent_id = db.query(m.Parent).filter_by(user_id=pu.id).first().id
    elif v.get("parent_name") and s.parent:
        s.parent.user.name = v["parent_name"]
    if class_changed or new_sec != s.section_id:
        s.class_id, s.section_id = new_class, new_sec
        ay = db.query(m.AcademicYear).filter_by(is_current=True).first()
        row = db.query(m.StudentClass).filter_by(student_id=s.id, academic_year_id=ay.id if ay else None).first()
        if row:
            row.class_id, row.section_id = new_class, new_sec
        else:
            db.add(m.StudentClass(student_id=s.id, class_id=new_class, section_id=new_sec,
                                  academic_year_id=ay.id if ay else None))
    db.commit()
    return {"message": "Student updated"}


# ---------------- teachers / wardens / parents ----------------
@router.put("/admin/teachers/{tid}")
def edit_teacher(tid: int, d: PersonUpdate, db: Session = Depends(get_db), u=adm):
    t = get_or_404(db, m.Teacher, tid, "Teacher")
    update_person(db, t.user, d)
    if "employee_no" in d.model_fields_set:
        t.employee_no = d.employee_no
    db.commit()
    return {"message": "Teacher updated"}


@router.delete("/admin/teachers/{tid}")
def remove_teacher(tid: int, db: Session = Depends(get_db), u=adm):
    t = get_or_404(db, m.Teacher, tid, "Teacher")
    t.user.is_active = False
    db.commit()
    return {"message": "Teacher deactivated"}


@router.put("/admin/wardens/{wid}")
def edit_warden(wid: int, d: PersonUpdate, db: Session = Depends(get_db), u=adm):
    w = get_or_404(db, m.HostelWarden, wid, "Warden")
    update_person(db, w.user, d)
    db.commit()
    return {"message": "Warden updated"}


@router.delete("/admin/wardens/{wid}")
def remove_warden(wid: int, db: Session = Depends(get_db), u=adm):
    w = get_or_404(db, m.HostelWarden, wid, "Warden")
    w.user.is_active = False
    db.commit()
    return {"message": "Warden deactivated"}


@router.put("/admin/parents/{pid}")
def edit_parent(pid: int, d: PersonUpdate, db: Session = Depends(get_db), u=adm):
    p = get_or_404(db, m.Parent, pid, "Parent")
    update_person(db, p.user, d)
    db.commit()
    return {"message": "Parent updated"}


# ---------------- classes / sections / subjects / teacher assignment ----------------
class NameUpdate(BaseModel):
    name: str = Field(min_length=1, max_length=80)


@router.put("/admin/classes/{cid}")
def edit_class(cid: int, d: NameUpdate, db: Session = Depends(get_db), u=adm):
    c = get_or_404(db, m.SchoolClass, cid, "Class")
    if db.query(m.SchoolClass).filter(m.SchoolClass.name == d.name, m.SchoolClass.id != cid).first():
        raise HTTPException(409, "A class with this name already exists")
    c.name = d.name
    db.commit()
    return {"message": "Class renamed"}


@router.delete("/admin/classes/{cid}")
def delete_class(cid: int, db: Session = Depends(get_db), u=adm):
    c = get_or_404(db, m.SchoolClass, cid, "Class")
    in_use(db, "this class", (m.Student, m.Student.class_id, cid), (m.Section, m.Section.class_id, cid),
           (m.Subject, m.Subject.class_id, cid), (m.Exam, m.Exam.class_id, cid), (m.Timetable, m.Timetable.class_id, cid))
    db.delete(c)
    db.commit()
    return {"message": "Class deleted"}


@router.put("/admin/sections/{sid}")
def edit_section(sid: int, d: NameUpdate, db: Session = Depends(get_db), u=adm):
    s = get_or_404(db, m.Section, sid, "Section")
    if db.query(m.Section).filter(m.Section.class_id == s.class_id, m.Section.name == d.name, m.Section.id != sid).first():
        raise HTTPException(409, "That section already exists in this class")
    s.name = d.name
    db.commit()
    return {"message": "Section renamed"}


@router.delete("/admin/sections/{sid}")
def delete_section(sid: int, db: Session = Depends(get_db), u=adm):
    s = get_or_404(db, m.Section, sid, "Section")
    in_use(db, "this section", (m.Student, m.Student.section_id, sid), (m.Timetable, m.Timetable.section_id, sid),
           (m.TeacherSubject, m.TeacherSubject.section_id, sid))
    db.delete(s)
    db.commit()
    return {"message": "Section deleted"}


@router.put("/admin/subjects/{sid}")
def edit_subject(sid: int, d: NameUpdate, db: Session = Depends(get_db), u=adm):
    s = get_or_404(db, m.Subject, sid, "Subject")
    if db.query(m.Subject).filter(m.Subject.class_id == s.class_id, m.Subject.name == d.name, m.Subject.id != sid).first():
        raise HTTPException(409, "That subject already exists in this class")
    s.name = d.name
    db.commit()
    return {"message": "Subject renamed"}


@router.delete("/admin/subjects/{sid}")
def delete_subject(sid: int, db: Session = Depends(get_db), u=adm):
    s = get_or_404(db, m.Subject, sid, "Subject")
    in_use(db, "this subject", (m.Exam, m.Exam.subject_id, sid), (m.Timetable, m.Timetable.subject_id, sid),
           (m.TeacherSubject, m.TeacherSubject.subject_id, sid), (m.Homework, m.Homework.subject_id, sid),
           (m.Assignment, m.Assignment.subject_id, sid), (m.StudyMaterial, m.StudyMaterial.subject_id, sid))
    db.delete(s)
    db.commit()
    return {"message": "Subject deleted"}


@router.delete("/admin/teacher-subjects/{rid}")
def unassign_teacher(rid: int, db: Session = Depends(get_db), u=adm):
    db.delete(get_or_404(db, m.TeacherSubject, rid, "Assignment"))
    db.commit()
    return {"message": "Teacher unassigned"}


# ---------------- fees ----------------
class FeeUpdate(BaseModel):
    fee_type: Optional[str] = Field(None, pattern="^(Tuition|Exam|Transport|Hostel|Other)$")
    amount: Optional[float] = Field(None, gt=0)
    due_date: Optional[date] = None


def _paid(db, fee_id):
    return sum(p.amount for p in db.query(m.FeePayment).filter_by(fee_id=fee_id))


@router.put("/fees/{fid}")
def edit_fee(fid: int, d: FeeUpdate, db: Session = Depends(get_db), u=adm):
    f = get_or_404(db, m.Fee, fid, "Fee")
    v = d.model_dump(exclude_unset=True)
    if v.get("amount") is not None and v["amount"] < _paid(db, fid) - 0.001:
        raise HTTPException(400, f"Amount cannot be less than what is already paid ({_paid(db, fid):g})")
    for k, val in v.items():
        if val is not None:
            setattr(f, k, val)
    db.commit()
    return {"message": "Fee updated"}


@router.delete("/fees/{fid}")
def delete_fee(fid: int, db: Session = Depends(get_db), u=adm):
    f = get_or_404(db, m.Fee, fid, "Fee")
    if _paid(db, fid) > 0:
        raise HTTPException(409, "Payments exist for this fee. Delete the payment(s) first.")
    db.delete(f)
    db.commit()
    return {"message": "Fee deleted"}


@router.delete("/fees/payment/{pid}")
def delete_payment(pid: int, db: Session = Depends(get_db), u=adm):
    db.delete(get_or_404(db, m.FeePayment, pid, "Payment"))
    db.commit()
    return {"message": "Payment deleted"}


# ---------------- timetable ----------------
@router.put("/timetable/{tid}")
def edit_period(tid: int, d: TimetableIn, db: Session = Depends(get_db), u=adm):
    t = get_or_404(db, m.Timetable, tid, "Period")
    if d.start_time >= d.end_time:
        raise HTTPException(400, "End time must be after start time")
    clash = db.query(m.Timetable).filter(m.Timetable.class_id == d.class_id, m.Timetable.section_id == d.section_id,
                                         m.Timetable.day == d.day, m.Timetable.start_time == d.start_time,
                                         m.Timetable.id != tid).first()
    if clash:
        raise HTTPException(409, "A period already exists at that time")
    for k, val in d.model_dump().items():
        setattr(t, k, val)
    db.commit()
    return {"message": "Period updated"}


@router.delete("/timetable/{tid}")
def delete_period(tid: int, db: Session = Depends(get_db), u=adm):
    db.delete(get_or_404(db, m.Timetable, tid, "Period"))
    db.commit()
    return {"message": "Period deleted"}


# ---------------- exams ----------------
class ExamUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    exam_date: Optional[date] = None
    internal_max: Optional[int] = Field(None, gt=0)
    max_marks: Optional[int] = Field(None, gt=0)


def _exam_guard(db, u, e):
    if u.role == "teacher" and e.class_id not in teacher_class_ids(db, u):
        raise HTTPException(403, "You are not assigned to this class")


@router.put("/exams/{eid}")
def edit_exam(eid: int, d: ExamUpdate, db: Session = Depends(get_db), u=Depends(roles("admin", "teacher"))):
    e = get_or_404(db, m.Exam, eid, "Exam")
    _exam_guard(db, u, e)
    v = {k: x for k, x in d.model_dump(exclude_unset=True).items() if x is not None}
    has_results = db.query(m.ExamResult).filter_by(exam_id=eid).count() > 0
    if has_results and ({"internal_max", "max_marks"} & v.keys()):
        raise HTTPException(409, "Marks are already entered - max marks can no longer be changed")
    for k, val in v.items():
        setattr(e, k, val)
    db.commit()
    return {"message": "Exam updated"}


@router.delete("/exams/{eid}")
def delete_exam(eid: int, db: Session = Depends(get_db), u=Depends(roles("admin", "teacher"))):
    e = get_or_404(db, m.Exam, eid, "Exam")
    _exam_guard(db, u, e)
    in_use(db, "this exam (marks entered)", (m.ExamResult, m.ExamResult.exam_id, eid))
    db.delete(e)
    db.commit()
    return {"message": "Exam deleted"}


# ---------------- notices / events ----------------
def _notice_guard(u, n):
    if u.role != "admin" and n.created_by != u.id:
        raise HTTPException(403, "You can only change notices you created")


@router.put("/notifications/notices/{nid}")
def edit_notice(nid: int, d: NoticeIn, db: Session = Depends(get_db), u=Depends(roles("admin", "teacher", "warden"))):
    n = get_or_404(db, m.Notice, nid, "Notice")
    _notice_guard(u, n)
    n.title, n.body, n.audience = d.title, d.body, d.audience
    db.commit()
    return {"message": "Notice updated"}


@router.delete("/notifications/notices/{nid}")
def delete_notice(nid: int, db: Session = Depends(get_db), u=Depends(roles("admin", "teacher", "warden"))):
    n = get_or_404(db, m.Notice, nid, "Notice")
    _notice_guard(u, n)
    db.delete(n)
    db.commit()
    return {"message": "Notice deleted"}


@router.put("/notifications/events/{eid}")
def edit_event(eid: int, d: EventIn, db: Session = Depends(get_db), u=adm):
    e = get_or_404(db, m.Event, eid, "Event")
    e.title, e.description, e.event_date = d.title, d.description, d.event_date
    db.commit()
    return {"message": "Event updated"}


@router.delete("/notifications/events/{eid}")
def delete_event(eid: int, db: Session = Depends(get_db), u=adm):
    db.delete(get_or_404(db, m.Event, eid, "Event"))
    db.commit()
    return {"message": "Event deleted"}


# ---------------- homework / assignments ----------------
class WorkUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=2, max_length=150)
    description: Optional[str] = None
    due_date: Optional[date] = None
    max_marks: Optional[int] = Field(None, gt=0)


def _work_guard(db, u, obj):
    if u.role == "teacher" and obj.teacher_id != teacher_of(db, u).id:
        raise HTTPException(403, "This is not your homework/assignment")


def _apply_work(obj, d: WorkUpdate, allow_marks):
    for k, val in d.model_dump(exclude_unset=True).items():
        if k == "max_marks" and not allow_marks:
            continue
        if val is not None or k in ("description", "due_date"):
            setattr(obj, k, val)


@router.put("/homework/{hid}")
def edit_homework(hid: int, d: WorkUpdate, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    h = get_or_404(db, m.Homework, hid, "Homework")
    _work_guard(db, u, h)
    _apply_work(h, d, False)
    db.commit()
    return {"message": "Homework updated"}


@router.delete("/homework/{hid}")
def delete_homework(hid: int, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    h = get_or_404(db, m.Homework, hid, "Homework")
    _work_guard(db, u, h)
    db.delete(h)
    db.commit()
    return {"message": "Homework deleted"}


@router.put("/assignments/{aid}")
def edit_assignment(aid: int, d: WorkUpdate, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    a = get_or_404(db, m.Assignment, aid, "Assignment")
    _work_guard(db, u, a)
    _apply_work(a, d, True)
    db.commit()
    return {"message": "Assignment updated"}


@router.delete("/assignments/{aid}")
def delete_assignment(aid: int, db: Session = Depends(get_db), u=Depends(roles("teacher", "admin"))):
    a = get_or_404(db, m.Assignment, aid, "Assignment")
    _work_guard(db, u, a)
    in_use(db, "this assignment (students already submitted)",
           (m.AssignmentSubmission, m.AssignmentSubmission.assignment_id, aid))
    db.delete(a)
    db.commit()
    return {"message": "Assignment deleted"}


# ---------------- hostel ----------------
class RoomUpdate(BaseModel):
    room_no: Optional[str] = Field(None, min_length=1, max_length=10)
    capacity: Optional[int] = Field(None, ge=1, le=20)


ward = Depends(roles("warden", "admin"))


@router.put("/hostel/rooms/{rid}")
def edit_room(rid: int, d: RoomUpdate, db: Session = Depends(get_db), u=ward):
    r = get_or_404(db, m.HostelRoom, rid, "Room")
    occ = db.query(m.HostelAllocation).filter_by(room_id=rid).count()
    if d.capacity is not None and d.capacity < occ:
        raise HTTPException(400, f"{occ} students already live in this room - capacity cannot be below that")
    if d.room_no and d.room_no != r.room_no:
        if db.query(m.HostelRoom).filter(m.HostelRoom.hostel_id == r.hostel_id, m.HostelRoom.room_no == d.room_no).first():
            raise HTTPException(409, "Room already exists")
        r.room_no = d.room_no
    if d.capacity is not None:
        r.capacity = d.capacity
    db.commit()
    return {"message": "Room updated"}


@router.delete("/hostel/rooms/{rid}")
def delete_room(rid: int, db: Session = Depends(get_db), u=ward):
    r = get_or_404(db, m.HostelRoom, rid, "Room")
    in_use(db, "this room (students allocated)", (m.HostelAllocation, m.HostelAllocation.room_id, rid))
    db.delete(r)
    db.commit()
    return {"message": "Room deleted"}


@router.post("/hostel/visitors/{vid}/checkout")
def visitor_checkout(vid: int, db: Session = Depends(get_db), u=ward):
    from datetime import datetime
    v = get_or_404(db, m.HostelVisitor, vid, "Visitor")
    if v.out_time:
        raise HTTPException(409, "Visitor already checked out")
    v.out_time = datetime.utcnow()
    db.commit()
    return {"message": "Visitor checked out"}
