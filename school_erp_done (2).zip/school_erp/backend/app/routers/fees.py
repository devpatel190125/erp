from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import FeeIn, PaymentIn, FeeHeadIn
from ..auth.deps import roles, current_user
from ..services import student_data as sd
from ..utils.helpers import can_access_student, class_students, notify

router = APIRouter(prefix="/fees", tags=["fees"])
adm = Depends(roles("admin"))


@router.post("")
def create(d: FeeIn, db: Session = Depends(get_db), u=adm):
    if d.student_id:
        s = can_access_student(db, u, d.student_id)
        targets = [s]
    elif d.class_id:
        # class must belong to this school
        cls = db.get(m.SchoolClass, d.class_id)
        if not cls or (u.school_id and cls.school_id != u.school_id):
            raise HTTPException(404, "Class not found")
        targets = class_students(db, d.class_id)
    else:
        raise HTTPException(400, "Provide student_id or class_id")
    if not targets:
        raise HTTPException(404, "Student not found")
    for s in targets:
        db.add(m.Fee(student_id=s.id, fee_type=d.fee_type, amount=d.amount, due_date=d.due_date))
    db.commit()
    return {"message": f"Fee added for {len(targets)} student(s)"}


@router.post("/payment")
def pay(d: PaymentIn, db: Session = Depends(get_db), u=adm):
    # Lock fee row to reduce concurrent overpay races
    f = db.query(m.Fee).filter_by(id=d.fee_id).with_for_update().first()
    if not f:
        raise HTTPException(404, "Fee not found")
    can_access_student(db, u, f.student_id)
    if d.amount is None or d.amount <= 0:
        raise HTTPException(400, "Amount must be positive")
    paid = sum(p.amount for p in db.query(m.FeePayment).filter_by(fee_id=f.id))
    pending = f.amount - paid
    if d.amount > pending + 0.001:
        raise HTTPException(400, f"Amount exceeds pending balance ({pending:g})")
    db.add(m.FeePayment(fee_id=f.id, amount=d.amount, mode=d.mode))
    notify(db, f.student.user_id, "Fee payment received", f"₹{d.amount:g} for {f.fee_type}", "fee")
    db.commit()
    return {"message": "Payment recorded"}


@router.get("/report")
def report(db: Session = Depends(get_db), u=adm):
    out = []
    q = db.query(m.Fee).join(m.Student).join(m.User).filter(m.User.is_active == True)  # noqa
    if u.school_id:
        q = q.filter(m.User.school_id == u.school_id)
    for f in q.order_by(m.Fee.id.desc()):
        pays = db.query(m.FeePayment).filter_by(fee_id=f.id).order_by(m.FeePayment.id).all()
        paid = sum(p.amount for p in pays)
        out.append({"fee_id": f.id, "id": f.id, "student_id": f.student_id, "last_payment_id": pays[-1].id if pays else None, "student": f.student.user.name, "class": f.student.klass.name, "fee_type": f.fee_type,
                    "total": f.amount, "amount": f.amount, "paid": paid, "pending": f.amount - paid,
                    "due_date": f.due_date.isoformat() if f.due_date else None})
    return out


@router.post("/remind")
def remind(db: Session = Depends(get_db), u=adm):
    n = 0
    q = db.query(m.Student).join(m.User).filter(m.User.is_active == True)  # noqa
    if u.school_id:
        q = q.filter(m.User.school_id == u.school_id)
    for s in q.all():
        pend = sum(f["pending"] for f in sd.fees(db, s))
        if pend > 0:
            for uid in {s.user_id, s.parent.user_id if s.parent else None}:
                notify(db, uid, "Fee reminder", f"Pending fees for {s.user.name}: ₹{pend:g}", "fee")
            n += 1
    db.commit()
    return {"message": f"Reminders sent for {n} students"}


@router.get("/student/{sid}")
def student_fees(sid: int, db: Session = Depends(get_db), u=Depends(current_user)):
    return sd.fees(db, can_access_student(db, u, sid))


@router.get("/daybook")
def daybook(from_date: str | None = None, to_date: str | None = None, db: Session = Depends(get_db), u=adm):
    """Payments for a day (default today) or date range."""
    from datetime import date as date_cls
    today = date_cls.today()
    try:
        start = date_cls.fromisoformat(from_date) if from_date else today
        end = date_cls.fromisoformat(to_date) if to_date else start
    except ValueError:
        raise HTTPException(422, "Invalid date format (use YYYY-MM-DD)")
    q = (db.query(m.FeePayment, m.Fee, m.Student, m.User)
         .join(m.Fee, m.Fee.id == m.FeePayment.fee_id)
         .join(m.Student, m.Student.id == m.Fee.student_id)
         .join(m.User, m.User.id == m.Student.user_id)
         .filter(m.FeePayment.paid_on >= start, m.FeePayment.paid_on <= end, m.User.is_active == True))  # noqa
    if u.school_id:
        q = q.filter(m.User.school_id == u.school_id)
    rows = q.order_by(m.FeePayment.paid_on.desc(), m.FeePayment.id.desc()).all()
    out, total = [], 0.0
    for p, f, st, usr in rows:
        total += p.amount
        out.append({
            "id": p.id, "paid_on": p.paid_on.isoformat() if p.paid_on else None,
            "amount": p.amount, "mode": p.mode,
            "student": usr.name if usr else "",
            "class": st.klass.name if st and st.klass else "",
            "fee_type": f.fee_type if f else "",
            "fee_id": p.fee_id,
        })
    return {"from": start.isoformat(), "to": end.isoformat(), "total": round(total, 2), "count": len(out), "payments": out}


@router.get("/class-report")
def class_report(class_id: int | None = None, db: Session = Depends(get_db), u=adm):
    """Class-wise fee summary."""
    cq = db.query(m.SchoolClass)
    if u.school_id:
        cq = cq.filter(m.SchoolClass.school_id == u.school_id)
    if class_id:
        cq = cq.filter(m.SchoolClass.id == class_id)
    classes = cq.order_by(m.SchoolClass.id).all()
    out = []
    for c in classes:
        students = class_students(db, c.id)
        total = paid = pending = 0.0
        due_students = 0
        for s in students:
            fees = db.query(m.Fee).filter_by(student_id=s.id).all()
            st_pending = 0.0
            for f in fees:
                p = sum(x.amount for x in db.query(m.FeePayment).filter_by(fee_id=f.id).all())
                total += f.amount
                paid += p
                st_pending += max(0, f.amount - p)
            pending += st_pending
            if st_pending > 0.01:
                due_students += 1
        out.append({
            "class_id": c.id, "class": c.name, "students": len(students),
            "total": round(total, 2), "paid": round(paid, 2), "pending": round(pending, 2),
            "due_students": due_students,
        })
    return out



@router.get("/heads")
def list_heads(db: Session = Depends(get_db), u=Depends(current_user)):
    sid = getattr(u, "school_id", None)
    q = db.query(m.FeeHead).filter(m.FeeHead.is_active == True)  # noqa
    if sid:
        q = q.filter((m.FeeHead.school_id == sid) | (m.FeeHead.school_id.is_(None)))
    rows = q.order_by(m.FeeHead.name).all()
    if not rows:
        # defaults
        return [{"id": 0, "name": n, "default_amount": 0} for n in
                ("Tuition", "Exam", "Transport", "Hostel", "Lab", "Library", "Sports", "Other")]
    return [{"id": h.id, "name": h.name, "default_amount": h.default_amount,
             "frequency": getattr(h, "frequency", None) or "Monthly",
             "applicable_classes": getattr(h, "applicable_classes", None) or ""} for h in rows]


@router.post("/heads")
def add_head(d: FeeHeadIn, db: Session = Depends(get_db), u=adm):
    sid = getattr(u, "school_id", None)
    if db.query(m.FeeHead).filter_by(school_id=sid, name=d.name).first():
        raise HTTPException(409, "Fee head already exists")
    db.add(m.FeeHead(
        school_id=sid, name=d.name.strip(), default_amount=d.default_amount,
        frequency=d.frequency or "Monthly",
        applicable_classes=d.applicable_classes or "",
    ))
    db.commit()
    return {"message": f"Fee head '{d.name}' added"}


@router.put("/heads/{hid}")
def edit_head(hid: int, d: FeeHeadIn, db: Session = Depends(get_db), u=adm):
    h = db.get(m.FeeHead, hid)
    if not h:
        raise HTTPException(404, "Not found")
    h.name = d.name.strip()
    h.default_amount = d.default_amount
    h.frequency = d.frequency or h.frequency
    h.applicable_classes = d.applicable_classes if d.applicable_classes is not None else h.applicable_classes
    db.commit()
    return {"message": "Fee structure updated"}


@router.delete("/heads/{hid}")
def del_head(hid: int, db: Session = Depends(get_db), u=adm):
    h = db.get(m.FeeHead, hid)
    if not h:
        raise HTTPException(404, "Not found")
    h.is_active = False
    db.commit()
    return {"message": "Fee structure deactivated"}
