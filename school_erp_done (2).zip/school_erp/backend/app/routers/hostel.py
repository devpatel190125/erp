from datetime import date, timedelta
from typing import Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import RoomIn, AllocIn, HostelAttIn, VisitorIn, HostelComplaintIn, BlockIn
from ..auth.deps import roles, current_user
from ..utils.helpers import school_hostel, require_school, can_access_student
from ..ai.hostel_ai import analyze_hostel_complaint
from ..utils.helpers import ser, notify, student_of

router = APIRouter(prefix="/hostel", tags=["hostel"])
ward = Depends(roles("warden", "admin"))


def occupancy(db, room):
    return db.query(m.HostelAllocation).filter_by(room_id=room.id).count()



@router.get("/blocks")
def list_blocks(db: Session = Depends(get_db), u=ward):
    h = school_hostel(db, u, create=True)
    if not h:
        return []
    out = []
    for b in db.query(m.HostelBlock).filter_by(hostel_id=h.id).order_by(m.HostelBlock.name):
        rooms = db.query(m.HostelRoom).filter_by(hostel_id=h.id, block=b.name).all()
        out.append({
            "id": b.id, "name": b.name, "floors": b.floors,
            "rooms": len(rooms),
            "beds": sum(r.capacity for r in rooms),
            "occupied": sum(db.query(m.HostelAllocation).filter_by(room_id=r.id).count() for r in rooms),
            "label": f"Block {b.name} ({b.floors} floors)",
        })
    return out


@router.post("/blocks")
def add_block(d: BlockIn, db: Session = Depends(get_db), u=ward):
    h = school_hostel(db, u, create=True)
    if not h:
        raise HTTPException(400, "No hostel for this school")
    if db.query(m.HostelBlock).filter_by(hostel_id=h.id, name=d.name).first():
        raise HTTPException(409, f"Block {d.name} already exists")
    db.add(m.HostelBlock(hostel_id=h.id, name=d.name.strip(), floors=d.floors))
    db.commit()
    return {"message": f"Block {d.name} added with {d.floors} floors"}


@router.get("/floors")
def floors_for_block(block: str, db: Session = Depends(get_db), u=ward):
    h = school_hostel(db, u, create=True)
    if not h:
        return []
    b = db.query(m.HostelBlock).filter_by(hostel_id=h.id, name=block).first()
    n = b.floors if b else 5
    return [{"id": i, "name": str(i), "label": f"Floor {i}"} for i in range(1, n + 1)]


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), u=ward):
    h = school_hostel(db, u)
    rooms = db.query(m.HostelRoom).filter_by(hostel_id=h.id).all() if h else []
    occupied = sum(1 for r in rooms if occupancy(db, r) >= r.capacity)
    room_ids = [r.id for r in rooms]
    # Hostel attendance for students of this school only
    sid = u.school_id
    att_q = (db.query(m.HostelAttendance.status, func.count())
             .join(m.Student, m.Student.id == m.HostelAttendance.student_id)
             .join(m.User, m.User.id == m.Student.user_id)
             .filter(m.HostelAttendance.date == date.today(), m.User.school_id == sid)
             .group_by(m.HostelAttendance.status))
    att = dict(att_q.all())
    # Visitors linked to school hostel students
    vis = (db.query(m.HostelVisitor)
           .join(m.Student, m.Student.id == m.HostelVisitor.student_id)
           .join(m.User, m.User.id == m.Student.user_id)
           .filter(m.User.school_id == sid)
           .order_by(m.HostelVisitor.id.desc()).limit(5).all())
    alloc_count = (db.query(m.HostelAllocation)
                   .filter(m.HostelAllocation.room_id.in_(room_ids)).count()) if room_ids else 0
    complaint_count = (db.query(m.HostelComplaint)
                       .join(m.Student, m.Student.id == m.HostelComplaint.student_id)
                       .join(m.User, m.User.id == m.Student.user_id)
                       .filter(m.User.school_id == sid, m.HostelComplaint.status != "Resolved").count())
    complaint_by_cat = dict(
        db.query(m.HostelComplaint.category, func.count())
        .join(m.Student, m.Student.id == m.HostelComplaint.student_id)
        .join(m.User, m.User.id == m.Student.user_id)
        .filter(m.User.school_id == sid, m.HostelComplaint.status != "Resolved")
        .group_by(m.HostelComplaint.category).all()
    )
    total_students = (db.query(m.Student).join(m.User)
                      .filter(m.Student.is_hostel.is_(True), m.User.is_active.is_(True),
                              m.User.school_id == sid).count())
    return {"total_students": total_students,
            "total_rooms": len(rooms),
            "occupied_rooms": occupied, "available_rooms": len(rooms) - occupied,
            "today_present": att.get("Present", 0), "today_absent": att.get("Absent", 0),
            "pending_complaints": complaint_count,
            "bed_occupancy": {"Occupied beds": alloc_count,
                              "Free beds": max(0, sum(r.capacity for r in rooms) - alloc_count)},
            "attendance_chart": {k: att.get(k, 0) for k in ("Present", "Absent", "Late", "Leave")},
            "complaints_by_category": complaint_by_cat,
            "recent_visitors": [{"visitor": v.visitor_name, "student": v.student.user.name,
                                "relation": v.relation, "purpose": v.purpose} for v in vis]}



@router.get("/rooms")
def rooms(db: Session = Depends(get_db), u=ward):
    out = []
    for r in db.query(m.HostelRoom).order_by(m.HostelRoom.block, m.HostelRoom.floor, m.HostelRoom.room_no):
        allocs = db.query(m.HostelAllocation).filter_by(room_id=r.id).all()
        names = []
        beds = []
        for a in allocs:
            nm = a.student.user.name if a.student and a.student.user else "?"
            bed = getattr(a, "bed_no", None) or 1
            names.append(nm)
            beds.append(f"Bed {bed}: {nm}")
        free = r.capacity - len(names)
        out.append({
            "id": r.id,
            "block": getattr(r, "block", None) or "A",
            "floor": getattr(r, "floor", None) or 1,
            "room_no": r.room_no,
            "capacity": r.capacity,
            "occupied": len(names),
            "available": free,
            "occupants": ", ".join(names) or "-",
            "beds": ", ".join(beds) or "-",
            "label": f"Blk {getattr(r,'block',None) or 'A'}-F{getattr(r,'floor',None) or 1}-{r.room_no} ({free} free)",
        })
    return out


@router.post("/rooms")
def add_room(d: RoomIn, db: Session = Depends(get_db), u=ward):
    h = school_hostel(db, u, create=True)
    if not h:
        raise HTTPException(400, "No hostel for this school")
    block = (d.block or "A").strip()
    floor = d.floor or 1
    # auto-create block if missing
    if not db.query(m.HostelBlock).filter_by(hostel_id=h.id, name=block).first():
        db.add(m.HostelBlock(hostel_id=h.id, name=block, floors=max(floor, 2)))
        db.flush()
    if db.query(m.HostelRoom).filter_by(hostel_id=h.id, room_no=d.room_no).first():
        raise HTTPException(409, "Room already exists")
    db.add(m.HostelRoom(hostel_id=h.id, room_no=d.room_no, capacity=d.capacity, block=block, floor=floor))
    db.commit()
    return {"message": f"Room {d.room_no} added in Block {block} Floor {floor}"}


@router.get("/students")
def students(db: Session = Depends(get_db), u=ward):
    out = []
    for s in db.query(m.Student).join(m.User).filter(m.Student.is_hostel.is_(True), m.User.is_active.is_(True)).all():
        a = db.query(m.HostelAllocation).filter_by(student_id=s.id).first()
        room_label = "Not allocated"
        if a and a.room:
            room_label = f"Blk {getattr(a.room,'block',None) or 'A'}-F{getattr(a.room,'floor',None) or 1}-{a.room.room_no} Bed {getattr(a,'bed_no',None) or 1}"
        out.append({"student_id": s.id, "name": s.user.name, "class": s.klass.name, "mobile": s.user.mobile,
                    "room": room_label})
    return out


@router.post("/allocate")
def allocate(d: AllocIn, db: Session = Depends(get_db), u=ward):
    s, r = db.get(m.Student, d.student_id), db.get(m.HostelRoom, d.room_id)
    if not s or not r or not s.is_hostel:
        raise HTTPException(400, "Student must exist and be a hostel student")
    if occupancy(db, r) >= r.capacity:
        raise HTTPException(400, "Room is full")
    used = {a.bed_no for a in db.query(m.HostelAllocation).filter_by(room_id=r.id).all() if a.bed_no}
    bed = d.bed_no
    if bed is None:
        for i in range(1, r.capacity + 1):
            if i not in used:
                bed = i
                break
        if bed is None:
            raise HTTPException(400, "No free bed")
    elif bed in used:
        raise HTTPException(400, f"Bed {bed} already taken")
    a = db.query(m.HostelAllocation).filter_by(student_id=s.id).first()
    if a:
        a.room_id = r.id
        a.bed_no = bed
    else:
        db.add(m.HostelAllocation(student_id=s.id, room_id=r.id, bed_no=bed))
    db.commit()
    return {"message": f"Allocated room {r.room_no} bed {bed}"}


class VacateIn(BaseModel):
    student_id: int


@router.post("/vacate")
def vacate(d: VacateIn, db: Session = Depends(get_db), u=ward):
    n = db.query(m.HostelAllocation).filter_by(student_id=d.student_id).delete()
    if not n:
        raise HTTPException(404, "This student has no room allocated")
    db.commit()
    return {"message": "Room vacated"}


@router.post("/attendance")
def mark(d: HostelAttIn, db: Session = Depends(get_db), u=ward):
    hostel_ids = {s.id for s in db.query(m.Student).filter_by(is_hostel=True)}
    for r in d.records:
        if r.student_id not in hostel_ids:
            raise HTTPException(400, f"Student {r.student_id} is not a hostel student")
        row = db.query(m.HostelAttendance).filter_by(student_id=r.student_id, date=d.date).first()
        if row:
            row.status = r.status
        else:
            db.add(m.HostelAttendance(student_id=r.student_id, date=d.date, status=r.status))
    db.commit()
    return {"message": "Hostel attendance saved"}


@router.get("/attendance")
def att(date_: date | None = None, db: Session = Depends(get_db), u=ward):
    day = date_ or date.today()
    out = []
    for s in db.query(m.Student).filter_by(is_hostel=True):
        r = db.query(m.HostelAttendance).filter_by(student_id=s.id, date=day).first()
        out.append({"student_id": s.id, "name": s.user.name, "status": r.status if r else None})
    return out


@router.get("/complaints")
def complaints(db: Session = Depends(get_db), u=ward):
    q = (db.query(m.HostelComplaint)
         .join(m.Student, m.Student.id == m.HostelComplaint.student_id)
         .join(m.User, m.User.id == m.Student.user_id)
         .filter(m.User.school_id == u.school_id)
         .order_by(m.HostelComplaint.id.desc()))
    return [{"id": c.id, "student": c.student.user.name, "description": c.description,
             "category": c.category, "priority": c.priority, "status": c.status}
            for c in q]


@router.post("/complaints")
def add_complaint(d: HostelComplaintIn, db: Session = Depends(get_db), u=Depends(roles("warden", "admin", "student"))):
    sid = d.student_id
    if u.role == "student":
        s = student_of(db, u)
        if not s or not s.is_hostel:
            raise HTTPException(403, "Only hostel students can raise hostel complaints")
        sid = s.id
    cat, pri = analyze_hostel_complaint(d.description)
    db.add(m.HostelComplaint(student_id=sid, description=d.description, category=cat, priority=pri))
    for w in db.query(m.HostelWarden):
        notify(db, w.user_id, f"New {pri} priority hostel complaint", d.description[:120], "hostel")
    db.commit()
    return {"message": "Complaint recorded", "category": cat, "priority": pri}


@router.post("/complaints/{cid}/resolve")
def resolve(cid: int, db: Session = Depends(get_db), u=ward):
    c = db.get(m.HostelComplaint, cid)
    if not c:
        raise HTTPException(404, "Not found")
    c.status = "Resolved"
    db.commit()
    return {"message": "Resolved"}


@router.get("/visitors")
def visitors(db: Session = Depends(get_db), u=ward):
    q = (db.query(m.HostelVisitor)
         .join(m.Student, m.Student.id == m.HostelVisitor.student_id)
         .join(m.User, m.User.id == m.Student.user_id)
         .filter(m.User.school_id == u.school_id)
         .order_by(m.HostelVisitor.id.desc()).limit(100))
    return [{"id": v.id, "visitor": v.visitor_name, "student": v.student.user.name,
             "relation": v.relation, "purpose": v.purpose}
            for v in q]


@router.post("/visitors")
def add_visitor(d: VisitorIn, db: Session = Depends(get_db), u=ward):
    db.add(m.HostelVisitor(**d.model_dump()))
    db.commit()
    return {"message": "Visitor logged"}


@router.get("/reports/occupancy")
def occ(db: Session = Depends(get_db), u=ward):
    return rooms(db, u)


# ------------------------------------------------------------------ outpass / leave from hostel
class OutpassIn(BaseModel):
    from_date: date
    to_date: date
    reason: str = Field(min_length=3, max_length=250)
    student_id: Optional[int] = None            # warden/admin can create one for a student


class DecideIn(BaseModel):
    decision: str = Field(pattern="^(Approved|Rejected)$")
    remarks: Optional[str] = Field(None, max_length=250)


def _outpass_row(db, o):
    a = db.query(m.HostelAllocation).filter_by(student_id=o.student_id).first()
    return {"id": o.id, "student": o.student.user.name, "class": o.student.klass.name, "room": a.room.room_no if a else "-",
            "from": str(o.from_date), "to": str(o.to_date), "reason": o.reason, "status": o.status, "remarks": o.remarks or "-",
            "requested": o.created_at.strftime("%Y-%m-%d") if o.created_at else "-"}


@router.post("/outpass")
def outpass_create(d: OutpassIn, db: Session = Depends(get_db), u=Depends(roles("student", "warden", "admin"))):
    if u.role == "student":
        s = student_of(db, u)
    else:
        if not d.student_id:
            raise HTTPException(400, "Choose a student")
        s = db.get(m.Student, d.student_id)
    if not s or not s.is_hostel:
        raise HTTPException(400, "Only hostel students can get an outpass")
    if d.to_date < d.from_date:
        raise HTTPException(400, "Return date cannot be before the leaving date")
    if d.from_date < date.today() - timedelta(days=1):
        raise HTTPException(400, "The leaving date cannot be in the past")
    if db.query(m.HostelOutpass).filter(m.HostelOutpass.student_id == s.id, m.HostelOutpass.status == "Pending").count() >= 3:
        raise HTTPException(409, "You already have 3 pending requests")
    o = m.HostelOutpass(student_id=s.id, from_date=d.from_date, to_date=d.to_date, reason=d.reason)
    if u.role != "student":                                  # staff-created requests are approved straight away
        o.status, o.decided_by = "Approved", u.id
    db.add(o)
    for w in db.query(m.User).filter(m.User.role.in_(["warden", "admin"])).all():
        if w.id != u.id:
            notify(db, w.id, "New outpass request", f"{s.user.name}: {d.from_date} to {d.to_date} - {d.reason}", "hostel")
    db.commit()
    return {"message": "Outpass request sent to the warden" if u.role == "student" else "Outpass created and approved"}


@router.get("/outpass")
def outpass_list(status: Optional[str] = None, db: Session = Depends(get_db), u=Depends(roles("student", "warden", "admin"))):
    q = db.query(m.HostelOutpass).order_by(m.HostelOutpass.id.desc())
    if u.role == "student":
        q = q.filter(m.HostelOutpass.student_id == student_of(db, u).id)
    if status:
        q = q.filter(m.HostelOutpass.status == status)
    return [_outpass_row(db, o) for o in q.limit(300)]


@router.post("/outpass/{oid}/decide")
def outpass_decide(oid: int, d: DecideIn, db: Session = Depends(get_db), u=ward):
    o = db.get(m.HostelOutpass, oid)
    if not o:
        raise HTTPException(404, "Request not found")
    if o.status != "Pending":
        raise HTTPException(409, f"This request is already {o.status}")
    o.status, o.remarks, o.decided_by = d.decision, d.remarks, u.id
    msg = f"Your outpass for {o.from_date} to {o.to_date} was {d.decision.lower()}." + (f" Note: {d.remarks}" if d.remarks else "")
    notify(db, o.student.user_id, f"Outpass {d.decision.lower()}", msg, "hostel")
    if o.student.parent:
        notify(db, o.student.parent.user_id, f"Outpass {d.decision.lower()}", f"{o.student.user.name}: {msg}", "hostel")
    db.commit()
    return {"message": f"Outpass {d.decision.lower()}"}


@router.post("/outpass/{oid}/returned")
def outpass_returned(oid: int, db: Session = Depends(get_db), u=ward):
    o = db.get(m.HostelOutpass, oid)
    if not o or o.status != "Approved":
        raise HTTPException(409, "Only an approved outpass can be marked as returned")
    o.status = "Returned"
    db.commit()
    return {"message": "Marked as returned to hostel"}


# ------------------------------------------------------------------ mess menu
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MEALS = ["Breakfast", "Lunch", "Snacks", "Dinner"]


@router.get("/mess")
def mess_get(db: Session = Depends(get_db), u=Depends(current_user)):
    have = {(r.day, r.meal): r.items for r in db.query(m.MessMenu).all()}
    return [{"id": d, "day": d, **{meal: have.get((d, meal)) or "-" for meal in MEALS}} for d in DAYS]


class MessIn(BaseModel):
    Breakfast: Optional[str] = Field(None, max_length=250)
    Lunch: Optional[str] = Field(None, max_length=250)
    Snacks: Optional[str] = Field(None, max_length=250)
    Dinner: Optional[str] = Field(None, max_length=250)


@router.put("/mess/{day}")
def mess_put(day: str, d: MessIn, db: Session = Depends(get_db), u=ward):
    if day not in DAYS:
        raise HTTPException(404, "Unknown day")
    for meal in MEALS:
        items = (getattr(d, meal) or "").strip()
        row = db.query(m.MessMenu).filter_by(day=day, meal=meal).first()
        if items:
            if row:
                row.items = items
            else:
                db.add(m.MessMenu(day=day, meal=meal, items=items))
        elif row:
            db.delete(row)
    db.commit()
    return {"message": f"{day} menu saved"}
