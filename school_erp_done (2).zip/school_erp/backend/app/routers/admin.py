from datetime import date, timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from .. import schemas as sc
from ..auth.deps import roles
from ..utils.helpers import (att_stats, low_attendance, ser, student_label, grade_for, class_students)

router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(roles("admin"))])


def make_user(db, role, name, mobile, email=None, school_id=None):
    if db.query(m.User).filter_by(mobile=mobile).first():
        raise HTTPException(409, f"Mobile {mobile} is already registered")
    if email and db.query(m.User).filter_by(email=email).first():
        raise HTTPException(409, "Email already registered")
    u = m.User(school_id=school_id, role=role, name=name, mobile=mobile, email=email)
    db.add(u)
    db.flush()
    return u


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), u=Depends(roles("admin"))):
    """Admin dashboard – section-safe so missing/odd data never returns 500."""
    import logging
    log = logging.getLogger("dashboard")
    today = date.today()
    sid = u.school_id

    def count_role(role):
        try:
            q = db.query(m.User).filter(m.User.role == role, m.User.is_active == True)  # noqa
            if sid:
                q = q.filter(m.User.school_id == sid)
            return q.count()
        except Exception as e:
            log.exception("count_role %s: %s", role, e)
            return 0

    def class_ids():
        try:
            q = db.query(m.SchoolClass.id)
            if sid:
                q = q.filter(m.SchoolClass.school_id == sid)
            return [r[0] for r in q.all()]
        except Exception as e:
            log.exception("class_ids: %s", e)
            return []

    def student_ids():
        try:
            q = db.query(m.Student.id).join(m.User).filter(m.User.is_active == True)  # noqa
            if sid:
                q = q.filter(m.User.school_id == sid)
            return [r[0] for r in q.all()]
        except Exception as e:
            log.exception("student_ids: %s", e)
            return []

    cids = class_ids()
    sids = student_ids()

    att = {"Present": 0, "Absent": 0, "Late": 0, "Leave": 0}
    try:
        if sids:
            # Prefer today's daily attendance; if empty, use most recent day with records
            def load_att(day):
                q = db.query(m.Attendance.status, func.count()).filter(
                    m.Attendance.date == day,
                    m.Attendance.student_id.in_(sids),
                )
                # daily rows often have null subject_id; also accept any if needed
                rows = q.group_by(m.Attendance.status).all()
                return {status: n for status, n in rows}

            att_day = load_att(today)
            if not att_day or sum(att_day.values()) == 0:
                last = (db.query(m.Attendance.date)
                        .filter(m.Attendance.student_id.in_(sids))
                        .order_by(m.Attendance.date.desc()).first())
                if last:
                    att_day = load_att(last[0])
            for k in att:
                att[k] = int(att_day.get(k, 0) or 0)
            # collapse unknown statuses
            for k, n in att_day.items():
                if k not in att:
                    att[k] = int(n or 0)
    except Exception as e:
        log.exception("attendance today: %s", e)

    total_fee = paid = fee_month = fee_year = 0.0
    fees_ = []
    fee_ids = []
    try:
        fees_ = db.query(m.Fee).filter(m.Fee.student_id.in_(sids)).all() if sids else []
        total_fee = float(sum((f.amount or 0) for f in fees_))
        fee_ids = [f.id for f in fees_]
        if fee_ids:
            paid = float(db.query(func.coalesce(func.sum(m.FeePayment.amount), 0))
                         .filter(m.FeePayment.fee_id.in_(fee_ids)).scalar() or 0)
            month_start = today.replace(day=1)
            year_start = today.replace(month=1, day=1)
            fee_month = float(db.query(func.coalesce(func.sum(m.FeePayment.amount), 0)).filter(
                m.FeePayment.fee_id.in_(fee_ids), m.FeePayment.paid_on >= month_start).scalar() or 0)
            fee_year = float(db.query(func.coalesce(func.sum(m.FeePayment.amount), 0)).filter(
                m.FeePayment.fee_id.in_(fee_ids), m.FeePayment.paid_on >= year_start).scalar() or 0)
    except Exception as e:
        log.exception("fees: %s", e)

    weekly_att = {}
    try:
        week_start = today - timedelta(days=today.weekday())
        for i in range(5):  # Mon–Fri only (skip weekend zeros)
            day = week_start + timedelta(days=i)
            label = day.strftime("%a %d")
            weekly_att[label] = 0
            if not sids:
                continue
            rows = dict(db.query(m.Attendance.status, func.count()).filter(
                m.Attendance.date == day,
                m.Attendance.student_id.in_(sids)).group_by(m.Attendance.status).all())
            tot = sum(rows.values())
            if tot:
                weekly_att[label] = round((rows.get("Present", 0) + rows.get("Late", 0)) / tot * 100, 1)
    except Exception as e:
        log.exception("weekly_att: %s", e)

    att_rate = 0.0
    try:
        if sids:
            rows = dict(db.query(m.Attendance.status, func.count()).filter(
                m.Attendance.date >= today - timedelta(days=30),
                m.Attendance.student_id.in_(sids)).group_by(m.Attendance.status).all())
            tot = sum(rows.values())
            if tot:
                att_rate = round((rows.get("Present", 0) + rows.get("Late", 0)) / tot * 100, 1)
    except Exception as e:
        log.exception("att_rate: %s", e)

    students_by_class = {}
    try:
        for cid in cids:
            c = db.get(m.SchoolClass, cid)
            if c:
                students_by_class[c.name] = len(class_students(db, cid))
    except Exception as e:
        log.exception("students_by_class: %s", e)

    fee_by_month = {}
    try:
        for i in range(5, -1, -1):
            y, mo = today.year, today.month - i
            while mo < 1:
                mo += 12
                y -= 1
            start = date(y, mo, 1)
            end = date(y + 1, 1, 1) if mo == 12 else date(y, mo + 1, 1)
            label = start.strftime("%b %y")
            amt = 0.0
            if fee_ids:
                amt = float(db.query(func.coalesce(func.sum(m.FeePayment.amount), 0)).filter(
                    m.FeePayment.fee_id.in_(fee_ids),
                    m.FeePayment.paid_on >= start, m.FeePayment.paid_on < end).scalar() or 0)
            fee_by_month[label] = amt
    except Exception as e:
        log.exception("fee_by_month: %s", e)

    class_performance = {}
    try:
        for cid in cids:
            c = db.get(m.SchoolClass, cid)
            if not c:
                continue
            vals = [r[0] for r in db.query(m.ExamResult.percentage).join(
                m.Exam, m.Exam.id == m.ExamResult.exam_id
            ).filter(m.Exam.class_id == cid, m.ExamResult.published == True).all() if r[0] is not None]
            if vals:
                class_performance[c.name] = round(sum(vals) / len(vals), 1)
    except Exception as e:
        log.exception("class_performance: %s", e)

    pending_list = []
    try:
        for f in fees_:
            paid_f = float(db.query(func.coalesce(func.sum(m.FeePayment.amount), 0))
                           .filter(m.FeePayment.fee_id == f.id).scalar() or 0)
            due = round(float(f.amount or 0) - paid_f, 2)
            if due <= 0.01:
                continue
            st = db.get(m.Student, f.student_id)
            if not st or not st.user or not st.user.is_active:
                continue
            pending_list.append({
                "student": st.user.name,
                "class": st.klass.name if st.klass else "",
                "fee_type": f.fee_type,
                "due": due,
                "due_date": f.due_date.isoformat() if f.due_date else None,
            })
        pending_list.sort(key=lambda x: (x["due_date"] or "9999", -x["due"]))
        pending_list = pending_list[:12]
    except Exception as e:
        log.exception("pending_list: %s", e)

    calendar_events = []
    try:
        eq = db.query(m.Event).filter(
            m.Event.event_date >= today - timedelta(days=7),
            m.Event.event_date <= today + timedelta(days=60))
        if sid:
            eq = eq.filter(m.Event.school_id == sid)
        calendar_events = [{**ser(e, "title", "description", "event_date")} for e in eq.order_by(m.Event.event_date).all()]
    except Exception as e:
        log.exception("calendar: %s", e)

    upcoming_exams = []
    try:
        xq = db.query(m.Exam).filter(m.Exam.exam_date >= today)
        if sid and cids:
            xq = xq.filter(m.Exam.class_id.in_(cids))
        elif sid and not cids:
            xq = xq.filter(m.Exam.id == -1)
        for e in xq.order_by(m.Exam.exam_date).limit(8).all():
            upcoming_exams.append({
                **ser(e, "name", "exam_date"),
                "subject": e.subject.name if e.subject else "",
                "class": e.klass.name if e.klass else "",
            })
    except Exception as e:
        log.exception("exams: %s", e)

    recent_notices = []
    try:
        nq = db.query(m.Notice)
        if sid:
            nq = nq.filter(m.Notice.school_id == sid)
        recent_notices = [ser(n, "title", "audience", "created_at") for n in nq.order_by(m.Notice.id.desc()).limit(5).all()]
    except Exception as e:
        log.exception("notices: %s", e)

    low = []
    try:
        low = low_attendance(db, cids if sid else None)[:8]
    except Exception as e:
        log.exception("low_att: %s", e)

    hostel_n = 0
    try:
        hq = db.query(m.Student).join(m.User).filter(m.Student.is_hostel == True, m.User.is_active == True)  # noqa
        if sid:
            hq = hq.filter(m.User.school_id == sid)
        hostel_n = hq.count()
    except Exception as e:
        log.exception("hostel: %s", e)

    # Active / inactive students
    active_students = count_role("student")
    inactive_students = 0
    try:
        q = db.query(m.User).filter(m.User.role == "student", m.User.is_active == False)
        if sid:
            q = q.filter(m.User.school_id == sid)
        inactive_students = q.count()
    except Exception:
        pass

    # Pending photo documents
    pending_docs = []
    pending_docs_count = 0
    try:
        q = db.query(m.StudentDocument).filter(m.StudentDocument.status == "Pending")
        docs = q.order_by(m.StudentDocument.uploaded_at.desc()).limit(20).all()
        for d in docs:
            st = db.get(m.Student, d.student_id)
            if not st:
                continue
            if sid and st.user and st.user.school_id != sid:
                continue
            pending_docs.append({
                "id": d.id, "student": st.user.name if st.user else "-",
                "admission_no": st.admission_no, "doc_type": d.doc_type,
                "title": d.title or d.doc_type, "status": d.status,
            })
        pending_docs_count = len(pending_docs)
        # better count
        pending_docs_count = db.query(m.StudentDocument).filter(m.StudentDocument.status == "Pending").count()
    except Exception as e:
        log.exception("pending_docs: %s", e)

    # Grade distribution from results
    grade_dist = {}
    try:
        from collections import Counter
        results = db.query(m.ExamResult).all()
        grades = []
        for r in results:
            if getattr(r, "grade", None):
                grades.append(r.grade)
            elif hasattr(r, "percentage") and r.percentage is not None:
                grades.append(grade_for(r.percentage))
        grade_dist = dict(Counter(grades))
    except Exception as e:
        log.exception("grade_dist: %s", e)

    # Recent activity from audit (last 8)
    recent_activity = []
    try:
        logs = db.query(m.AuditLog).order_by(m.AuditLog.id.desc()).limit(8).all()
        for a in logs:
            recent_activity.append({
                "action": getattr(a, "action", None) or getattr(a, "method", "") or "Action",
                "detail": getattr(a, "path", None) or getattr(a, "detail", "") or "",
                "user": getattr(a, "user_name", None) or str(getattr(a, "user_id", "")),
                "at": str(getattr(a, "created_at", "") or "")[:19],
            })
    except Exception as e:
        log.exception("recent_activity: %s", e)

    return {
        "total_students": count_role("student"),
        "total_teachers": count_role("teacher"),
        "total_parents": count_role("parent"),
        "total_classes": len(cids),
        "hostel_students": hostel_n,
        "today_present": att.get("Present", 0),
        "today_absent": att.get("Absent", 0),
        "attendance_rate": att_rate,
        "pending_fees": round(total_fee - paid, 2),
        "fee_collected_month": round(fee_month, 2),
        "fee_collected_year": round(fee_year, 2),
        "fee_summary": {"Collected": round(paid, 2), "Pending": round(total_fee - paid, 2)},
        "fee_by_month": fee_by_month,
        "weekly_attendance": weekly_att,
        "students_by_class": students_by_class,
        "class_performance": class_performance,
        "attendance_chart": att,
        "pending_fees_list": pending_list,
        "calendar_events": calendar_events,
        "upcoming_exams": upcoming_exams,
        "recent_notices": recent_notices,
        "low_attendance": low,
        "low_attendance_count": len(low) if isinstance(low, list) else 0,
        "active_students": active_students,
        "inactive_students": inactive_students,
        "student_status": {"Active": active_students, "Inactive": inactive_students},
        "grade_distribution": grade_dist,
        "pending_documents": pending_docs,
        "pending_documents_count": pending_docs_count,
        "recent_activity": recent_activity,
    }



@router.post("/students")
def add_student(d: sc.StudentIn, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    if db.query(m.Student).filter_by(admission_no=d.admission_no).first():
        raise HTTPException(409, "Admission number already exists")
    if not db.get(m.SchoolClass, d.class_id):
        raise HTTPException(400, "Invalid class")
    su = make_user(db, "student", d.name, d.mobile, d.email, school_id=admin.school_id)
    parent = None
    if d.parent_mobile:
        pu = db.query(m.User).filter_by(mobile=d.parent_mobile, role="parent").first()
        if not pu:
            pu = make_user(db, "parent", d.parent_name or f"Parent of {d.name}", d.parent_mobile, school_id=admin.school_id)
            db.add(m.Parent(user_id=pu.id))
            db.flush()
        parent = db.query(m.Parent).filter_by(user_id=pu.id).first()
    s = m.Student(user_id=su.id, admission_no=d.admission_no, roll_no=d.roll_no, class_id=d.class_id,
                  section_id=d.section_id, dob=d.dob, gender=d.gender, is_hostel=d.is_hostel,
                  parent_id=parent.id if parent else None,
                  address_line1=d.address_line1, address_line2=d.address_line2,
                  city=d.city, state=d.state, pincode=d.pincode)
    db.add(s)
    db.flush()
    ay = db.query(m.AcademicYear).filter_by(is_current=True, school_id=admin.school_id).first()
    if not ay:
        ay = db.query(m.AcademicYear).filter_by(is_current=True).first()
    db.add(m.StudentClass(student_id=s.id, class_id=d.class_id, section_id=d.section_id,
                          academic_year_id=ay.id if ay else None))
    db.commit()
    return {"id": s.id, "message": "Student created"}


@router.get("/students")
def students(db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    q = db.query(m.Student).join(m.User).filter(m.User.is_active == True)  # noqa
    if admin.school_id:
        q = q.filter(m.User.school_id == admin.school_id)
    rows = q.order_by(m.Student.class_id, m.Student.roll_no).all()
    return [{"id": s.id, "admission_no": s.admission_no, "name": s.user.name, "mobile": s.user.mobile,
             "class_id": s.class_id, "section_id": s.section_id,
             "class": s.klass.name if s.klass else "", "section": s.section.name if s.section else "-",
             "parent": s.parent.user.name if s.parent else "-", "hostel": "Yes" if s.is_hostel else "No",
             "city": s.city or "", "attendance": att_stats(db, s.id)["percentage"]} for s in rows]


@router.delete("/students/{sid}")
def remove_student(sid: int, db: Session = Depends(get_db)):
    s = db.get(m.Student, sid)
    if not s:
        raise HTTPException(404, "Not found")
    s.user.is_active = False
    db.commit()
    return {"message": "Student deactivated"}


@router.post("/teachers")
def add_teacher(d: sc.StaffIn, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    tu = make_user(db, "teacher", d.name, d.mobile, d.email, school_id=admin.school_id)
    t = m.Teacher(user_id=tu.id, employee_no=d.employee_no, qualification=d.qualification,
                  experience=d.experience, class_id=d.class_id)
    db.add(t)
    db.flush()
    if d.subject_ids and d.class_id:
        for sid in d.subject_ids:
            db.add(m.TeacherSubject(teacher_id=t.id, subject_id=sid, class_id=d.class_id))
    db.commit()
    return {"message": "Teacher created", "id": t.id}


@router.get("/teachers")
def teachers(db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    q = db.query(m.Teacher).join(m.User).filter(m.User.is_active == True)  # noqa
    if admin.school_id:
        q = q.filter(m.User.school_id == admin.school_id)
    out = []
    for t in q.all():
        subs = db.query(m.TeacherSubject).filter_by(teacher_id=t.id).all()
        sub_names = sorted({x.subject.name for x in subs if x.subject})
        out.append({"id": t.id, "name": t.user.name, "mobile": t.user.mobile, "email": t.user.email,
                    "employee_no": t.employee_no, "qualification": t.qualification or "",
                    "experience": t.experience or "", "class": t.klass.name if t.klass else "",
                    "subjects": ", ".join(sub_names),
                    "photo": getattr(t, "photo_path", None) or ""})
    return out


@router.get("/parents")
def parents(db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    q = db.query(m.Parent).join(m.User)
    if admin.school_id:
        q = q.filter(m.User.school_id == admin.school_id)
    return [{"id": p.id, "name": p.user.name, "mobile": p.user.mobile, "email": p.user.email,
             "children": ", ".join(s.user.name for s in db.query(m.Student).filter_by(parent_id=p.id))}
            for p in q.all()]


@router.post("/wardens")
def add_warden(d: sc.StaffIn, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    hq = db.query(m.Hostel)
    if admin.school_id:
        hq = hq.filter(m.Hostel.school_id == admin.school_id)
    hid = d.hostel_id or (hq.first().id if hq.first() else None)
    wu = make_user(db, "warden", d.name, d.mobile, d.email, school_id=admin.school_id)
    db.add(m.HostelWarden(user_id=wu.id, hostel_id=hid))
    db.commit()
    return {"message": "Warden created"}


@router.get("/wardens")
def wardens(db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    q = db.query(m.HostelWarden).join(m.User)
    if admin.school_id:
        q = q.filter(m.User.school_id == admin.school_id)
    return [{"id": w.id, "name": w.user.name, "mobile": w.user.mobile, "email": w.user.email} for w in q.all()]


# ---------- academic setup ----------
@router.post("/classes")
def add_class(d: sc.ClassIn, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    q = db.query(m.SchoolClass).filter_by(name=d.name)
    if admin.school_id:
        q = q.filter_by(school_id=admin.school_id)
    if q.first():
        raise HTTPException(409, "Class already exists")
    row = m.SchoolClass(name=d.name, school_id=admin.school_id, capacity=d.capacity or 40,
                        class_teacher_id=d.class_teacher_id)
    db.add(row)
    db.commit()
    return {"message": "Class added", "id": row.id}


@router.put("/classes/{cid}")
def edit_class(cid: int, d: sc.ClassIn, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    c = db.get(m.SchoolClass, cid)
    if not c:
        raise HTTPException(404, "Class not found")
    c.name = d.name
    if d.capacity is not None:
        c.capacity = d.capacity
    c.class_teacher_id = d.class_teacher_id
    db.commit()
    return {"message": "Class updated"}


@router.delete("/classes/{cid}")
def del_class(cid: int, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    c = db.get(m.SchoolClass, cid)
    if not c:
        raise HTTPException(404, "Class not found")
    if db.query(m.Student).filter_by(class_id=cid).count():
        raise HTTPException(400, "Class has students — move them first")
    db.delete(c)
    db.commit()
    return {"message": "Class deleted"}


@router.get("/classes")
def classes(db: Session = Depends(get_db)):
    out = []
    for c in db.query(m.SchoolClass).order_by(m.SchoolClass.id):
        teacher = None
        if getattr(c, "class_teacher_id", None):
            tch = db.get(m.Teacher, c.class_teacher_id)
            teacher = tch.user.name if tch and tch.user else None
        out.append({
            "id": c.id, "name": c.name,
            "capacity": getattr(c, "capacity", None) or 40,
            "class_teacher_id": getattr(c, "class_teacher_id", None),
            "class_teacher": teacher or "—",
            "sections": ", ".join(s.name for s in db.query(m.Section).filter_by(class_id=c.id)),
            "students": db.query(m.Student).filter_by(class_id=c.id).count(),
        })
    return out


@router.get("/classes/{cid}/students")
def class_students_list(cid: int, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    rows = db.query(m.Student).filter_by(class_id=cid).all()
    return [{"id": s.id, "admission_no": s.admission_no, "roll_no": s.roll_no, "name": s.user.name,
             "section": s.section.name if s.section else "-", "mobile": s.user.mobile}
            for s in rows]


@router.post("/sections")
def add_section(d: sc.NameIn, db: Session = Depends(get_db)):
    if not d.class_id:
        raise HTTPException(400, "class_id required")
    if db.query(m.Section).filter_by(class_id=d.class_id, name=d.name).first():
        raise HTTPException(409, "Section already exists")
    db.add(m.Section(class_id=d.class_id, name=d.name))
    db.commit()
    return {"message": "Section added"}


@router.get("/sections")
def sections(class_id: int | None = None, db: Session = Depends(get_db)):
    q = db.query(m.Section)
    if class_id:
        q = q.filter_by(class_id=class_id)
    return [{"id": s.id, "name": s.name, "class_id": s.class_id, "class": s.klass.name, "label": f"{s.klass.name}-{s.name}"} for s in q.all()]


@router.post("/subjects")
def add_subject(d: sc.NameIn, db: Session = Depends(get_db)):
    if not d.class_id:
        raise HTTPException(400, "class_id required")
    if db.query(m.Subject).filter_by(class_id=d.class_id, name=d.name).first():
        raise HTTPException(409, "Subject already exists")
    db.add(m.Subject(name=d.name, class_id=d.class_id))
    db.commit()
    return {"message": "Subject added"}


@router.get("/subjects")
def subjects(class_id: int | None = None, db: Session = Depends(get_db)):
    q = db.query(m.Subject)
    if class_id:
        q = q.filter_by(class_id=class_id)
    return [{"id": s.id, "name": s.name, "class": s.klass.name, "label": f"{s.klass.name} - {s.name}"} for s in q.all()]


@router.get("/academic-years")
def list_years(db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    q = db.query(m.AcademicYear)
    if admin.school_id:
        q = q.filter((m.AcademicYear.school_id == admin.school_id) | (m.AcademicYear.school_id.is_(None)))
    return [{"id": y.id, "name": y.name, "is_current": bool(y.is_current)} for y in q.order_by(m.AcademicYear.id.desc())]


@router.post("/academic-years")
def add_year(d: sc.NameIn, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    sid = admin.school_id
    if sid:
        db.query(m.AcademicYear).filter_by(school_id=sid).update({"is_current": False})
    else:
        db.query(m.AcademicYear).update({"is_current": False})
    y = m.AcademicYear(name=d.name, is_current=True, school_id=sid)
    db.add(y)
    db.commit()
    return {"message": "Academic year set as current", "id": y.id}


@router.post("/academic-years/{yid}/activate")
def activate_year(yid: int, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    y = db.get(m.AcademicYear, yid)
    if not y:
        raise HTTPException(404, "Year not found")
    q = db.query(m.AcademicYear)
    if admin.school_id:
        q = q.filter_by(school_id=admin.school_id)
    q.update({"is_current": False})
    y.is_current = True
    db.commit()
    return {"message": f"{y.name} is now current"}


@router.post("/teacher-subjects")
def assign_teacher(d: sc.TeacherSubjectIn, db: Session = Depends(get_db)):
    db.add(m.TeacherSubject(**d.model_dump()))
    db.commit()
    return {"message": "Teacher assigned"}


@router.get("/teacher-subjects")
def teacher_subjects(db: Session = Depends(get_db)):
    return [{"id": r.id, "teacher": r.teacher.user.name, "subject": r.subject.name, "class": r.klass.name,
             "section": r.section.name if r.section else "All"} for r in db.query(m.TeacherSubject).all()]


@router.get("/complaints")
def complaints(db: Session = Depends(get_db)):
    return [{"id": c.id, "from": c.user.name, "role": c.user.role, "subject": c.subject,
             "description": c.description, "status": c.status, "created_at": c.created_at.isoformat()}
            for c in db.query(m.Complaint).order_by(m.Complaint.id.desc()).all()]


@router.post("/complaints/{cid}/resolve")
def resolve(cid: int, db: Session = Depends(get_db)):
    c = db.get(m.Complaint, cid)
    if not c:
        raise HTTPException(404, "Not found")
    c.status = "Resolved"
    db.commit()
    return {"message": "Resolved"}


# ---------- reports ----------
@router.get("/reports/low-attendance")
def rep_low(db: Session = Depends(get_db)):
    return low_attendance(db)


@router.get("/reports/class-result")
def class_result(class_id: int, db: Session = Depends(get_db)):
    out = []
    for s in db.query(m.Student).filter_by(class_id=class_id).all():
        rs = db.query(m.ExamResult).filter_by(student_id=s.id, published=True).all()
        if rs:
            avg = round(sum(r.percentage for r in rs) / len(rs), 1)
            out.append({**student_label(s), "exams": len(rs), "average": avg, "grade": grade_for(avg),
                        "result": "Pass" if all(r.passed for r in rs) else "Fail"})
    return sorted(out, key=lambda x: -x["average"])


@router.get("/reports/report-card/{sid}")
def report_card(sid: int, db: Session = Depends(get_db)):
    from ..services import student_data as sd
    s = db.get(m.Student, sid)
    if not s:
        raise HTTPException(404, "Student not found")
    res = sd.results(db, s)
    avg = round(sum(r["percentage"] for r in res) / len(res), 1) if res else 0
    return {"student": sd.profile(db, s), "attendance": att_stats(db, sid), "results": res,
            "overall_percentage": avg, "overall_grade": grade_for(avg)}


@router.get("/reports/subject-performance")
def subject_perf(class_id: int, db: Session = Depends(get_db)):
    rows = db.query(m.Subject.name, func.avg(m.ExamResult.percentage), func.count()).join(
        m.Exam, m.Exam.subject_id == m.Subject.id).join(m.ExamResult, m.ExamResult.exam_id == m.Exam.id).filter(
        m.Exam.class_id == class_id, m.ExamResult.published == True).group_by(m.Subject.name).all()  # noqa
    return [{"subject": n, "average": round(a, 1), "entries": c} for n, a, c in rows]



@router.get("/documents")
def list_documents(db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    q = db.query(m.StudentDocument).order_by(m.StudentDocument.id.desc())
    if admin.school_id:
        q = q.join(m.Student).join(m.User).filter(m.User.school_id == admin.school_id)
    out = []
    for d in q.limit(200):
        st = d.student if hasattr(d, "student") else db.get(m.Student, d.student_id)
        out.append({
            **ser(d, "id", "doc_type", "title", "file_path", "status", "remarks", "uploaded_at"),
            "student": st.user.name if st and st.user else "",
            "admission_no": st.admission_no if st else "",
            "class": st.klass.name if st and st.klass else "",
        })
    return out


@router.post("/documents/{doc_id}/verify")
def verify_document(doc_id: int, status: str = "Verified", remarks: str = "",
                    db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    d = db.get(m.StudentDocument, doc_id)
    if not d:
        raise HTTPException(404, "Document not found")
    if status not in ("Verified", "Rejected"):
        raise HTTPException(400, "status must be Verified or Rejected")
    d.status = status
    d.remarks = remarks or d.remarks
    db.commit()
    return {"message": f"Document {status.lower()}"}



DEFAULT_ROLE_ACCESS = {
    "admin": ["*"],
    "teacher": ["dashboard", "students", "attendance", "work", "exams", "materials", "notices"],
    "student": ["dashboard", "profile", "documents", "attendance", "subjects", "timetable", "work", "exams", "results", "fees", "notices", "materials", "outpass", "mess", "complaints"],
    "parent": ["dashboard", "attendance", "results", "work", "exams", "timetable", "fees", "mess", "notices", "contact"],
    "warden": ["dashboard", "rooms", "students", "attendance", "outpass", "mess", "complaints", "visitors", "notices"],
}


@router.get("/role-access")
def get_role_access(db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    from ..services import settings_service as ss
    raw = ss.get(db, "role_access", None, admin.school_id)
    if raw:
        import json
        try:
            return json.loads(raw)
        except Exception:
            pass
    return DEFAULT_ROLE_ACCESS


@router.post("/role-access")
def set_role_access(body: dict, db: Session = Depends(get_db), admin=Depends(roles("admin"))):
    import json
    from ..services import settings_service as ss
    ss.set_many(db, {"role_access": json.dumps(body)}, admin.school_id)
    return {"message": "Role access updated"}


# ---------- CSV import / export ----------
from fastapi import UploadFile, File
from fastapi.responses import PlainTextResponse
import csv, io


@router.get("/students/export-csv")
def export_students_csv(db: Session = Depends(get_db), u=Depends(roles("admin"))):
    """Download all active students as CSV."""
    q = db.query(m.Student).join(m.User).filter(m.User.is_active == True)  # noqa
    if u.school_id:
        q = q.filter(m.User.school_id == u.school_id)
    rows = q.order_by(m.Student.id).all()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["admission_no", "name", "mobile", "email", "class", "section", "roll_no", "gender", "dob", "is_hostel", "parent_name", "parent_mobile", "city", "state"])
    for s in rows:
        parent_name = parent_mobile = ""
        if s.parent and s.parent.user:
            parent_name = s.parent.user.name or ""
            parent_mobile = s.parent.user.mobile or ""
        w.writerow([
            s.admission_no or "",
            s.user.name if s.user else "",
            s.user.mobile if s.user else "",
            s.user.email if s.user else "",
            s.klass.name if s.klass else "",
            s.section.name if s.section else "",
            s.roll_no or "",
            s.gender or "",
            s.dob.isoformat() if s.dob else "",
            "1" if s.is_hostel else "0",
            parent_name,
            parent_mobile,
            s.city or "",
            s.state or "",
        ])
    return PlainTextResponse(
        "\ufeff" + buf.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="students_export.csv"'},
    )


@router.get("/students/import-template")
def students_import_template():
    """Sample CSV template for bulk student import."""
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["admission_no", "name", "mobile", "email", "class", "section", "roll_no", "gender", "dob", "is_hostel", "parent_name", "parent_mobile"])
    w.writerow(["ADM2026100", "Sample Student", "919999990001", "sample@school.com", "Class 8", "A", "1", "M", "2012-05-15", "0", "Parent Name", "919999990002"])
    return PlainTextResponse(
        "\ufeff" + buf.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="students_import_template.csv"'},
    )


@router.post("/students/import-csv")
async def import_students_csv(file: UploadFile = File(...), db: Session = Depends(get_db), u=Depends(roles("admin"))):
    """Bulk import students from CSV. Required columns: name, mobile, class. Optional: admission_no, email, section, roll_no, gender, dob, is_hostel, parent_name, parent_mobile."""
    raw = (await file.read()).decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(raw))
    if not reader.fieldnames:
        raise HTTPException(400, "Empty or invalid CSV")
    # normalize headers
    fields = {h.strip().lower().replace(" ", "_"): h for h in reader.fieldnames}

    def cell(row, *keys):
        for k in keys:
            key = k.lower().replace(" ", "_")
            if key in fields:
                return (row.get(fields[key]) or "").strip()
            if k in row:
                return (row.get(k) or "").strip()
        return ""

    created, skipped, errors = 0, 0, []
    for i, row in enumerate(reader, start=2):
        name = cell(row, "name")
        mobile = cell(row, "mobile")
        class_name = cell(row, "class", "class_name")
        if not name or not mobile or not class_name:
            errors.append(f"Row {i}: need name, mobile, class")
            skipped += 1
            continue
        # find class
        cq = db.query(m.SchoolClass).filter(m.SchoolClass.name == class_name)
        if u.school_id:
            cq = cq.filter(m.SchoolClass.school_id == u.school_id)
        klass = cq.first()
        if not klass and class_name.isdigit():
            cq = db.query(m.SchoolClass).filter(m.SchoolClass.name == f"Class {class_name}")
            if u.school_id:
                cq = cq.filter(m.SchoolClass.school_id == u.school_id)
            klass = cq.first()
        if not klass:
            errors.append(f"Row {i}: class '{class_name}' not found")
            skipped += 1
            continue
        section_name = cell(row, "section") or "A"
        sec = db.query(m.Section).filter_by(class_id=klass.id, name=section_name).first()
        if not sec:
            sec = db.query(m.Section).filter_by(class_id=klass.id).first()
        # skip if mobile exists
        if db.query(m.User).filter_by(mobile=mobile, role="student").first():
            errors.append(f"Row {i}: mobile {mobile} already exists")
            skipped += 1
            continue
        adm = cell(row, "admission_no") or f"ADM{2026000 + i}"
        if db.query(m.Student).filter_by(admission_no=adm).first():
            adm = f"ADM{2026000 + i}{created}"
        try:
            parent = None
            pm = cell(row, "parent_mobile")
            pn = cell(row, "parent_name") or f"Parent of {name.split()[0]}"
            if pm:
                pu = db.query(m.User).filter_by(mobile=pm, role="parent").first()
                if not pu:
                    pu = make_user(db, "parent", pn, pm, school_id=u.school_id)
                parent = db.query(m.Parent).filter_by(user_id=pu.id).first()
                if not parent:
                    parent = m.Parent(user_id=pu.id)
                    db.add(parent)
                    db.flush()
            su = make_user(db, "student", name, mobile, cell(row, "email") or None, school_id=u.school_id)
            dob = None
            ds = cell(row, "dob")
            if ds:
                try:
                    from datetime import date as date_cls
                    dob = date_cls.fromisoformat(ds[:10])
                except Exception:
                    dob = None
            st = m.Student(
                user_id=su.id, admission_no=adm,
                roll_no=int(cell(row, "roll_no") or 0) or None,
                class_id=klass.id, section_id=sec.id if sec else None,
                parent_id=parent.id if parent else None,
                dob=dob, gender=cell(row, "gender") or None,
                is_hostel=cell(row, "is_hostel") in ("1", "yes", "true", "Y", "y"),
            )
            db.add(st)
            db.flush()
            db.add(m.StudentClass(student_id=st.id, class_id=klass.id, section_id=sec.id if sec else None))
            created += 1
        except Exception as e:
            errors.append(f"Row {i}: {e}")
            skipped += 1
            db.rollback()
            continue
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(400, f"Import failed: {e}")
    return {"message": f"Imported {created} students ({skipped} skipped)", "created": created, "skipped": skipped, "errors": errors[:20]}
