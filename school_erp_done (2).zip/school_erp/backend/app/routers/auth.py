from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_
from sqlalchemy.orm import Session
import secrets
import re
from ..config import settings
from ..database import get_db
from ..models import models as m
from ..schemas import OtpReq, AdminLogin, VerifyReq, SchoolRegister
from ..auth.security import verify_password, create_token, hash_password
from ..auth.deps import current_user
from ..services import audit
from ..services.otp_service import send_otp, verify_otp
from ..services import settings_service as ss

router = APIRouter(prefix="/auth", tags=["auth"])
GENERIC = {"message": "If the account is registered, an OTP has been sent."}


def find(db, identifier, role):
    return db.query(m.User).filter(m.User.role == role, m.User.is_active == True,  # noqa
                                   or_(m.User.mobile == identifier, m.User.email == identifier)).first()


def _gen_school_code(db) -> str:
    for _ in range(20):
        code = "SCH-" + secrets.token_hex(2).upper()
        if not db.query(m.School).filter_by(code=code).first():
            return code
    return "SCH-" + secrets.token_hex(4).upper()


@router.post("/register-school")
def register_school(d: SchoolRegister, db: Session = Depends(get_db)):
    """Public: register a new school + admin account (auto-activated)."""
    email = d.email.strip().lower()
    if "@" not in email or "." not in email.split("@")[-1]:
        raise HTTPException(422, "Invalid email address")
    if not re.search(r"[A-Za-z]", d.password) or not re.search(r"\d", d.password):
        raise HTTPException(422, "Password must contain at least one letter and one number")
    if db.query(m.User).filter(or_(m.User.email == email, m.User.mobile == d.mobile)).first():
        raise HTTPException(409, "Email or mobile already registered")

    code = _gen_school_code(db)
    addr = ", ".join(p for p in (d.address_line1, d.address_line2) if p)
    school = m.School(
        code=code,
        name=d.school_name.strip(),
        address=addr or None,
        city=d.city,
        state=d.state,
        pincode=d.pincode,
        phone=d.phone or d.mobile,
        email=email,
        is_active=True,
    )
    db.add(school)
    db.flush()

    admin = m.User(
        school_id=school.id,
        role="admin",
        name=d.admin_name.strip(),
        email=email,
        mobile=d.mobile,
        password_hash=hash_password(d.password),
        is_active=True,
    )
    db.add(admin)
    db.flush()

    # current academic year
    from datetime import date
    y = date.today().year
    ay_name = f"{y}-{str(y + 1)[-2:]}"
    db.add(m.AcademicYear(school_id=school.id, name=ay_name, is_current=True))

    # seed settings from school row
    ss.set_many(db, {
        "school_name": school.name,
        "address": addr or "",
        "phone": school.phone or "",
        "email": email,
        "school_code": code,
        "low_attendance": str(settings.LOW_ATTENDANCE),
    }, school.id)

    db.commit()
    return {
        "message": "School registered successfully. You can log in as Admin now.",
        "school_code": code,
        "school_name": school.name,
        "admin_email": email,
    }


@router.post("/request-otp")
def request_otp(d: OtpReq, db: Session = Depends(get_db)):
    """OTP-only login for student / teacher / warden / parent (also used for Resend)."""
    u = find(db, d.identifier, d.role)
    if u:
        send_otp(db, d.identifier, f"login_{d.role}", u)
    return GENERIC


@router.post("/admin/login")
def admin_login(d: AdminLogin, db: Session = Depends(get_db)):
    """Admin step 1: password check, then OTP is sent."""
    u = find(db, d.identifier, "admin")
    if not u or not verify_password(d.password, u.password_hash):
        raise HTTPException(401, "Invalid credentials")
    send_otp(db, d.identifier, "login_admin", u)
    return {"message": "Password verified. OTP sent to your registered email." if settings.OTP_PROVIDER == "email"
            else "Password verified. OTP sent."}


@router.post("/verify-otp")
def verify(d: VerifyReq, db: Session = Depends(get_db)):
    u = find(db, d.identifier, d.role)
    if not u or not verify_otp(db, d.identifier, d.otp, f"login_{d.role}"):
        raise HTTPException(401, "Invalid or expired OTP")
    audit.write(db, u, "Logged in", "POST", "/auth/verify-otp", 200)
    db.commit()
    school_name = None
    school_code = None
    if u.school_id:
        sch = db.get(m.School, u.school_id)
        if sch:
            school_name, school_code = sch.name, sch.code
    is_hostel = False
    if u.role == "student":
        st = db.query(m.Student).filter_by(user_id=u.id).first()
        is_hostel = bool(st and st.is_hostel)
    elif u.role == "parent":
        # true if any linked student is hosteler
        p = db.query(m.Parent).filter_by(user_id=u.id).first()
        if p:
            is_hostel = any(s.is_hostel for s in db.query(m.Student).filter_by(parent_id=p.id).all())
    return {
        "access_token": create_token(u.id, u.role),
        "token_type": "bearer",
        "role": u.role,
        "name": u.name,
        "school_id": u.school_id,
        "school_name": school_name,
        "school_code": school_code,
        "is_hostel": is_hostel,
    }


@router.get("/me")
def me(u: m.User = Depends(current_user), db: Session = Depends(get_db)):
    out = {"id": u.id, "name": u.name, "role": u.role, "mobile": u.mobile, "email": u.email, "school_id": u.school_id}
    if u.school_id:
        sch = db.get(m.School, u.school_id)
        if sch:
            out["school_name"] = sch.name
            out["school_code"] = sch.code
    out["is_hostel"] = False
    if u.role == "student":
        st = db.query(m.Student).filter_by(user_id=u.id).first()
        out["is_hostel"] = bool(st and st.is_hostel)
    elif u.role == "parent":
        p = db.query(m.Parent).filter_by(user_id=u.id).first()
        if p:
            out["is_hostel"] = any(s.is_hostel for s in db.query(m.Student).filter_by(parent_id=p.id).all())
    return out
