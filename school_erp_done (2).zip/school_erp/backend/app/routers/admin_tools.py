"""Admin extras: global search, full student profile, year-end promotion, user access, settings, audit log."""
import re
from collections import OrderedDict
from datetime import date, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query
from pydantic import BaseModel, Field
from sqlalchemy import or_
from sqlalchemy.orm import Session
from ..config import settings as env
from ..database import get_db
from ..models import models as m
from ..auth.deps import roles
from ..auth.security import verify_password, hash_password
from ..services import settings_service as ss
from ..services import student_data as sd
from ..utils.helpers import att_stats, class_students

router = APIRouter(prefix="/admin", tags=["admin-tools"])
public = APIRouter(prefix="/settings", tags=["settings"])
adm = Depends(roles("admin"))


def get_or_404(db, model, oid, what):
    o = db.get(model, oid)
    if not o:
        raise HTTPException(404, f"{what} not found")
    return o


# ------------------------------------------------------------------ global search
@router.get("/search")
def search(q: str = Query(..., min_length=2, max_length=60), db: Session = Depends(get_db), u=adm):
    like = f"%{q.strip()}%"
    out = []
    studs = (db.query(m.Student).join(m.User).filter(or_(m.User.name.ilike(like), m.User.mobile.ilike(like), m.User.email.ilike(like),
                                                         m.Student.admission_no.ilike(like))).limit(8).all())
    for s in studs:
        out.append({"type": "Student", "id": s.id, "title": s.user.name, "active": bool(s.user.is_active),
                    "sub": f"{s.klass.name}{'-' + s.section.name if s.section else ''} · Adm {s.admission_no}" + ("" if s.user.is_active else " · inactive"),
                    "url": f"student.html?id={s.id}"})
    for model, label, page in ((m.Teacher, "Teacher", "teachers"), (m.Parent, "Parent", "parents"), (m.HostelWarden, "Warden", "wardens")):
        rows = db.query(model).join(m.User).filter(or_(m.User.name.ilike(like), m.User.mobile.ilike(like), m.User.email.ilike(like))).limit(5).all()
        for r in rows:
            out.append({"type": label, "id": r.id, "title": r.user.name, "active": bool(r.user.is_active), "sub": r.user.mobile or r.user.email or "",
                        "url": f"{page}.html?q={r.user.name}"})
    return out


# ------------------------------------------------------------------ full student profile
@router.get("/students/{sid}/profile")
def student_profile(sid: int, db: Session = Depends(get_db), u=adm):
    s = get_or_404(db, m.Student, sid, "Student")
    att = att_stats(db, s.id)
    monthly = OrderedDict()
    rows = db.query(m.Attendance).filter(m.Attendance.student_id == s.id, m.Attendance.subject_id.is_(None)).order_by(m.Attendance.date).all()
    for r in rows:
        k = r.date.strftime("%b %Y")
        monthly.setdefault(k, [0, 0])
        monthly[k][1] += 1
        monthly[k][0] += 1 if r.status in ("Present", "Late") else 0
    results = sd.results(db, s)
    fees = sd.fees(db, s)
    perf = sd.subject_performance(db, s)
    hostel = None
    if s.is_hostel:
        a = db.query(m.HostelAllocation).filter_by(student_id=s.id).first()
        outs = db.query(m.HostelOutpass).filter_by(student_id=s.id).order_by(m.HostelOutpass.id.desc()).limit(5).all()
        hostel = {"room": a.room.room_no if a else "Not allocated", "since": str(a.allocated_on) if a else None,
                  "outpasses": [{"from": str(o.from_date), "to": str(o.to_date), "reason": o.reason, "status": o.status} for o in outs]}
    pays = [{"payment_id": p["id"], "fee_type": f["fee_type"], "paid_on": p["paid_on"], "amount": p["amount"], "mode": p["mode"]} for f in fees for p in f["payments"]]
    docs = []
    photo = None
    for d in db.query(m.StudentDocument).filter_by(student_id=s.id).order_by(m.StudentDocument.id.desc()).all():
        item = {"id": d.id, "doc_type": d.doc_type, "title": d.title or d.doc_type, "status": d.status,
                "file_path": d.file_path, "remarks": d.remarks or "", "uploaded_at": str(d.uploaded_at) if d.uploaded_at else ""}
        docs.append(item)
        if d.doc_type == "photo" and d.status != "Rejected" and not photo:
            photo = d.file_path
    return {
        "details": {"id": s.id, "user_id": s.user_id, "name": s.user.name, "mobile": s.user.mobile, "email": s.user.email, "admission_no": s.admission_no,
                    "roll_no": s.roll_no, "class": s.klass.name, "section": s.section.name if s.section else "-",
                    "class_id": s.class_id, "section_id": s.section_id,
                    "dob": str(s.dob) if s.dob else None, "gender": s.gender, "active": bool(s.user.is_active),
                    "parent_name": s.parent.user.name if s.parent else None, "parent_mobile": s.parent.user.mobile if s.parent else None,
                    "city": getattr(s, "city", None) or "", "photo": photo},
        "attendance": att, "attendance_breakdown": {"Present": att["present"], "Absent": att["absent"], "Late": att["late"], "Leave": att["leave"]},
        "attendance_monthly": {k: round(v[0] / v[1] * 100, 1) for k, v in monthly.items()},
        "average": round(sum(r["percentage"] for r in results) / len(results), 1) if results else 0,
        "subject_performance": perf, "results": results, "fees": fees, "payments": pays,
        "fee_status": {"Paid": round(sum(f["paid"] for f in fees), 2), "Pending": round(sum(f["pending"] for f in fees), 2)},
        "pending_fees": round(sum(f["pending"] for f in fees), 2), "hostel": hostel,
        "documents": docs,
    }


@router.get("/fees/pending")
def pending_fees(db: Session = Depends(get_db), u=adm):
    """Dropdown for 'Record payment' - no more typing a Fee ID."""
    out = []
    for f in db.query(m.Fee).join(m.Student).join(m.User).filter(m.User.is_active == True).order_by(m.Fee.id.desc()):  # noqa: E712
        paid = sum(p.amount for p in db.query(m.FeePayment).filter_by(fee_id=f.id))
        if f.amount - paid > 0.005:
            out.append({"id": f.id, "label": f"{f.student.user.name} - {f.fee_type} (due Rs. {f.amount - paid:,.2f})"})
    return out


# ------------------------------------------------------------------ users: activate / deactivate
@router.get("/users")
def users(role: Optional[str] = None, db: Session = Depends(get_db), u=adm):
    q = db.query(m.User).order_by(m.User.role, m.User.name)
    if u.school_id:
        q = q.filter(m.User.school_id == u.school_id)
    if role:
        q = q.filter(m.User.role == role)
    return [{"id": x.id, "name": x.name, "role": x.role, "mobile": x.mobile or "-", "email": x.email or "-",
             "status": "Active" if x.is_active else "Inactive", "created": x.created_at.strftime("%Y-%m-%d") if x.created_at else "-"} for x in q.all()]


def _toggle(db, admin, uid, active):
    x = get_or_404(db, m.User, uid, "User")
    if admin.school_id and x.school_id != admin.school_id:
        raise HTTPException(404, "User not found")
    if x.role == "admin":
        raise HTTPException(400, "Admin accounts cannot be deactivated here")
    if x.id == admin.id:
        raise HTTPException(400, "You cannot deactivate yourself")
    x.is_active = active
    db.commit()
    return {"message": f"{x.name} is now {'active' if active else 'inactive'}"}


@router.post("/users/{uid}/deactivate")
def deactivate(uid: int, db: Session = Depends(get_db), u=adm):
    return _toggle(db, u, uid, False)


@router.post("/users/{uid}/activate")
def activate(uid: int, db: Session = Depends(get_db), u=adm):
    return _toggle(db, u, uid, True)


# ------------------------------------------------------------------ year-end promotion
def suggest_next(db, name, school_id=None):
    mo = re.match(r"^(.*?)(\d+)$", name.strip())
    if not mo:
        return None
    q = db.query(m.SchoolClass).filter(m.SchoolClass.name == f"{mo.group(1)}{int(mo.group(2)) + 1}")
    if school_id:
        q = q.filter_by(school_id=school_id)
    nxt = q.first()
    return nxt.id if nxt else None


@router.get("/promotion/preview")
def promotion_preview(class_id: int, db: Session = Depends(get_db), u=adm):
    c = get_or_404(db, m.SchoolClass, class_id, "Class")
    if u.school_id and c.school_id != u.school_id:
        raise HTTPException(404, "Class not found")
    studs = []
    for s in class_students(db, class_id):
        f = sd.fees(db, s)
        studs.append({"id": s.id, "name": s.user.name, "roll_no": s.roll_no, "section": s.section.name if s.section else "-",
                      "attendance": att_stats(db, s.id)["percentage"], "pending_fees": round(sum(x["pending"] for x in f), 2)})
    ay_q = db.query(m.AcademicYear).filter_by(is_current=True)
    if u.school_id:
        ay_q = ay_q.filter_by(school_id=u.school_id)
    ay = ay_q.first()
    return {"class": c.name, "students": studs, "next_class_id": suggest_next(db, c.name, u.school_id), "current_year": ay.name if ay else None}


class PromoteIn(BaseModel):
    from_class_id: int
    to_class_id: Optional[int] = None            # None = students leave school (graduate)
    student_ids: list[int] = Field(min_length=1, max_length=1000)
    academic_year: Optional[str] = Field(None, max_length=20)


@router.post("/promotion")
def promote(d: PromoteIn, db: Session = Depends(get_db), u=adm):
    src = get_or_404(db, m.SchoolClass, d.from_class_id, "Class")
    if u.school_id and src.school_id != u.school_id:
        raise HTTPException(404, "Class not found")
    dst = get_or_404(db, m.SchoolClass, d.to_class_id, "Target class") if d.to_class_id else None
    if dst and dst.id == src.id:
        raise HTTPException(400, "Choose a different target class")
    studs = {s.id: s for s in class_students(db, src.id)}
    bad = [i for i in d.student_ids if i not in studs]
    if bad:
        raise HTTPException(400, f"Students {bad} are not active students of {src.name}")
    ay = db.query(m.AcademicYear).filter_by(is_current=True).first()
    name = (d.academic_year or "").strip()
    if name and (not ay or ay.name != name):
        ay = db.query(m.AcademicYear).filter_by(name=name).first() or m.AcademicYear(name=name)
        (db.query(m.AcademicYear).filter_by(school_id=u.school_id).update({m.AcademicYear.is_current: False}) if u.school_id else db.query(m.AcademicYear).update({m.AcademicYear.is_current: False}))
        ay.is_current = True
        db.add(ay)
        db.flush()
    no_section = 0
    for sid in set(d.student_ids):
        s = studs[sid]
        if dst:
            new_sec = None
            if s.section:
                match = db.query(m.Section).filter_by(class_id=dst.id, name=s.section.name).first()
                new_sec = match.id if match else None
            no_section += 0 if new_sec or not s.section_id else 1
            s.class_id, s.section_id = dst.id, new_sec
            row = db.query(m.StudentClass).filter_by(student_id=s.id, academic_year_id=ay.id if ay else None).first()
            if row:
                row.class_id, row.section_id = dst.id, new_sec
            else:
                db.add(m.StudentClass(student_id=s.id, class_id=dst.id, section_id=new_sec, academic_year_id=ay.id if ay else None))
        else:
            s.user.is_active = False                 # alumni: kept in the database, cannot log in
            db.query(m.HostelAllocation).filter_by(student_id=s.id).delete()
    db.commit()
    n = len(set(d.student_ids))
    msg = f"{n} students promoted from {src.name} to {dst.name}" if dst else f"{n} students of {src.name} marked as left school (graduated)"
    if no_section:
        msg += f". {no_section} have no matching section in {dst.name} - set it with Edit."
    return {"message": msg, "unassigned_section": no_section}


# ------------------------------------------------------------------ settings + password
class SettingsIn(BaseModel):
    school_name: Optional[str] = Field(None, min_length=2, max_length=100)
    address: Optional[str] = Field(None, max_length=200)
    phone: Optional[str] = Field(None, max_length=30)
    email: Optional[str] = Field(None, max_length=100)
    low_attendance: Optional[float] = Field(None, ge=1, le=100)
    school_code: Optional[str] = Field(None, min_length=3, max_length=20)


@router.get("/settings")
def get_settings(db: Session = Depends(get_db), u=adm):
    return ss.get_all(db, u.school_id)


@router.put("/settings")
def put_settings(d: SettingsIn, db: Session = Depends(get_db), u=adm):
    v = {k: x for k, x in d.model_dump(exclude_unset=True).items() if x is not None}
    if v.get("email") and "@" not in v["email"]:
        raise HTTPException(422, "Invalid email address")
    if v.get("school_code"):
        code = v["school_code"].upper().strip()
        other = db.query(m.School).filter(m.School.code == code, m.School.id != u.school_id).first()
        if other:
            raise HTTPException(409, "School code already in use")
        v["school_code"] = code
    ss.set_many(db, v, u.school_id)
    db.commit()
    return {"message": "Settings saved"}


@public.get("/public")
def public_settings(db: Session = Depends(get_db)):
    return {"school_name": ss.school_name(db)}


class PasswordIn(BaseModel):
    old_password: str = Field(min_length=1, max_length=72)
    new_password: str = Field(min_length=8, max_length=72)


@router.post("/change-password")
def change_password(d: PasswordIn, db: Session = Depends(get_db), u=adm):
    if not verify_password(d.old_password, u.password_hash or ""):
        raise HTTPException(400, "Your current password is wrong")
    if not (re.search(r"[A-Za-z]", d.new_password) and re.search(r"\d", d.new_password)):
        raise HTTPException(422, "New password needs at least one letter and one number")
    if d.new_password == d.old_password:
        raise HTTPException(400, "The new password must be different from the old one")
    u.password_hash = hash_password(d.new_password)
    db.commit()
    return {"message": "Password changed. Use the new password next time you log in."}


# ------------------------------------------------------------------ audit log
@router.get("/audit")
def audit(days: int = Query(30, ge=1, le=365), db: Session = Depends(get_db), u=adm):
    since = date.today() - timedelta(days=days)
    q = db.query(m.AuditLog).filter(m.AuditLog.created_at >= since)
    if hasattr(m.AuditLog, "school_id") and u.school_id:
        q = q.filter(m.AuditLog.school_id == u.school_id)
    rows = q.order_by(m.AuditLog.id.desc()).limit(1000).all()
    off = timedelta(minutes=env.TZ_OFFSET_MINUTES)
    return [{"id": r.id, "time": (r.created_at + off).strftime("%Y-%m-%d %H:%M"), "day": (r.created_at + off).strftime("%d %b"),
             "user": r.user_name or "-", "role": r.role or "-", "action": r.action, "ip": r.ip or "-"} for r in rows]


@router.post("/students/{sid}/photo")
def upload_student_photo(sid: int, file: UploadFile = File(...), db: Session = Depends(get_db), u=adm):
    s = get_or_404(db, m.Student, sid, "Student")
    from ..utils.helpers import save_upload
    path = save_upload(file)
    # mark older photos rejected optionally
    for d in db.query(m.StudentDocument).filter_by(student_id=s.id, doc_type="photo").all():
        if d.status == "Pending":
            d.status = "Verified"
    d = m.StudentDocument(student_id=s.id, doc_type="photo", title="Profile photo",
                          file_path=path, status="Verified")
    db.add(d)
    db.commit()
    return {"message": "Photo uploaded", "file": path}


@router.post("/teachers/{tid}/photo")
def upload_teacher_photo(tid: int, file: UploadFile = File(...), db: Session = Depends(get_db), u=adm):
    t = get_or_404(db, m.Teacher, tid, "Teacher")
    from ..utils.helpers import save_upload
    path = save_upload(file)
    t.photo_path = path
    db.commit()
    return {"message": "Teacher photo uploaded", "file": path}


@router.get("/exams/{exam_id}/class-report")
def exam_class_report(exam_id: int, db: Session = Depends(get_db), u=adm):
    """Class-wise results for one exam (for UI table + PDF generation)."""
    e = get_or_404(db, m.Exam, exam_id, "Exam")
    results = db.query(m.ExamResult).filter_by(exam_id=exam_id).all()
    rows = []
    for r in results:
        rows.append({
            "student_id": r.student_id,
            "student": r.student.user.name if r.student and r.student.user else "",
            "roll_no": r.student.roll_no if r.student else "",
            "internal": r.internal_marks,
            "exam": r.exam_marks,
            "total": r.total,
            "percentage": r.percentage,
            "grade": r.grade,
            "result": "Pass" if r.passed else "Fail",
            "published": r.published,
        })
    rows.sort(key=lambda x: (-(x["percentage"] or 0), x["student"]))
    return {
        "exam": e.name,
        "subject": e.subject.name if e.subject else "",
        "class": e.klass.name if e.klass else "",
        "date": str(e.exam_date) if e.exam_date else "",
        "rows": rows,
        "count": len(rows),
        "average": round(sum(r["percentage"] or 0 for r in rows) / len(rows), 1) if rows else 0,
    }

