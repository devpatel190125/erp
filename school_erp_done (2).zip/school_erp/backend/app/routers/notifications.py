from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from ..schemas import NoticeIn, EventIn
from ..auth.deps import roles, current_user
from ..utils.helpers import notify, ser, require_school, school_scope_users

router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.get("/my")
def mine(db: Session = Depends(get_db), u=Depends(current_user)):
    return [{**ser(n, "id", "title", "message", "type", "is_read", "created_at")}
            for n in db.query(m.Notification).filter_by(user_id=u.id).order_by(m.Notification.id.desc()).limit(50)]


@router.post("/{nid}/read")
def read(nid: int, db: Session = Depends(get_db), u=Depends(current_user)):
    n = db.query(m.Notification).filter_by(id=nid, user_id=u.id).first()
    if not n:
        raise HTTPException(404, "Not found")
    n.is_read = True
    db.commit()
    return {"message": "ok"}


@router.get("/notices")
def notices(db: Session = Depends(get_db), u=Depends(current_user)):
    q = db.query(m.Notice)
    if u.school_id:
        q = q.filter(m.Notice.school_id == u.school_id)
    if u.role != "admin":
        q = q.filter(or_(m.Notice.audience == "all", m.Notice.audience == u.role))
    return [{**ser(n, "id", "title", "body", "audience", "category", "created_at"), "mine": u.role == "admin" or n.created_by == u.id}
            for n in q.order_by(m.Notice.id.desc()).limit(100)]


@router.post("/notices")
def create_notice(d: NoticeIn, db: Session = Depends(get_db), u=Depends(roles("admin", "teacher", "warden"))):
    if u.role == "warden":
        d.category = "hostel"
    data = d.model_dump()
    data["school_id"] = require_school(u)
    db.add(m.Notice(created_by=u.id, **data))
    q = school_scope_users(db, u).filter(m.User.id != u.id)
    if d.audience != "all":
        q = q.filter_by(role=d.audience)
    for t in q.all():
        notify(db, t.id, f"Notice: {d.title}", d.body, "notice")
    db.commit()
    return {"message": "Notice published"}


@router.get("/events")
def events(db: Session = Depends(get_db), u=Depends(current_user)):
    q = db.query(m.Event)
    if u.school_id:
        q = q.filter(m.Event.school_id == u.school_id)
    return [ser(e, "id", "title", "description", "event_date") for e in q.order_by(m.Event.event_date.desc())]


@router.post("/events")
def create_event(d: EventIn, db: Session = Depends(get_db), u=Depends(roles("admin"))):
    data = d.model_dump()
    data["school_id"] = require_school(u)
    db.add(m.Event(**data))
    for t in school_scope_users(db, u):
        notify(db, t.id, f"Event: {d.title}", d.description, "event")
    db.commit()
    return {"message": "Event created"}
