from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..schemas import AIChatIn
from ..auth.deps import current_user
from ..ai import ai_service

router = APIRouter(prefix="/ai", tags=["ai"])


@router.get("/status")
def status(u=Depends(current_user)):
    return ai_service.status()


@router.post("/chat")
def chat(d: AIChatIn, db: Session = Depends(get_db), u=Depends(current_user)):
    return ai_service.chat(db, u, d.message, d.conversation_id)
