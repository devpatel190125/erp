from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import models as m
from .security import decode_token

bearer = HTTPBearer(auto_error=False)


def current_user(creds: HTTPAuthorizationCredentials = Depends(bearer), db: Session = Depends(get_db)) -> m.User:
    if not creds:
        raise HTTPException(401, "Not authenticated")
    data = decode_token(creds.credentials)
    if not data:
        raise HTTPException(401, "Invalid or expired token")
    user = db.get(m.User, int(data["sub"]))
    if not user or not user.is_active or user.role != data.get("role"):
        raise HTTPException(401, "User not found or inactive")
    return user


def roles(*allowed: str):
    def dep(user: m.User = Depends(current_user)) -> m.User:
        if user.role not in allowed:
            raise HTTPException(403, "You do not have permission for this action")
        return user
    return dep


def school_id_of(user: m.User) -> int:
    """Return the user's school_id or raise if missing."""
    if not user.school_id:
        raise HTTPException(400, "Account is not linked to a school")
    return user.school_id


def same_school(db: Session, user: m.User, other_user_id: int) -> bool:
    other = db.get(m.User, other_user_id)
    return bool(other and other.school_id and other.school_id == user.school_id)
