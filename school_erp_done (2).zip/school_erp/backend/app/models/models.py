from datetime import datetime
from sqlalchemy import (Column, Integer, String, Text, Date, DateTime, Boolean, Float,
                        ForeignKey, UniqueConstraint, Index)
from sqlalchemy.orm import relationship
from ..database import Base


def ts():
    return Column(DateTime, default=datetime.utcnow)


def fk(t, **k):
    return Column(Integer, ForeignKey(t), **k)


class School(Base):
    """One row per registered school (multi-tenant)."""
    __tablename__ = "schools"
    id = Column(Integer, primary_key=True)
    code = Column(String(20), unique=True, nullable=False, index=True)  # e.g. SCH-A7K2
    name = Column(String(120), nullable=False)
    address = Column(String(255))
    city = Column(String(80))
    state = Column(String(80))
    pincode = Column(String(12))
    phone = Column(String(20))
    email = Column(String(120))
    is_active = Column(Boolean, default=True)
    created_at = ts()


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    school_id = fk("schools.id", index=True)  # null only for legacy; new users always set
    role = Column(String(20), nullable=False, index=True)  # admin/student/teacher/warden/parent
    name = Column(String(120), nullable=False)
    email = Column(String(120), unique=True)
    mobile = Column(String(15), unique=True)
    password_hash = Column(String(255))  # admin only
    is_active = Column(Boolean, default=True)
    created_at = ts()
    school = relationship("School")


class AcademicYear(Base):
    __tablename__ = "academic_years"
    id = Column(Integer, primary_key=True)
    school_id = fk("schools.id", index=True)
    name = Column(String(20), nullable=False)
    is_current = Column(Boolean, default=False)
    __table_args__ = (UniqueConstraint("school_id", "name"),)


class SchoolClass(Base):
    __tablename__ = "classes"
    id = Column(Integer, primary_key=True)
    school_id = fk("schools.id", index=True)
    name = Column(String(30), nullable=False)
    capacity = Column(Integer, default=40)
    class_teacher_id = Column(Integer, ForeignKey("teachers.id"), nullable=True)
    class_teacher = relationship(
        "Teacher", foreign_keys=[class_teacher_id],
        primaryjoin="SchoolClass.class_teacher_id==Teacher.id",
        post_update=True,
    )
    __table_args__ = (UniqueConstraint("school_id", "name"),)


class Section(Base):
    __tablename__ = "sections"
    id = Column(Integer, primary_key=True)
    class_id = fk("classes.id", nullable=False)
    name = Column(String(10), nullable=False)
    klass = relationship("SchoolClass")
    __table_args__ = (UniqueConstraint("class_id", "name"),)


class Subject(Base):
    __tablename__ = "subjects"
    id = Column(Integer, primary_key=True)
    name = Column(String(80), nullable=False)
    class_id = fk("classes.id", nullable=False)
    klass = relationship("SchoolClass")
    __table_args__ = (UniqueConstraint("class_id", "name"),)


class Parent(Base):
    __tablename__ = "parents"
    id = Column(Integer, primary_key=True)
    user_id = fk("users.id", unique=True, nullable=False)
    user = relationship("User")


class Student(Base):
    __tablename__ = "students"
    id = Column(Integer, primary_key=True)
    user_id = fk("users.id", unique=True, nullable=False)
    admission_no = Column(String(30), nullable=False)
    roll_no = Column(Integer)
    class_id = fk("classes.id", nullable=False, index=True)
    section_id = fk("sections.id")
    parent_id = fk("parents.id", index=True)
    dob = Column(Date)
    gender = Column(String(10))
    address_line1 = Column(String(120))
    address_line2 = Column(String(120))
    city = Column(String(80))
    state = Column(String(80))
    pincode = Column(String(12))
    is_hostel = Column(Boolean, default=False)
    user = relationship("User")
    klass = relationship("SchoolClass")
    section = relationship("Section")
    parent = relationship("Parent")
    __table_args__ = (Index("ix_student_adm", "admission_no"),)


class StudentClass(Base):
    __tablename__ = "student_classes"
    id = Column(Integer, primary_key=True)
    student_id = fk("students.id", nullable=False)
    class_id = fk("classes.id", nullable=False)
    section_id = fk("sections.id")
    academic_year_id = fk("academic_years.id")


class Teacher(Base):
    __tablename__ = "teachers"
    id = Column(Integer, primary_key=True)
    user_id = fk("users.id", unique=True, nullable=False)
    employee_no = Column(String(30), unique=True)
    qualification = Column(String(120))
    experience = Column(String(60))  # e.g. "5 years"
    class_id = fk("classes.id")  # optional assigned class (one)
    photo_path = Column(String(255))
    user = relationship("User")
    klass = relationship(
        "SchoolClass", foreign_keys=[class_id],
        primaryjoin="Teacher.class_id==SchoolClass.id",
    )


class StudentDocument(Base):
    """Student uploaded documents; admin verifies."""
    __tablename__ = "student_documents"
    id = Column(Integer, primary_key=True)
    student_id = fk("students.id", nullable=False, index=True)
    doc_type = Column(String(40), nullable=False)  # photo, aadhaar, birth_cert, marksheet, tc, other
    title = Column(String(120))
    file_path = Column(String(255), nullable=False)
    status = Column(String(15), default="Pending")  # Pending / Verified / Rejected
    remarks = Column(String(250))
    uploaded_at = ts()
    verified_by = fk("users.id")
    student = relationship("Student")


class TeacherSubject(Base):
    __tablename__ = "teacher_subjects"
    id = Column(Integer, primary_key=True)
    teacher_id = fk("teachers.id", nullable=False, index=True)
    subject_id = fk("subjects.id", nullable=False)
    class_id = fk("classes.id", nullable=False, index=True)
    section_id = fk("sections.id")
    teacher = relationship("Teacher")
    subject = relationship("Subject")
    klass = relationship("SchoolClass")
    section = relationship("Section")


class Hostel(Base):
    __tablename__ = "hostels"
    id = Column(Integer, primary_key=True)
    school_id = fk("schools.id", index=True)
    name = Column(String(80), nullable=False)


class HostelBlock(Base):
    """Named blocks inside a hostel (A, B, North Wing...)."""
    __tablename__ = "hostel_blocks"
    id = Column(Integer, primary_key=True)
    hostel_id = fk("hostels.id", nullable=False, index=True)
    name = Column(String(40), nullable=False)  # e.g. A, B, North
    floors = Column(Integer, default=2)  # how many floors this block has
    __table_args__ = (UniqueConstraint("hostel_id", "name"),)


class HostelWarden(Base):
    __tablename__ = "hostel_wardens"
    id = Column(Integer, primary_key=True)
    user_id = fk("users.id", unique=True, nullable=False)
    hostel_id = fk("hostels.id")
    user = relationship("User")


class HostelRoom(Base):
    __tablename__ = "hostel_rooms"
    id = Column(Integer, primary_key=True)
    hostel_id = fk("hostels.id", nullable=False)
    block = Column(String(20), default="A")       # Block A/B/C
    floor = Column(Integer, default=1)            # Floor number
    room_no = Column(String(10), nullable=False)
    capacity = Column(Integer, default=2)         # editable bed capacity
    __table_args__ = (UniqueConstraint("hostel_id", "room_no"),)


class HostelAllocation(Base):
    __tablename__ = "hostel_allocations"
    id = Column(Integer, primary_key=True)
    student_id = fk("students.id", unique=True, nullable=False)
    room_id = fk("hostel_rooms.id", nullable=False, index=True)
    bed_no = Column(Integer, default=1)  # bed 1..capacity within room
    allocated_on = Column(Date, default=datetime.utcnow)
    student = relationship("Student")
    room = relationship("HostelRoom")


class HostelAttendance(Base):
    __tablename__ = "hostel_attendance"
    id = Column(Integer, primary_key=True)
    student_id = fk("students.id", nullable=False)
    date = Column(Date, nullable=False)
    status = Column(String(10), nullable=False)
    __table_args__ = (UniqueConstraint("student_id", "date"),)


class HostelComplaint(Base):
    __tablename__ = "hostel_complaints"
    id = Column(Integer, primary_key=True)
    student_id = fk("students.id")
    description = Column(Text, nullable=False)
    category = Column(String(30))
    priority = Column(String(10))
    status = Column(String(15), default="Open")
    created_at = ts()
    student = relationship("Student")


class HostelVisitor(Base):
    __tablename__ = "hostel_visitors"
    id = Column(Integer, primary_key=True)
    student_id = fk("students.id", nullable=False)
    visitor_name = Column(String(100), nullable=False)
    relation = Column(String(40))
    purpose = Column(String(200))
    in_time = ts()
    out_time = Column(DateTime)
    student = relationship("Student")


class Attendance(Base):
    __tablename__ = "attendance"
    id = Column(Integer, primary_key=True)
    student_id = fk("students.id", nullable=False)
    date = Column(Date, nullable=False)
    status = Column(String(10), nullable=False)  # Present/Absent/Late/Leave
    subject_id = fk("subjects.id")               # NULL = daily attendance
    marked_by = fk("users.id")
    __table_args__ = (UniqueConstraint("student_id", "date", "subject_id"), Index("ix_att_sd", "student_id", "date"))


class Homework(Base):
    __tablename__ = "homework"
    id = Column(Integer, primary_key=True)
    class_id = fk("classes.id", nullable=False, index=True)
    section_id = fk("sections.id")
    subject_id = fk("subjects.id", nullable=False)
    teacher_id = fk("teachers.id", nullable=False)
    title = Column(String(150), nullable=False)
    description = Column(Text)
    due_date = Column(Date)
    created_at = ts()
    subject = relationship("Subject")


class Assignment(Base):
    __tablename__ = "assignments"
    id = Column(Integer, primary_key=True)
    class_id = fk("classes.id", nullable=False, index=True)
    section_id = fk("sections.id")
    subject_id = fk("subjects.id", nullable=False)
    teacher_id = fk("teachers.id", nullable=False)
    title = Column(String(150), nullable=False)
    description = Column(Text)
    due_date = Column(Date)
    max_marks = Column(Integer, default=10)
    created_at = ts()
    subject = relationship("Subject")


class AssignmentSubmission(Base):
    __tablename__ = "assignment_submissions"
    id = Column(Integer, primary_key=True)
    assignment_id = fk("assignments.id", nullable=False)
    student_id = fk("students.id", nullable=False)
    file_path = Column(String(255))
    submitted_at = ts()
    marks = Column(Float)
    feedback = Column(Text)
    student = relationship("Student")
    __table_args__ = (UniqueConstraint("assignment_id", "student_id"),)


class Exam(Base):
    __tablename__ = "exams"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    # exam = whole class (terminal); test = section-wise (unit test)
    exam_type = Column(String(10), default="exam")  # exam | test
    class_id = fk("classes.id", nullable=False, index=True)
    section_id = fk("sections.id")  # used when exam_type=test
    subject_id = fk("subjects.id", nullable=False)
    exam_date = Column(Date)
    start_time = Column(String(10))  # e.g. "09:00"
    end_time = Column(String(10))
    internal_max = Column(Integer, default=20)
    max_marks = Column(Integer, default=80)
    subject = relationship("Subject")
    klass = relationship("SchoolClass")
    section = relationship("Section")


class ExamResult(Base):
    __tablename__ = "exam_results"
    id = Column(Integer, primary_key=True)
    exam_id = fk("exams.id", nullable=False, index=True)
    student_id = fk("students.id", nullable=False, index=True)
    internal_marks = Column(Float, default=0)
    exam_marks = Column(Float, default=0)
    total = Column(Float)
    percentage = Column(Float)
    grade = Column(String(3))
    passed = Column(Boolean)
    published = Column(Boolean, default=False)
    exam = relationship("Exam")
    student = relationship("Student")
    __table_args__ = (UniqueConstraint("exam_id", "student_id"),)


class FeeHead(Base):
    """Custom fee types per school (unlimited heads)."""
    __tablename__ = "fee_heads"
    id = Column(Integer, primary_key=True)
    school_id = fk("schools.id", index=True)
    name = Column(String(60), nullable=False)  # Tuition, Lab, Library...
    default_amount = Column(Float, default=0)
    frequency = Column(String(20), default="Monthly")  # Monthly, Quarterly, Annual, One-time
    applicable_classes = Column(String(255), default="")  # comma-separated class ids or names
    is_active = Column(Boolean, default=True)
    __table_args__ = (UniqueConstraint("school_id", "name"),)


class Fee(Base):
    __tablename__ = "fees"
    id = Column(Integer, primary_key=True)
    student_id = fk("students.id", nullable=False, index=True)
    fee_type = Column(String(30), nullable=False)
    amount = Column(Float, nullable=False)
    due_date = Column(Date)
    student = relationship("Student")


class FeePayment(Base):
    __tablename__ = "fee_payments"
    id = Column(Integer, primary_key=True)
    fee_id = fk("fees.id", nullable=False, index=True)
    amount = Column(Float, nullable=False)
    paid_on = Column(Date, default=datetime.utcnow)
    mode = Column(String(20), default="Cash")


class Timetable(Base):
    __tablename__ = "timetable"
    id = Column(Integer, primary_key=True)
    class_id = fk("classes.id", nullable=False, index=True)
    section_id = fk("sections.id")
    subject_id = fk("subjects.id", nullable=False)
    teacher_id = fk("teachers.id")
    room = Column(String(20))
    day = Column(String(10), nullable=False)
    start_time = Column(String(5), nullable=False)
    end_time = Column(String(5), nullable=False)
    subject = relationship("Subject")
    teacher = relationship("Teacher")


class Notice(Base):
    __tablename__ = "notices"
    id = Column(Integer, primary_key=True)
    school_id = fk("schools.id", index=True)
    title = Column(String(150), nullable=False)
    body = Column(Text)
    audience = Column(String(20), default="all")
    category = Column(String(20), default="general")
    created_by = fk("users.id")
    created_at = ts()


class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = fk("users.id", nullable=False, index=True)
    title = Column(String(150), nullable=False)
    message = Column(Text)
    type = Column(String(30), default="general")
    is_read = Column(Boolean, default=False)
    created_at = ts()


class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True)
    school_id = fk("schools.id", index=True)
    title = Column(String(150), nullable=False)
    description = Column(Text)
    event_date = Column(Date)


class Complaint(Base):
    __tablename__ = "complaints"
    id = Column(Integer, primary_key=True)
    user_id = fk("users.id", nullable=False, index=True)
    subject = Column(String(150), nullable=False)
    description = Column(Text)
    status = Column(String(15), default="Open")
    created_at = ts()
    user = relationship("User")


class StudyMaterial(Base):
    __tablename__ = "study_materials"
    id = Column(Integer, primary_key=True)
    class_id = fk("classes.id", nullable=False, index=True)
    subject_id = fk("subjects.id", nullable=False)
    teacher_id = fk("teachers.id")
    title = Column(String(150), nullable=False)
    file_path = Column(String(255), nullable=False)
    created_at = ts()
    subject = relationship("Subject")


class OtpVerification(Base):
    __tablename__ = "otp_verifications"
    id = Column(Integer, primary_key=True)
    identifier = Column(String(120), nullable=False, index=True)
    purpose = Column(String(20), nullable=False)
    otp_hash = Column(String(64), nullable=False)  # HMAC-SHA256, plain OTP never stored
    attempts = Column(Integer, default=0)
    used = Column(Boolean, default=False)
    expires_at = Column(DateTime, nullable=False)
    created_at = ts()


class AIConversation(Base):
    __tablename__ = "ai_conversations"
    id = Column(Integer, primary_key=True)
    user_id = fk("users.id", nullable=False, index=True)
    created_at = ts()


class AIMessage(Base):
    __tablename__ = "ai_messages"
    id = Column(Integer, primary_key=True)
    conversation_id = fk("ai_conversations.id", nullable=False, index=True)
    sender = Column(String(10), nullable=False)
    content = Column(Text, nullable=False)
    created_at = ts()


class SchoolSetting(Base):
    """Per-school key/value settings. Composite PK: school_id + key."""
    __tablename__ = "school_settings"
    school_id = Column(Integer, ForeignKey("schools.id"), primary_key=True, default=0)
    key = Column(String(50), primary_key=True)
    value = Column(Text)


class AuditLog(Base):
    """Who changed what. Filled automatically for every successful POST/PUT/DELETE (see main.py middleware)."""
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True)
    user_id = fk("users.id", index=True)
    user_name = Column(String(120))
    role = Column(String(20))
    action = Column(String(200), nullable=False)
    method = Column(String(8))
    path = Column(String(200))
    status_code = Column(Integer)
    ip = Column(String(45))
    created_at = Column(DateTime, default=datetime.utcnow, index=True)


class HostelOutpass(Base):
    __tablename__ = "hostel_outpass"
    id = Column(Integer, primary_key=True)
    student_id = fk("students.id", nullable=False, index=True)
    from_date = Column(Date, nullable=False)
    to_date = Column(Date, nullable=False)
    reason = Column(String(250), nullable=False)
    status = Column(String(15), default="Pending")      # Pending / Approved / Rejected / Returned
    remarks = Column(String(250))
    decided_by = fk("users.id")
    created_at = ts()
    student = relationship("Student")


class MessMenu(Base):
    __tablename__ = "mess_menu"
    id = Column(Integer, primary_key=True)
    school_id = fk("schools.id", index=True)
    day = Column(String(10), nullable=False)
    meal = Column(String(15), nullable=False)
    items = Column(String(250))
    __table_args__ = (UniqueConstraint("school_id", "day", "meal"),)
