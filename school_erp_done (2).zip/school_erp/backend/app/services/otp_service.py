import html
import hashlib, hmac, secrets, smtplib, logging, ssl
from email.message import EmailMessage
from datetime import datetime, timedelta
import httpx
from fastapi import HTTPException
from sqlalchemy.orm import Session
from ..config import settings
from ..models import models as m


log = logging.getLogger("otp")


class ConsoleProvider:
    def send(self, to, otp, user=None):
        print(f"[DEV OTP] to={to} otp={otp}")


class EmailProvider:
    """Sends the OTP to the user's REGISTERED email (users.email), whatever they typed to log in."""
    def send(self, to, otp, user=None):
        dest = getattr(user, "email", None)
        if not dest:
            raise HTTPException(400, "No email address is registered for this account. Ask the school admin to add one.")
        if not settings.SMTP_USER or not settings.SMTP_PASSWORD:
            raise HTTPException(503, "Email is not configured on the server (SMTP_USER / SMTP_PASSWORD).")
        msg = EmailMessage()
        msg["Subject"] = f"{otp} is your {settings.SCHOOL_NAME} login code"
        msg["From"] = settings.SMTP_FROM or settings.SMTP_USER
        msg["To"] = dest
        msg.set_content(f"Hello {user.name},\n\nYour {settings.SCHOOL_NAME} one-time password is: {otp}\n\n"
                        f"It is valid for {settings.OTP_EXPIRY_MINUTES} minutes. Never share it with anyone.\n"
                        "If you did not try to log in, ignore this email.")
        msg.add_alternative(f"""<div style="font-family:Arial,sans-serif;max-width:420px;margin:auto">
<h2 style="color:#4f46e5">{html.escape(settings.SCHOOL_NAME)}</h2><p>Hello {html.escape(user.name or "")},</p><p>Your login code is</p>
<p style="font-size:32px;letter-spacing:8px;font-weight:700;background:#eef0ff;padding:12px;text-align:center;border-radius:8px">{otp}</p>
<p style="color:#666">Valid for {settings.OTP_EXPIRY_MINUTES} minutes. Never share it with anyone.</p></div>""", subtype="html")
        try:
            with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=15) as s:
                s.starttls(context=ssl.create_default_context())
                s.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
                s.send_message(msg)
        except smtplib.SMTPAuthenticationError:
            log.error("SMTP login failed - for Gmail use an App Password")
            raise HTTPException(502, "Email login failed on the server (check SMTP_USER / App Password).")
        except Exception as e:  # network, DNS, TLS ...
            log.error("SMTP send failed: %s", e)
            raise HTTPException(502, "Could not send the email right now. Try again in a minute.")


class TwilioProvider:
    def send(self, to, otp, user=None):
        r = httpx.post(f"https://api.twilio.com/2010-04-01/Accounts/{settings.TWILIO_SID}/Messages.json",
                   auth=(settings.TWILIO_SID, settings.TWILIO_TOKEN),
                   data={"From": settings.TWILIO_FROM, "To": to, "Body": f"Your School ERP OTP is {otp}"}, timeout=15)
        r.raise_for_status()


def provider():
    return {"twilio": TwilioProvider, "email": EmailProvider}.get(settings.OTP_PROVIDER, ConsoleProvider)()


def _hash(identifier, otp):
    return hmac.new(settings.SECRET_KEY.encode(), f"{identifier}:{otp}".encode(), hashlib.sha256).hexdigest()


def send_otp(db: Session, identifier: str, purpose: str, user=None):
    now = datetime.utcnow()
    last = db.query(m.OtpVerification).filter_by(identifier=identifier, purpose=purpose)\
        .order_by(m.OtpVerification.id.desc()).first()
    if last and (now - last.created_at).total_seconds() < settings.OTP_RESEND_SECONDS:
        raise HTTPException(429, f"Please wait {settings.OTP_RESEND_SECONDS} seconds before requesting another OTP")
    recent = db.query(m.OtpVerification).filter(m.OtpVerification.identifier == identifier,
                                                m.OtpVerification.created_at > now - timedelta(hours=1)).count()
    if recent >= settings.OTP_MAX_REQUESTS_PER_HOUR:
        raise HTTPException(429, "Too many OTP requests. Try again later.")
    db.query(m.OtpVerification).filter_by(identifier=identifier, purpose=purpose, used=False).update({"used": True})
    otp = settings.DEV_FIXED_OTP if (settings.OTP_PROVIDER == "console" and settings.DEV_FIXED_OTP) \
        else f"{secrets.randbelow(10**6):06d}"
    db.add(m.OtpVerification(identifier=identifier, purpose=purpose, otp_hash=_hash(identifier, otp),
                             expires_at=now + timedelta(minutes=settings.OTP_EXPIRY_MINUTES)))
    db.flush()
    try:
        provider().send(identifier, otp, user)   # send first: if email fails, nothing is committed
    except Exception:
        db.rollback()
        raise
    db.commit()


def verify_otp(db: Session, identifier: str, otp: str, purpose: str) -> bool:
    rec = db.query(m.OtpVerification).filter_by(identifier=identifier, purpose=purpose, used=False)\
        .order_by(m.OtpVerification.id.desc()).first()
    if not rec or rec.expires_at < datetime.utcnow() or rec.attempts >= settings.OTP_MAX_ATTEMPTS:
        return False
    rec.attempts += 1
    ok = hmac.compare_digest(rec.otp_hash, _hash(identifier, otp))
    if ok:
        rec.used = True  # invalidate after success
    db.commit()
    return ok
