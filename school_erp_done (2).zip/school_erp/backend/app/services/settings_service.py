"""School settings stored in the database (editable by the admin on the Settings page). Per-school."""
from ..config import settings
from ..models import models as m

# Core settings shown on Settings page
KEYS = ("school_name", "address", "phone", "email", "low_attendance", "school_code")
# Extra keys allowed for storage (role matrix, feature flags, etc.)
EXTRA_KEYS = ("role_access",)


def defaults(school=None):
    d = {
        "school_name": (school.name if school else None) or settings.SCHOOL_NAME,
        "address": "",
        "phone": "",
        "email": "",
        "low_attendance": str(settings.LOW_ATTENDANCE),
        "school_code": school.code if school else "",
    }
    if school:
        parts = [p for p in (school.address, school.city, school.state, school.pincode) if p]
        d["address"] = ", ".join(parts) if parts else (school.address or "")
        d["phone"] = school.phone or ""
        d["email"] = school.email or ""
    return d


def _school_id(db, school_id=None):
    if school_id is not None:
        return school_id
    s = db.query(m.School).order_by(m.School.id).first()
    return s.id if s else 0


def get(db, key, default=None, school_id=None):
    """Read a single setting key for a school."""
    sid = _school_id(db, school_id)
    row = db.query(m.SchoolSetting).filter_by(school_id=sid, key=key).first()
    if row and row.value not in (None, ""):
        return row.value
    return default


def get_all(db, school_id=None):
    sid = _school_id(db, school_id)
    school = db.get(m.School, sid) if sid else None
    d = defaults(school)
    for r in db.query(m.SchoolSetting).filter_by(school_id=sid).all():
        if r.key in d and r.value not in (None, ""):
            d[r.key] = r.value
    return d


def set_many(db, values: dict, school_id=None):
    sid = _school_id(db, school_id)
    allowed = set(KEYS) | set(EXTRA_KEYS)
    for k, v in values.items():
        if k not in allowed:
            continue
        row = db.query(m.SchoolSetting).filter_by(school_id=sid, key=k).first()
        if row:
            row.value = str(v)
        else:
            db.add(m.SchoolSetting(school_id=sid, key=k, value=str(v)))
    school = db.get(m.School, sid) if sid else None
    if school:
        if "school_name" in values and values["school_name"]:
            school.name = str(values["school_name"])
        if "phone" in values:
            school.phone = str(values["phone"] or "")
        if "email" in values:
            school.email = str(values["email"] or "")
        if "school_code" in values and values["school_code"]:
            school.code = str(values["school_code"]).upper().strip()
        if "address" in values:
            school.address = str(values["address"] or "")
    db.commit()


def school_name(db, school_id=None):
    return get_all(db, school_id)["school_name"]


def low_threshold(db, school_id=None):
    try:
        return float(get_all(db, school_id)["low_attendance"])
    except (TypeError, ValueError):
        return settings.LOW_ATTENDANCE
