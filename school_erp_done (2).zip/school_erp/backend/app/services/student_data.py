"""Shared data readers used by the student, parent and AI layers (always take an already-authorised student)."""
from datetime import date
from ..models import models as m
from ..utils.helpers import grade_for, att_stats, ser


def profile(db, s):
    return {"name": s.user.name, "mobile": s.user.mobile, "email": s.user.email,
            "admission_no": s.admission_no, "roll_no": s.roll_no,
            "class": s.klass.name, "section": s.section.name if s.section else None,
            "dob": s.dob.isoformat() if s.dob else None, "gender": s.gender, "hostel": s.is_hostel,
            "parent": s.parent.user.name if s.parent else None,
            "address_line1": s.address_line1, "address_line2": s.address_line2,
            "city": s.city, "state": s.state, "pincode": s.pincode,
            "address": ", ".join(p for p in (s.address_line1, s.address_line2, s.city, s.state, s.pincode) if p)}


def attendance(db, s):
    recs = db.query(m.Attendance).filter_by(student_id=s.id, subject_id=None).order_by(m.Attendance.date.desc()).limit(60).all()
    return {**att_stats(db, s.id), "records": [ser(r, "date", "status") for r in recs]}


def subjects(db, s):
    return [{"subject": x.name} for x in db.query(m.Subject).filter_by(class_id=s.class_id).all()]


def homework(db, s):
    rows = db.query(m.Homework).filter(m.Homework.class_id == s.class_id).order_by(m.Homework.due_date.desc()).all()
    return [{**ser(h, "id", "title", "description", "due_date"), "subject": h.subject.name}
            for h in rows if h.section_id in (None, s.section_id)]


def assignments(db, s):
    out = []
    for a in db.query(m.Assignment).filter_by(class_id=s.class_id).order_by(m.Assignment.due_date.desc()).all():
        if a.section_id not in (None, s.section_id):
            continue
        sub = db.query(m.AssignmentSubmission).filter_by(assignment_id=a.id, student_id=s.id).first()
        out.append({**ser(a, "id", "title", "due_date", "max_marks"), "subject": a.subject.name,
                    "status": "Submitted" if sub else "Pending", "marks": sub.marks if sub else None,
                    "feedback": sub.feedback if sub else None})
    return out


def exams(db, s):
    rows = db.query(m.Exam).filter_by(class_id=s.class_id).order_by(m.Exam.exam_date).all()
    return [{**ser(e, "id", "name", "exam_date", "max_marks"), "subject": e.subject.name} for e in rows]


def results(db, s):
    rows = db.query(m.ExamResult).filter_by(student_id=s.id, published=True).all()
    return [{"exam": r.exam.name, "subject": r.exam.subject.name, "internal": r.internal_marks,
             "exam_marks": r.exam_marks, "total": r.total, "percentage": r.percentage, "grade": grade_for(r.percentage or 0),
             "result": "Pass" if r.passed else "Fail"} for r in rows]


def fees(db, s):
    out = []
    for f in db.query(m.Fee).filter_by(student_id=s.id).all():
        pays = db.query(m.FeePayment).filter_by(fee_id=f.id).all()
        paid = sum(p.amount for p in pays)
        out.append({**ser(f, "id", "fee_type", "amount", "due_date"), "paid": paid, "pending": f.amount - paid,
                    "history": ", ".join(f"{p.paid_on} ₹{p.amount:g}" for p in pays),
                    "last_payment_id": pays[-1].id if pays else None,
                    "payments": [{"id": p.id, "paid_on": str(p.paid_on), "amount": p.amount, "mode": p.mode} for p in pays]})
    return out


def timetable(db, s):
    rows = db.query(m.Timetable).filter(m.Timetable.class_id == s.class_id).order_by(m.Timetable.day, m.Timetable.start_time).all()
    return [{"day": t.day, "time": f"{t.start_time}-{t.end_time}", "subject": t.subject.name,
             "teacher": t.teacher.user.name if t.teacher else None, "room": t.room}
            for t in rows if t.section_id in (None, s.section_id)]


def materials(db, s):
    rows = db.query(m.StudyMaterial).filter_by(class_id=s.class_id).all()
    return [{"title": r.title, "subject": r.subject.name, "file": r.file_path, "id": r.id} for r in rows]


DATA = {"profile": profile, "attendance": attendance, "subjects": subjects, "homework": homework,
        "assignments": assignments, "exams": exams, "results": results, "fees": fees,
        "timetable": timetable, "materials": materials}


def subject_performance(db, s):
    d = {}
    for r in results(db, s):
        d.setdefault(r["subject"], []).append(r["percentage"])
    return {k: round(sum(v) / len(v), 1) for k, v in d.items()}


def chart_extras(db, s, fee_rows=None):
    """Small dicts the dashboards turn into charts."""
    a = att_stats(db, s.id)
    fee_rows = fees(db, s) if fee_rows is None else fee_rows
    return {"attendance_breakdown": {"Present": a["present"], "Absent": a["absent"], "Late": a["late"], "Leave": a["leave"]},
            "fee_status": {"Paid": round(sum(f["paid"] for f in fee_rows), 2), "Pending": round(sum(f["pending"] for f in fee_rows), 2)},
            "results_trend": {f"{r['exam']} - {r['subject']}": r["percentage"] for r in results(db, s)}}
