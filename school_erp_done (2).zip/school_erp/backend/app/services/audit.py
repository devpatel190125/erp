"""Audit log - who changed what.

Every successful POST / PUT / PATCH / DELETE on /api is recorded automatically by the middleware in main.py
(user, role, a readable description, time, IP). Request bodies are NOT stored, so passwords / OTPs never reach the log.
"""
import re
import logging
from ..database import SessionLocal
from ..models import models as m
from ..auth.security import decode_token

log = logging.getLogger("audit")
SKIP_PREFIXES = ("/auth/", "/ai/", "/notifications/read")      # logins are logged explicitly; chat is not an "edit"

# (method, regex on path, description).  \1 = first number in the path.
RULES = [
    ("POST", r"^/admin/students$", "Added a student"), ("PUT", r"^/admin/students/(\d+)$", "Edited student #\\1"),
    ("DELETE", r"^/admin/students/(\d+)$", "Deactivated student #\\1"),
    ("POST", r"^/admin/teachers$", "Added a teacher"), ("PUT", r"^/admin/teachers/(\d+)$", "Edited teacher #\\1"), ("DELETE", r"^/admin/teachers/(\d+)$", "Deactivated teacher #\\1"),
    ("POST", r"^/admin/wardens$", "Added a warden"), ("PUT", r"^/admin/wardens/(\d+)$", "Edited warden #\\1"), ("DELETE", r"^/admin/wardens/(\d+)$", "Deactivated warden #\\1"),
    ("PUT", r"^/admin/parents/(\d+)$", "Edited parent #\\1"),
    ("POST", r"^/admin/classes$", "Added a class"), ("PUT", r"^/admin/classes/(\d+)$", "Renamed class #\\1"), ("DELETE", r"^/admin/classes/(\d+)$", "Deleted class #\\1"),
    ("POST", r"^/admin/sections$", "Added a section"), ("PUT", r"^/admin/sections/(\d+)$", "Renamed section #\\1"), ("DELETE", r"^/admin/sections/(\d+)$", "Deleted section #\\1"),
    ("POST", r"^/admin/subjects$", "Added a subject"), ("PUT", r"^/admin/subjects/(\d+)$", "Renamed subject #\\1"), ("DELETE", r"^/admin/subjects/(\d+)$", "Deleted subject #\\1"),
    ("POST", r"^/admin/teacher-subjects$", "Assigned a teacher to a class"), ("DELETE", r"^/admin/teacher-subjects/(\d+)$", "Removed a teacher assignment"),
    ("POST", r"^/admin/users/(\d+)/activate$", "Re-activated user #\\1"), ("POST", r"^/admin/users/(\d+)/deactivate$", "Deactivated user #\\1"),
    ("POST", r"^/admin/promotion$", "Promoted / graduated students"), ("PUT", r"^/admin/settings$", "Changed school settings"),
    ("POST", r"^/admin/change-password$", "Changed the admin password"), ("POST", r"^/admin/complaints/(\d+)/resolve$", "Resolved complaint #\\1"),
    ("POST", r"^/fees$", "Added a fee"), ("PUT", r"^/fees/(\d+)$", "Edited fee #\\1"), ("DELETE", r"^/fees/(\d+)$", "Deleted fee #\\1"),
    ("POST", r"^/fees/payment$", "Recorded a fee payment"), ("DELETE", r"^/fees/payment/(\d+)$", "Deleted payment #\\1"), ("POST", r"^/fees/remind$", "Sent fee reminders"),
    ("POST", r"^/attendance/mark$", "Marked / corrected attendance"),
    ("POST", r"^/timetable$", "Added a timetable period"), ("PUT", r"^/timetable/(\d+)$", "Edited timetable period #\\1"), ("DELETE", r"^/timetable/(\d+)$", "Deleted timetable period #\\1"),
    ("POST", r"^/exams$", "Created an exam"), ("PUT", r"^/exams/(\d+)$", "Edited exam #\\1"), ("DELETE", r"^/exams/(\d+)$", "Deleted exam #\\1"),
    ("POST", r"^/exams/results$", "Entered exam marks"), ("POST", r"^/exams/(\d+)/publish$", "Published results of exam #\\1"),
    ("POST", r"^/notifications/notices$", "Posted a notice"), ("PUT", r"^/notifications/notices/(\d+)$", "Edited notice #\\1"), ("DELETE", r"^/notifications/notices/(\d+)$", "Deleted notice #\\1"),
    ("POST", r"^/notifications/events$", "Added an event"), ("PUT", r"^/notifications/events/(\d+)$", "Edited event #\\1"), ("DELETE", r"^/notifications/events/(\d+)$", "Deleted event #\\1"),
    ("POST", r"^/homework$", "Gave homework"), ("PUT", r"^/homework/(\d+)$", "Edited homework #\\1"), ("DELETE", r"^/homework/(\d+)$", "Deleted homework #\\1"),
    ("POST", r"^/assignments$", "Created an assignment"), ("PUT", r"^/assignments/(\d+)$", "Edited assignment #\\1"), ("DELETE", r"^/assignments/(\d+)$", "Deleted assignment #\\1"),
    ("POST", r"^/hostel/rooms$", "Added a hostel room"), ("PUT", r"^/hostel/rooms/(\d+)$", "Edited hostel room #\\1"), ("DELETE", r"^/hostel/rooms/(\d+)$", "Deleted hostel room #\\1"),
    ("POST", r"^/hostel/allocate$", "Allocated a hostel room"), ("POST", r"^/hostel/vacate$", "Vacated a hostel room"), ("POST", r"^/hostel/attendance$", "Marked hostel attendance"),
    ("POST", r"^/hostel/outpass$", "Created an outpass request"), ("POST", r"^/hostel/outpass/(\d+)/decide$", "Decided outpass #\\1"),
    ("POST", r"^/hostel/outpass/(\d+)/returned$", "Marked outpass #\\1 as returned"), ("PUT", r"^/hostel/mess/(\w+)$", "Updated the mess menu (\\1)"),
    ("POST", r"^/hostel/visitors$", "Logged a hostel visitor"), ("POST", r"^/hostel/visitors/(\d+)/checkout$", "Checked out visitor #\\1"),
    ("POST", r"^/hostel/complaints$", "Logged a hostel complaint"), ("POST", r"^/hostel/complaints/(\d+)/resolve$", "Resolved hostel complaint #\\1"),
    ("POST", r"^/files/materials$", "Uploaded study material"),
]
_COMPILED = [(mt, re.compile(rx), text) for mt, rx, text in RULES]


def describe(method: str, path: str) -> str:
    for mt, rx, text in _COMPILED:
        if mt == method:
            mo = rx.match(path)
            if mo:
                return rx.sub(text, path) if mo.groups() else text
    return f"{method} {path}"


def write(db, user, action, method="", path="", status=200, ip=None):
    db.add(m.AuditLog(user_id=getattr(user, "id", None), user_name=getattr(user, "name", None), role=getattr(user, "role", None),
                      action=action[:200], method=method, path=path[:200], status_code=status, ip=ip))


def record_request(request, status_code):
    """Called by the middleware after a successful write request. Never raises."""
    path = request.url.path[4:] if request.url.path.startswith("/api") else request.url.path
    if request.method not in ("POST", "PUT", "PATCH", "DELETE") or status_code >= 400 or path.startswith(SKIP_PREFIXES):
        return
    auth = request.headers.get("authorization", "")
    data = decode_token(auth[7:]) if auth.lower().startswith("bearer ") else None
    if not data:
        return
    db = SessionLocal()
    try:
        user = db.get(m.User, int(data["sub"]))
        write(db, user, describe(request.method, path), request.method, path, status_code, request.client.host if request.client else None)
        db.commit()
    except Exception:  # an audit problem must never break the real request
        log.exception("audit write failed")
        db.rollback()
    finally:
        db.close()
