from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    APP_ENV: str = "development"  # development | production
    DATABASE_URL: str = "mysql+pymysql://root:password@localhost:3306/school_erp"
    SECRET_KEY: str = "change-me"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_MINUTES: int = 480
    OTP_PROVIDER: str = "console"          # console | email | twilio
    DEV_FIXED_OTP: str = "123456"           # used ONLY when OTP_PROVIDER=console
    OTP_EXPIRY_MINUTES: int = 5
    OTP_MAX_ATTEMPTS: int = 5
    OTP_MAX_REQUESTS_PER_HOUR: int = 5
    OTP_RESEND_SECONDS: int = 30
    # Email OTP (OTP_PROVIDER=email). Gmail: smtp.gmail.com / 587 / use an "App password", not your login password
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = ""                     # defaults to SMTP_USER
    SCHOOL_NAME: str = "School ERP"
    TWILIO_SID: str = ""
    TWILIO_TOKEN: str = ""
    TWILIO_FROM: str = ""
    # AI assistant. AI_PROVIDER: gemini (free) | groq (free) | ollama (free, runs on your PC) | anthropic | openai
    AI_PROVIDER: str = ""                   # empty = anthropic if ANTHROPIC_API_KEY is set, otherwise offline rules
    AI_API_KEY: str = ""
    AI_BASE_URL: str = ""                   # only for custom OpenAI-compatible servers
    ANTHROPIC_API_KEY: str = ""
    AI_MODEL: str = ""                       # empty = sensible default for the provider
    UPLOAD_DIR: str = "uploads"
    MAX_UPLOAD_MB: int = 5
    PASS_PERCENT: float = 33.0
    LOW_ATTENDANCE: float = 75.0            # default; the admin can change it in Settings
    TZ_OFFSET_MINUTES: int = 330            # shown in audit log / receipts (330 = India, IST)
    CORS_ORIGINS: str = "*"


settings = Settings()

# Production hard checks
if settings.APP_ENV == "production":
    if settings.SECRET_KEY in ("change-me", "") or len(settings.SECRET_KEY) < 32:
        raise RuntimeError("Production requires a strong SECRET_KEY (32+ chars).")
    if settings.OTP_PROVIDER == "console" or settings.DEV_FIXED_OTP:
        raise RuntimeError("Production forbids console OTP / DEV_FIXED_OTP.")
    if settings.CORS_ORIGINS.strip() in ("*", ""):
        raise RuntimeError("Production requires explicit CORS_ORIGINS (not *).")

if settings.SECRET_KEY in ("change-me", "") or len(settings.SECRET_KEY) < 24:
    import warnings
    warnings.warn("SECRET_KEY is weak/default - set a long random value in .env (python -c \"import secrets;print(secrets.token_urlsafe(48))\")")
    if settings.OTP_PROVIDER != "console":
        raise RuntimeError("Refusing to start with a weak SECRET_KEY while real OTPs are enabled.")
