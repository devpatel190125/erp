from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from .config import settings
from .services import audit
from .database import Base, engine
from .models import models  # noqa: F401  (register tables)
from .routers import (auth, admin, students, teachers, parents, hostel, attendance, homework, assignments,
                      exams, fees, timetable, notifications, ai, files, manage, admin_tools, pdfs)

app = FastAPI(title="School ERP with AI", version="1.0.0")
origins = [o.strip() for o in settings.CORS_ORIGINS.split(",")]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=origins != ["*"],
                   allow_methods=["*"], allow_headers=["*"])

Base.metadata.create_all(bind=engine)

def _ensure_columns():
    """Add new columns on existing MySQL DBs without a full migration tool."""
    from sqlalchemy import text
    stmts = [
        "ALTER TABLE classes ADD COLUMN capacity INT DEFAULT 40",
        "ALTER TABLE classes ADD COLUMN class_teacher_id INT NULL",
        "ALTER TABLE fee_heads ADD COLUMN frequency VARCHAR(20) DEFAULT 'Monthly'",
        "ALTER TABLE fee_heads ADD COLUMN applicable_classes VARCHAR(255) DEFAULT ''",
        "ALTER TABLE teachers ADD COLUMN photo_path VARCHAR(255) NULL",
    ]
    with engine.connect() as conn:
        for s in stmts:
            try:
                conn.execute(text(s))
                conn.commit()
            except Exception:
                try:
                    conn.rollback()
                except Exception:
                    pass

try:
    _ensure_columns()
except Exception:
    pass

for r in (auth, admin, students, teachers, parents, hostel, attendance, homework, assignments, exams, fees,
          timetable, notifications, ai, files, manage, admin_tools, pdfs):
    app.include_router(r.router, prefix="/api")
app.include_router(admin_tools.public, prefix="/api")


@app.middleware("http")
async def audit_log(request, call_next):
    response = await call_next(request)
    if request.method != "GET" and request.url.path.startswith("/api/"):
        audit.record_request(request, response.status_code)      # who changed what (never raises)
    return response


@app.get("/api/health")
def health():
    from .config import settings as s
    out = {"status": "ok"}
    # Only reveal OTP mode outside production (local demo UX)
    if s.APP_ENV != "production":
        out["otp"] = s.OTP_PROVIDER
        out["env"] = s.APP_ENV
    return out


FRONTEND = Path(__file__).resolve().parents[2] / "frontend"
if FRONTEND.exists():
    app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
