from datetime import date
from typing import Optional, List
from pydantic import BaseModel, Field

MOB = r"^\d{10}$"
STATUS = "^(Present|Absent|Late|Leave)$"


class OtpReq(BaseModel):
    identifier: str = Field(min_length=5, max_length=120)
    role: str = Field(pattern="^(student|teacher|parent|warden)$")


class AdminLogin(BaseModel):
    identifier: str = Field(min_length=5, max_length=120)
    password: str = Field(min_length=1, max_length=128)


class VerifyReq(BaseModel):
    identifier: str
    otp: str = Field(pattern=r"^\d{6}$")
    role: str = Field(pattern="^(admin|student|teacher|parent|warden)$")


class SchoolRegister(BaseModel):
    school_name: str = Field(min_length=2, max_length=120)
    admin_name: str = Field(min_length=2, max_length=120)
    email: str = Field(min_length=5, max_length=120)
    mobile: str = Field(pattern=r"^\d{10}$")
    password: str = Field(min_length=8, max_length=72)
    address_line1: Optional[str] = Field(None, max_length=120)
    address_line2: Optional[str] = Field(None, max_length=120)
    city: Optional[str] = Field(None, max_length=80)
    state: Optional[str] = Field(None, max_length=80)
    pincode: Optional[str] = Field(None, max_length=12)
    phone: Optional[str] = Field(None, max_length=20)


class StudentIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    mobile: str = Field(pattern=MOB)
    email: Optional[str] = None
    admission_no: str = Field(min_length=1, max_length=30)
    roll_no: Optional[int] = None
    class_id: int
    section_id: Optional[int] = None
    dob: Optional[date] = None
    gender: Optional[str] = None
    is_hostel: bool = False
    parent_name: Optional[str] = None
    parent_mobile: Optional[str] = Field(default=None, pattern=MOB)
    address_line1: Optional[str] = Field(None, max_length=120)
    address_line2: Optional[str] = Field(None, max_length=120)
    city: Optional[str] = Field(None, max_length=80)
    state: Optional[str] = Field(None, max_length=80)
    pincode: Optional[str] = Field(None, max_length=12)


class StaffIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    mobile: str = Field(pattern=MOB)
    email: Optional[str] = None
    employee_no: Optional[str] = None
    hostel_id: Optional[int] = None
    qualification: Optional[str] = Field(None, max_length=120)
    experience: Optional[str] = Field(None, max_length=60)
    class_id: Optional[int] = None
    subject_ids: Optional[List[int]] = None


class NameIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    class_id: Optional[int] = None


class TeacherSubjectIn(BaseModel):
    teacher_id: int
    subject_id: int
    class_id: int
    section_id: Optional[int] = None


class AttRecord(BaseModel):
    student_id: int
    status: str = Field(pattern=STATUS)


class AttendanceIn(BaseModel):
    class_id: int
    section_id: Optional[int] = None
    date: date
    subject_id: Optional[int] = None
    records: List[AttRecord]


class WorkIn(BaseModel):
    class_id: int
    section_id: Optional[int] = None
    subject_id: int
    title: str = Field(min_length=2, max_length=150)
    description: Optional[str] = None
    due_date: Optional[date] = None
    max_marks: int = 10


class ExamIn(BaseModel):
    name: str
    exam_type: str = "exam"  # exam (whole class) | test (section-wise)
    class_id: int
    section_id: Optional[int] = None
    subject_id: int
    exam_date: Optional[date] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    internal_max: int = 20
    max_marks: int = 80


class MarksIn(BaseModel):
    exam_id: int
    student_id: int
    internal_marks: float = Field(ge=0)
    exam_marks: float = Field(ge=0)


class ReviewIn(BaseModel):
    marks: float = Field(ge=0)
    feedback: Optional[str] = None


class FeeIn(BaseModel):
    class_id: Optional[int] = None
    student_id: Optional[int] = None
    fee_type: str = Field(min_length=1, max_length=60)  # any custom head name
    amount: float = Field(gt=0)
    due_date: Optional[date] = None


class FeeHeadIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    default_amount: float = 0
    frequency: Optional[str] = "Monthly"
    applicable_classes: Optional[str] = ""  # comma-separated class names or ids


class ClassIn(BaseModel):
    name: str = Field(min_length=1, max_length=30)
    capacity: Optional[int] = 40
    class_teacher_id: Optional[int] = None


class PaymentIn(BaseModel):
    fee_id: int
    amount: float = Field(gt=0)
    mode: str = "Cash"


class TimetableIn(BaseModel):
    class_id: int
    section_id: Optional[int] = None
    subject_id: int
    teacher_id: Optional[int] = None
    room: Optional[str] = None
    day: str = Field(pattern="^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday)$")
    start_time: str = Field(pattern=r"^\d{2}:\d{2}$")
    end_time: str = Field(pattern=r"^\d{2}:\d{2}$")


class NoticeIn(BaseModel):
    title: str = Field(min_length=2, max_length=150)
    body: Optional[str] = None
    audience: str = Field(default="all", pattern="^(all|student|teacher|parent|warden)$")
    category: str = "general"


class EventIn(BaseModel):
    title: str
    description: Optional[str] = None
    event_date: Optional[date] = None


class ComplaintIn(BaseModel):
    subject: str = Field(min_length=2, max_length=150)
    description: Optional[str] = None


class RoomIn(BaseModel):
    room_no: str
    block: str = "A"
    floor: int = 1
    capacity: int = 2


class BlockIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    floors: int = Field(default=2, ge=1, le=20)


class AllocIn(BaseModel):
    student_id: int
    room_id: int
    bed_no: Optional[int] = None


class HostelAttIn(BaseModel):
    date: date
    records: List[AttRecord]


class VisitorIn(BaseModel):
    student_id: int
    visitor_name: str
    relation: Optional[str] = None
    purpose: Optional[str] = None


class HostelComplaintIn(BaseModel):
    description: str = Field(min_length=3)
    student_id: Optional[int] = None


class AIChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    conversation_id: Optional[int] = None


class DocumentIn(BaseModel):
    doc_type: str = Field(default="other", max_length=40)
    title: Optional[str] = Field(None, max_length=120)


class DocumentVerifyIn(BaseModel):
    status: str = Field(pattern="^(Verified|Rejected)$")
    remarks: Optional[str] = Field(None, max_length=250)
