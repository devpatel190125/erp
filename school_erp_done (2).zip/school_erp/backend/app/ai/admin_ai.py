from .textutil import has
from ..services.settings_service import low_threshold
import re
from datetime import date
from sqlalchemy import func
from ..models import models as m
from ..config import settings
from ..utils.helpers import att_stats, low_attendance, student_label
from ..services import student_data as sd


def at_risk_students(db):
    out = []
    for s in db.query(m.Student).join(m.User).filter(m.User.is_active == True):  # noqa
        a = att_stats(db, s.id)["percentage"]
        perf = sd.subject_performance(db, s)
        avg = sum(perf.values()) / len(perf) if perf else None
        reasons = []
        if a < low_threshold(db):
            reasons.append(f"attendance {a}%")
        if avg is not None and avg < 40:
            reasons.append(f"average marks {avg:.0f}%")
        if reasons:
            out.append({**student_label(s), "reasons": ", ".join(reasons)})
    return out


def context(db, user):
    today = date.today()
    absent = db.query(m.Attendance).filter_by(date=today, status="Absent", subject_id=None).count()
    return {"students": db.query(m.Student).count(), "absent_today": absent, "low_attendance": low_attendance(db)[:20],
            "pending_fees": db.query(func.coalesce(func.sum(m.Fee.amount), 0)).scalar() - db.query(func.coalesce(func.sum(m.FeePayment.amount), 0)).scalar()}


def analyze_attendance(db, threshold=75):
    rows = [x for x in low_attendance(db) if x["attendance"] < threshold]
    if not rows:
        return f"No students are below {threshold}% attendance."
    return f"{len(rows)} students below {threshold}%:\n" + "\n".join(
        f"- {x['name']} | Class {x['class']} | Section {x['section']} | {x['attendance']}%" for x in rows)


def generate_report(db):
    c = context(db, None)
    return (f"School report - {date.today():%d %b %Y}\n- Total students: {c['students']}\n- Absent today: {c['absent_today']}\n"
            f"- Students below {low_threshold(db):.0f}% attendance: {len(low_attendance(db))}\n"
            f"- Pending fees: ₹{c['pending_fees']:,.0f}\n- At-risk students: {len(at_risk_students(db))}")


def answer_erp_question(db, user, msg):
    t = msg.lower()
    if has(t, "below", "low attendance", "less than"):
        m_ = re.search(r"(\d+)\s*%?", t)
        return analyze_attendance(db, int(m_.group(1)) if m_ else 75)
    if has(t, "absent", "absentee"):
        rows = db.query(m.Attendance).filter_by(date=date.today(), status="Absent", subject_id=None).all()
        return f"{len(rows)} students are absent today." + ("\n" + "\n".join(f"- {db.get(m.Student, r.student_id).user.name}" for r in rows[:30]) if rows else "")
    if has(t, "risk", "at-risk", "weak students"):
        r = at_risk_students(db)
        return "At-risk students:\n" + "\n".join(f"- {x['name']} ({x['class']}-{x['section']}): {x['reasons']}" for x in r) if r else "No at-risk students found."
    if has(t, "fee", "pending fee", "dues"):
        return f"Total pending fees: ₹{context(db, user)['pending_fees']:,.0f}"
    if has(t, "report", "summary", "overview"):
        return generate_report(db)
    return "Try: 'Show students whose attendance is below 75%', 'How many students are absent today?', 'Which students are at risk?', 'Pending fees', 'Generate report'."


rule_based = answer_erp_question
