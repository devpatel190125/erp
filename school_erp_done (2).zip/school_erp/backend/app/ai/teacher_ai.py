from .textutil import has
import re
from ..utils.helpers import teacher_class_ids, low_attendance


def context(db, user):
    return {"low_attendance_in_my_classes": low_attendance(db, teacher_class_ids(db, user))}


def analyze_attendance(db, user):
    low = low_attendance(db, teacher_class_ids(db, user))
    if not low:
        return "All students in your classes have attendance of 75% or more."
    return "Students below 75% in your classes:\n" + "\n".join(
        f"- {x['name']} ({x['class']}-{x['section']}): {x['attendance']}%" for x in low)


def generate_questions(topic, n=10, kind="MCQ"):
    """Offline template. With ANTHROPIC_API_KEY set the LLM produces real questions instead."""
    lines = [f"[Offline template] {n} {kind} skeletons on '{topic}' - set ANTHROPIC_API_KEY for AI-written questions.\n"]
    for i in range(1, n + 1):
        lvl = "Easy" if i <= n // 3 else "Medium" if i <= 2 * n // 3 else "Hard"
        lines.append(f"Q{i}. [{lvl}] Question about {topic}\n   A) ...  B) ...  C) ...  D) ...\n   Correct: __")
    return "\n".join(lines)


def generate_homework(topic, cls=""):
    return (f"Homework - {cls} {topic}\n1. Read the chapter on {topic} and write 5 key points.\n"
            f"2. Solve 5 textbook questions on {topic}.\n3. Draw a labelled diagram / write a short example.\n"
            "4. Write 2 doubts to ask in class.")


def generate_lesson_plan(topic, cls=""):
    return (f"Lesson plan - {cls} {topic} (40 min)\n- Objective: students understand the core idea of {topic}\n"
            "- Warm-up (5 min): recall question\n- Explanation (15 min): concept + example\n- Activity (10 min): pair practice\n"
            "- Assessment (5 min): 3 quick questions\n- Homework (5 min): assign practice")


def rule_based(db, user, msg):
    t = msg.lower()
    n = re.search(r"(\d+)", t)
    n = int(n.group(1)) if n else 10
    topic = re.search(r"(?:class\s*\d+\s*)?([a-z ]*(?:science|math\w*|english|hindi|social\w*|history|geography))", t)
    topic = topic.group(0).strip() if topic else "the chapter"
    if has(t, "attendance"):
        return analyze_attendance(db, user)
    if has(t, "mcq", "quiz", "question", "test paper"):
        return generate_questions(topic, min(n, 30))
    if has(t, "lesson", "lesson plan"):
        return generate_lesson_plan(topic)
    if has(t, "homework"):
        return generate_homework(topic)
    return "I can generate MCQ/quiz skeletons, homework, lesson plans and analyse your class attendance. Add an ANTHROPIC_API_KEY for full AI content."
