import re
from .textutil import has
from datetime import date
from ..services import student_data as sd
from ..utils.helpers import student_of, att_stats


def context(db, user):
    s = student_of(db, user)
    return {"name": user.name, "class": s.klass.name, "attendance": att_stats(db, s.id),
            "subject_performance": sd.subject_performance(db, s), "upcoming_exams": sd.exams(db, s),
            "pending_assignments": [a for a in sd.assignments(db, s) if a["status"] == "Pending"]}


def analyze_student_performance(db, s):
    perf = sd.subject_performance(db, s)
    a = att_stats(db, s.id)
    if not perf:
        return f"No published results yet. Attendance is {a['percentage']}%."
    weak = sorted(perf.items(), key=lambda x: x[1])
    lines = [f"Attendance: {a['percentage']}%", "Subject averages:"] + [f"- {k}: {v}%" for k, v in weak]
    lines.append(f"Weakest subject: {weak[0][0]} ({weak[0][1]}%). Strongest: {weak[-1][0]} ({weak[-1][1]}%).")
    if a["percentage"] < 75:
        lines.append("Your attendance is below 75% - try not to miss more classes.")
    return "\n".join(lines)


def generate_study_plan(db, s, days=7):
    perf = sd.subject_performance(db, s)
    subs = [x["subject"] for x in sd.subjects(db, s)]
    subs.sort(key=lambda x: perf.get(x, 50))  # weakest first
    upcoming = [e for e in sd.exams(db, s) if e["exam_date"] and e["exam_date"] >= date.today().isoformat()]
    days = max(1, min(days, 30))
    plan = [f"Study plan for {days} day(s) (weak subjects get more time):"]
    for d in range(1, days + 1):
        if d == days:
            plan.append(f"Day {d}: Quick revision of all subjects, formulas/key points, sleep early.")
            continue
        main, second = subs[(d - 1) % len(subs)], subs[(d) % len(subs)]
        plan.append(f"Day {d}: {main} (1.5 hr concepts + practice), {second} (45 min revision), 30 min homework/assignment.")
    if upcoming:
        plan.append("Upcoming exams: " + ", ".join(f"{e['subject']} on {e['exam_date']}" for e in upcoming[:5]))
    return "\n".join(plan)


def rule_based(db, user, msg):
    s = student_of(db, user)
    t = msg.lower()
    if has(t, "plan", "study plan", "schedule", "routine"):
        m_ = re.search(r"(\d+)\s*day", t)
        return generate_study_plan(db, s, int(m_.group(1)) if m_ else 7)
    if has(t, "attendance", "present", "absent"):
        a = att_stats(db, s.id)
        return f"Your attendance is {a['percentage']}% ({a['present']} present, {a['absent']} absent, {a['late']} late)."
    if has(t, "weak", "performance", "result", "marks", "progress", "grade", "score"):
        return analyze_student_performance(db, s)
    if has(t, "homework", "assignment", "pending"):
        p = context(db, user)["pending_assignments"]
        return "Pending assignments:\n" + "\n".join(f"- {a['title']} ({a['subject']}), due {a['due_date']}" for a in p) if p else "No pending assignments."
    return ("I'm in offline mode, so I can create study plans, show attendance, pending work and analyse your performance. "
            "For subject doubts and homework help, ask your admin to add an ANTHROPIC_API_KEY to enable the full AI tutor.")
