import re


def has(text: str, *words: str) -> bool:
    """Whole-word match (plural / -ing / -ed allowed). 'plan' matches 'plans' but NOT 'explain';
    'fee' matches 'fees' but NOT 'feel' or 'feedback'; 'room' does NOT match 'classroom'."""
    t = text.lower()
    return any(re.search(r"\b" + re.escape(w) + r"(s|es|ing|ed)?\b", t) for w in words)
