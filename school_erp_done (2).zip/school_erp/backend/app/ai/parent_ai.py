from .textutil import has
from ..services import student_data as sd
from ..utils.helpers import parent_children, att_stats


def context(db, user):
    return [{"child": s.user.name, "class": s.klass.name, "attendance": att_stats(db, s.id),
             "subject_performance": sd.subject_performance(db, s),
             "pending_assignments": sum(1 for a in sd.assignments(db, s) if a["status"] == "Pending"),
             "pending_fees": sum(f["pending"] for f in sd.fees(db, s))} for s in parent_children(db, user)]


def generate_parent_summary(db, user):
    ctx = context(db, user)
    if not ctx:
        return "No child is linked to your account."
    out = []
    for c in ctx:
        perf = c["subject_performance"]
        lines = [f"Summary for {c['child']} ({c['class']}):", f"- Attendance: {c['attendance']['percentage']}%",
                 f"- Pending assignments: {c['pending_assignments']}"]
        if perf:
            w = sorted(perf.items(), key=lambda x: x[1])
            lines.append(f"- Average marks by subject: " + ", ".join(f"{k} {v}%" for k, v in w))
            need = [k for k, v in w if v < 50]
            lines.append("- Needs attention: " + (", ".join(need) if need else "none - doing well"))
        else:
            lines.append("- No published results yet.")
        if c["attendance"]["percentage"] < 75:
            lines.append("- Attendance is below 75% - please ensure regular attendance.")
        if c["pending_fees"] > 0:
            lines.append(f"- Pending fees: ₹{c['pending_fees']:g}")
        out.append("\n".join(lines))
    return "\n\n".join(out)


def rule_based(db, user, msg):
    t = msg.lower()
    ctx = context(db, user)
    if has(t, "attendance", "absent", "present"):
        return "\n".join(f"{c['child']}: {c['attendance']['percentage']}% ({c['attendance']['absent']} absent days)" for c in ctx) or "No child linked."
    if has(t, "fee", "dues", "pending"):
        return "\n".join(f"{c['child']}: pending ₹{c['pending_fees']:g}" for c in ctx)
    return generate_parent_summary(db, user)
