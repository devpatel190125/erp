import json, logging, time
import httpx
from ..config import settings
from ..models import models as m
from . import admin_ai, student_ai, teacher_ai, parent_ai, hostel_ai

log = logging.getLogger("ai")
MODULES = {"admin": admin_ai, "student": student_ai, "teacher": teacher_ai, "parent": parent_ai, "warden": hostel_ai}

# Free options: gemini (Google AI Studio key, no card), groq (free key), ollama (runs on your own PC, no key, private).
PRESETS = {
    "anthropic": {"label": "Claude", "model": "claude-sonnet-4-6"},
    "gemini": {"label": "Gemini", "base": "https://generativelanguage.googleapis.com/v1beta/openai", "model": "gemini-flash-latest"},
    "groq": {"label": "Groq (Llama)", "base": "https://api.groq.com/openai/v1", "model": "llama-3.3-70b-versatile"},
    "ollama": {"label": "Ollama (local)", "base": "http://localhost:11434/v1", "model": "llama3.2", "nokey": True, "timeout": 180},
    "openai": {"label": "OpenAI-compatible", "base": "https://api.openai.com/v1", "model": "gpt-4o-mini"},
}


def active():
    """Which AI is configured right now (None = offline rules). Read on every call so .env edits + restart just work."""
    prov = (settings.AI_PROVIDER or "").strip().lower() or ("anthropic" if settings.ANTHROPIC_API_KEY else "")
    if not prov:
        return None
    p = PRESETS.get(prov, PRESETS["openai"])
    key = settings.AI_API_KEY or (settings.ANTHROPIC_API_KEY if prov == "anthropic" else "")
    if not key and not p.get("nokey"):
        return None
    model = (settings.AI_MODEL or "").strip()
    if not model or (prov != "anthropic" and model.lower().startswith("claude")):   # old Claude name left in .env
        model = p["model"]
    return {"provider": prov, "key": key or "none", "model": model, "label": p["label"],
            "base": settings.AI_BASE_URL or p.get("base", ""), "timeout": p.get("timeout", 45)}


# Friendly explanations for the usual failures (shown to the user + logged on the server).
ERRORS = {
    401: "The AI API key is invalid. Check AI_API_KEY in backend/.env (no spaces or quotes).",
    403: "The API key has no permission for this model or region (check AI_PROVIDER, AI_MODEL).",
    404: "The AI model name is wrong. Check AI_MODEL in backend/.env (or delete the line to use the default).",
    500: "The AI service had a temporary problem. I retried automatically - please ask again in a minute.",
    502: "The AI service had a temporary problem. I retried automatically - please ask again in a minute.",
    503: "The AI service is overloaded right now (Google/OpenAI side, usually temporary). I retried automatically - ask again in a minute.",
    504: "The AI service timed out. I retried automatically - please ask again in a minute.",
    429: "Free quota / rate limit reached. Wait a minute and try again (free plans allow only a few questions per minute).",
    529: "The AI service is overloaded right now. Try again in a minute.",
}


def api_detail(resp):
    """The real reason Anthropic gives (e.g. 'credit balance is too low') - this used to be thrown away."""
    try:
        j = resp.json()
        j = j[0] if isinstance(j, list) and j else j
        e = j.get("error", {})
        return str(e.get("message", "") if isinstance(e, dict) else e).strip()
    except Exception:
        return (resp.text or "")[:200]


def explain_error(code, detail):
    d = detail.lower()
    if "credit balance" in d:
        return "Your Anthropic account has no API credit. Add credit at console.anthropic.com -> Billing, or switch to a free provider (AI_PROVIDER=gemini)."
    if "model" in d and code in (400, 404):
        return f"The AI model name looks wrong. Check AI_MODEL in backend/.env. ({detail[:150]})"
    if code in ERRORS:
        return ERRORS[code]
    return f"The AI service rejected the request ({code}): {detail[:200]}" if detail else f"The AI service returned an error ({code})."


def status():
    a = active()
    return {"mode": "online" if a else "offline", "label": a["label"] if a else None, "model": a["model"] if a else None,
            "note": None if a else "Offline mode: simple rule-based answers only. Set AI_PROVIDER and AI_API_KEY in backend/.env "
                                   "(free options: gemini, groq, ollama)."}


def clean_history(history):
    """The Anthropic API needs alternating roles that start with 'user'. Fix whatever the DB gave us."""
    out = []
    for h in history:
        if not h["content"]:
            continue
        if out and out[-1]["role"] == h["role"]:
            out[-1]["content"] += "\n" + h["content"]
        else:
            out.append(dict(h))
    while out and out[0]["role"] != "user":
        out.pop(0)
    return out


def build_system(role, ctx):
    data = json.dumps(ctx, default=str, separators=(",", ":"))
    if len(data) > 12000:
        data = data[:12000] + '..."(data truncated)"'
    return (f"You are the AI assistant inside a school ERP. The user is a {role}. Use ONLY the JSON data below for "
            "facts about people, marks, attendance and fees; you may use general school knowledge for explanations "
            "and study help. Never reveal data about other students, parents or teachers. If the data does not "
            "contain the answer, say so instead of guessing. Reply in the same language the user writes in "
            "(English, Hindi or Gujarati). Be concise, friendly and age-appropriate. Plain text, short lists are fine.\n"
            "DATA:\n" + data)


def call_llm(a, role, ctx, history, msg):
    system = build_system(role, ctx)
    msgs = clean_history(history) + [{"role": "user", "content": msg}]
    if a["provider"] == "anthropic":
        r = httpx.post("https://api.anthropic.com/v1/messages",
                       headers={"x-api-key": a["key"], "anthropic-version": "2023-06-01", "content-type": "application/json"},
                       json={"model": a["model"], "max_tokens": 1000, "system": system, "messages": msgs}, timeout=a["timeout"])
        r.raise_for_status()
        return "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text").strip() or None
    # Gemini / Groq / Ollama / any OpenAI-compatible server share one wire format
    r = httpx.post(a["base"].rstrip("/") + "/chat/completions",
                   headers={"Authorization": "Bearer " + a["key"], "Content-Type": "application/json"},
                   json={"model": a["model"], "max_tokens": 1000, "messages": [{"role": "system", "content": system}] + msgs},
                   timeout=a["timeout"])
    r.raise_for_status()
    ch = (r.json().get("choices") or [{}])[0].get("message", {})
    return (ch.get("content") or "").strip() or None


RETRY_CODES = {500, 502, 503, 504, 529}
FALLBACK_MODEL = {"gemini": "gemini-flash-lite-latest"}     # lighter model, usually less busy


def call_with_retry(a, role, ctx, history, msg):
    """Busy servers (503) are normal on free tiers: retry twice with a short pause, then try the lighter model."""
    models = [a["model"]]
    fb = FALLBACK_MODEL.get(a["provider"])
    if fb and fb != a["model"]:
        models.append(fb)
    last = None
    for model in models:
        for attempt in range(3):
            try:
                return call_llm({**a, "model": model}, role, ctx, history, msg)
            except httpx.HTTPStatusError as e:
                if e.response.status_code not in RETRY_CODES:
                    raise
                last = e
                log.warning("AI %s busy (%s) model=%s attempt=%s", a["provider"], e.response.status_code, model, attempt + 1)
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
    raise last


def chat(db, user, message, conv_id=None):
    """The model/rule engine only ever receives context built for THIS logged-in user."""
    conv = db.get(m.AIConversation, conv_id) if conv_id else None
    if conv and conv.user_id != user.id:
        conv = None
    if not conv:
        conv = m.AIConversation(user_id=user.id)
        db.add(conv)
        db.flush()
    mod = MODULES[user.role]
    prev = db.query(m.AIMessage).filter_by(conversation_id=conv.id).order_by(m.AIMessage.id.desc()).limit(8).all()[::-1]
    history = [{"role": "user" if p.sender == "user" else "assistant", "content": p.content} for p in prev]
    reply, mode, note, a = None, "offline", None, active()
    if a:
        try:
            reply = call_with_retry(a, user.role, mod.context(db, user), history, message)
            mode = "online" if reply else "offline"
        except httpx.HTTPStatusError as e:   # was silently swallowed before - now logged and explained
            code, detail = e.response.status_code, api_detail(e.response)
            log.error("AI API error (%s) %s: %s", a["provider"], code, detail or e.response.text[:300])
            note = explain_error(code, detail)
        except httpx.HTTPError as e:
            log.error("AI API unreachable (%s): %s", a["provider"], e)
            note = ("Could not reach Ollama. Is it running (ollama serve) and the model pulled?" if a["provider"] == "ollama"
                    else "Could not reach the AI service (check the server's internet connection).")
        except Exception:
            log.exception("AI failure")
            note = "The AI failed unexpectedly - answered in offline mode."
    else:
        note = "Offline mode (no AI provider configured)."
    if reply is None:
        reply = mod.rule_based(db, user, message)
    db.add(m.AIMessage(conversation_id=conv.id, sender="user", content=message))
    db.add(m.AIMessage(conversation_id=conv.id, sender="assistant", content=reply))
    db.commit()
    return {"reply": reply, "conversation_id": conv.id, "mode": mode, "label": a["label"] if (a and mode == "online") else None, "note": note}
