from .textutil import has
from datetime import date
from ..models import models as m

CATS = {"Maintenance": ["fan", "light", "bulb", "water", "tap", "leak", "door", "window", "bed", "broken", "electric", "wifi", "plumb"],
        "Food": ["food", "mess", "meal", "breakfast", "dinner", "lunch", "hygiene", "stale"],
        "Safety": ["fight", "bully", "ragging", "theft", "stolen", "fire", "smoke", "injury", "unsafe", "harass", "threat"],
        "Health": ["sick", "fever", "ill", "vomit", "medicine", "doctor", "pain"],
        "Cleanliness": ["dirty", "clean", "toilet", "bathroom", "garbage", "smell", "pest", "insect"]}
HIGH = ["fire", "fight", "bully", "ragging", "theft", "stolen", "injury", "harass", "threat", "smoke", "fever", "vomit", "unsafe", "emergency"]
MED = ["leak", "broken", "not working", "no water", "sick", "stale", "electric"]


def analyze_hostel_complaint(text):
    t = text.lower()
    cat = next((c for c, ws in CATS.items() if any(w in t for w in ws)), "General")
    pri = "High" if any(w in t for w in HIGH) else "Medium" if any(w in t for w in MED) else "Low"
    return cat, pri


def context(db, user):
    rooms = db.query(m.HostelRoom).all()
    free = {r.room_no: r.capacity - db.query(m.HostelAllocation).filter_by(room_id=r.id).count() for r in rooms}
    return {"rooms_total": len(rooms), "available_rooms": {k: v for k, v in free.items() if v > 0},
            "open_complaints": [{"text": c.description, "category": c.category, "priority": c.priority}
                                for c in db.query(m.HostelComplaint).filter(m.HostelComplaint.status != "Resolved")]}


def suggest_room(db):
    best = None
    for r in db.query(m.HostelRoom):
        free = r.capacity - db.query(m.HostelAllocation).filter_by(room_id=r.id).count()
        if free > 0 and (best is None or free < best[1]):
            best = (r.room_no, free)  # fill partially-occupied rooms first
    return best


def rule_based(db, user, msg):
    t = msg.lower()
    c = context(db, user)
    if has(t, "room", "available", "occupancy", "vacant", "bed"):
        occ = db.query(m.HostelAllocation).count()
        cap = sum(r.capacity for r in db.query(m.HostelRoom))
        s = suggest_room(db)
        lines = [f"Occupancy: {occ}/{cap} beds ({round(occ / cap * 100) if cap else 0}%).", "Available rooms:"]
        lines += [f"- Room {k}: {v} bed(s) free" for k, v in c["available_rooms"].items()] or ["- none"]
        if s:
            lines.append(f"Allocation suggestion: Room {s[0]} (fills a partly-used room first).")
        return "\n".join(lines)
    if has(t, "absent", "attendance"):
        ab = db.query(m.HostelAttendance).filter_by(date=date.today(), status="Absent").all()
        if not ab:
            return "No hostel students are marked absent today (or attendance is not marked yet)."
        return "Absent hostel students today:\n" + "\n".join(f"- {a_.student_id and db.get(m.Student, a_.student_id).user.name}" for a_ in ab)
    if has(t, "complaint"):
        cs = c["open_complaints"]
        if not cs:
            return "There are no open hostel complaints."
        by = {}
        for x in cs:
            by.setdefault(x["category"], []).append(x["priority"])
        return f"{len(cs)} open complaints.\n" + "\n".join(f"- {k}: {len(v)} ({v.count('High')} high priority)" for k, v in by.items())
    return "I can help with: available rooms, hostel attendance, absent students, and complaint summaries."
