"""Set / change the email of any user (OTP emails are sent to this address).

    python set_email.py 9000000001 yourname@gmail.com
    python set_email.py 9100000001 student@gmail.com

Normal users can be edited from the admin screens (Edit button). This script is mainly for the
admin account, which has no edit screen.
"""
import sys
from app.database import SessionLocal
from app.models import models as m

if len(sys.argv) != 3 or "@" not in sys.argv[2]:
    sys.exit("Usage: python set_email.py <mobile> <email>")
db = SessionLocal()
u = db.query(m.User).filter_by(mobile=sys.argv[1]).first()
if not u:
    sys.exit(f"No user with mobile {sys.argv[1]}")
if db.query(m.User).filter(m.User.email == sys.argv[2], m.User.id != u.id).first():
    sys.exit("That email is already used by another account")
u.email = sys.argv[2]
db.commit()
print(f"OK: {u.name} ({u.role}) -> {u.email}.  Log in with mobile {u.mobile}; the OTP will be emailed to this address.")
