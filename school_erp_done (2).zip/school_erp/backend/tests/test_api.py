import os
os.environ.update(DATABASE_URL="sqlite:///./test_erp.db", OTP_RESEND_SECONDS="0", OTP_MAX_REQUESTS_PER_HOUR="100")
if os.path.exists("test_erp.db"):
    os.remove("test_erp.db")
from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402
import seed  # noqa: E402

seed.run()
c = TestClient(app)


def login(role, ident, pw=None):
    if role == "admin":
        assert c.post("/api/auth/admin/login", json={"identifier": ident, "password": pw}).status_code == 200
    else:
        assert c.post("/api/auth/request-otp", json={"identifier": ident, "role": role}).status_code == 200
    r = c.post("/api/auth/verify-otp", json={"identifier": ident, "otp": "123456", "role": role})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["access_token"]}


def test_admin_needs_password_and_otp():
    assert c.post("/api/auth/admin/login", json={"identifier": "admin@school.com", "password": "bad"}).status_code == 401
    assert c.post("/api/auth/verify-otp", json={"identifier": "admin@school.com", "otp": "123456", "role": "admin"}).status_code == 401
    h = login("admin", "admin@school.com", "Admin@123")
    assert c.get("/api/admin/dashboard", headers=h).json()["total_students"] == 12


def test_otp_single_use_and_wrong_otp():
    c.post("/api/auth/request-otp", json={"identifier": "9100000001", "role": "student"})
    assert c.post("/api/auth/verify-otp", json={"identifier": "9100000001", "otp": "000000", "role": "student"}).status_code == 401
    assert c.post("/api/auth/verify-otp", json={"identifier": "9100000001", "otp": "123456", "role": "student"}).status_code == 200
    assert c.post("/api/auth/verify-otp", json={"identifier": "9100000001", "otp": "123456", "role": "student"}).status_code == 401


def test_rbac_and_isolation():
    st = login("student", "9100000001")
    assert c.get("/api/admin/students", headers=st).status_code == 403
    assert c.get("/api/students/me/attendance", headers=st).status_code == 200
    assert c.get("/api/attendance/student/2", headers=st).status_code == 403   # another student
    par = login("parent", "9200000001")
    assert c.get("/api/attendance/student/2", headers=par).status_code == 403   # not their child
    assert c.get("/api/parents/child/results", headers=par).status_code == 200
    assert c.get("/api/students/me/fees").status_code == 401


def test_teacher_attendance_and_marks():
    t = login("teacher", "9000000011")
    kids = c.get("/api/teachers/students", headers=t).json()
    assert len(kids) == 12
    cl = c.get("/api/teachers/me/classes", headers=t).json()[0]
    recs = [{"student_id": k["student_id"], "status": "Absent"} for k in kids if k["section"] == "A"]
    r = c.post("/api/attendance/mark", headers=t, json={"class_id": cl["class_id"], "section_id": cl["section_id"], "date": "2026-01-05", "records": recs})
    assert r.status_code == 200, r.text
    ex = c.get("/api/exams", headers=t).json()[0]
    r = c.post("/api/exams/results", headers=t, json={"exam_id": ex["id"], "student_id": kids[0]["student_id"], "internal_marks": 15, "exam_marks": 60})
    assert r.json()["grade"] == "B"
    assert c.post("/api/exams/results", headers=t, json={"exam_id": ex["id"], "student_id": kids[0]["student_id"], "internal_marks": 99, "exam_marks": 1}).status_code == 400


def test_ai_role_scoped():
    a = login("admin", "admin@school.com", "Admin@123")
    r = c.post("/api/ai/chat", headers=a, json={"message": "Show students whose attendance is below 75%"}).json()
    assert "below 75" in r["reply"]
    s = login("student", "9100000001")
    r = c.post("/api/ai/chat", headers=s, json={"message": "I have an exam in 7 days. Create a study plan."}).json()
    assert "Day 1" in r["reply"]


def test_hostel_and_dashboards():
    w = login("warden", "9300000001")
    assert c.get("/api/hostel/dashboard", headers=w).json()["total_students"] == 4
    r = c.post("/api/hostel/complaints", headers=w, json={"description": "There was a fight in the corridor"}).json()
    assert r["priority"] == "High"
    assert c.get("/api/teachers/dashboard", headers=login("teacher", "9000000011")).status_code == 200
    assert c.get("/api/parents/dashboard", headers=login("parent", "9200000001")).status_code == 200
    assert c.get("/api/students/me/dashboard", headers=login("student", "9100000001")).status_code == 200
