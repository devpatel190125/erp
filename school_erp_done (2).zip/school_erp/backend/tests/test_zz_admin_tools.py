from datetime import date, timedelta
from test_api import c, login
from app.database import SessionLocal
from app.models import models as m

ADMIN = lambda: login("admin", "admin@school.com", "Admin@123")  # noqa: E731
STUDENT = lambda: login("student", "9100000001")  # noqa: E731  (a hostel student in the seed data)
WARDEN = lambda: login("warden", "9300000001")  # noqa: E731


def test_search_finds_people():
    h = ADMIN()
    r = c.get("/api/admin/search?q=Aarav", headers=h).json()
    assert any(x["type"] == "Student" and x["url"].startswith("student.html?id=") for x in r)
    assert c.get("/api/admin/search?q=a", headers=h).status_code == 422          # too short
    assert c.get("/api/admin/search?q=Aarav", headers=STUDENT()).status_code == 403
    mob = c.get("/api/admin/teachers", headers=h).json()[0]["mobile"]
    assert any(x["type"] == "Teacher" for x in c.get(f"/api/admin/search?q={mob}", headers=h).json())


def test_student_profile_has_everything():
    h = ADMIN()
    sid = next(x["id"] for x in c.get("/api/admin/students", headers=h).json() if x["name"].startswith("Aarav"))
    p = c.get(f"/api/admin/students/{sid}/profile", headers=h).json()
    for k in ("details", "attendance", "attendance_breakdown", "attendance_monthly", "average", "subject_performance", "results", "fees",
              "payments", "fee_status", "pending_fees", "hostel"):
        assert k in p, k
    assert p["details"]["name"].startswith("Aarav") and p["hostel"]["room"]
    assert c.get("/api/admin/students/999999/profile", headers=h).status_code == 404


def test_users_activate_deactivate():
    h = ADMIN()
    c.post("/api/admin/teachers", headers=h, json={"name": "Temp Access", "mobile": "9555500088"})
    u = next(x for x in c.get("/api/admin/users?role=teacher", headers=h).json() if x["mobile"] == "9555500088")
    assert u["status"] == "Active"
    assert c.post(f"/api/admin/users/{u['id']}/deactivate", headers=h).status_code == 200
    assert next(x for x in c.get("/api/admin/users", headers=h).json() if x["id"] == u["id"])["status"] == "Inactive"
    # an inactive user can no longer log in
    c.post("/api/auth/request-otp", json={"identifier": "9555500088", "role": "teacher"})
    assert c.post("/api/auth/verify-otp", json={"identifier": "9555500088", "otp": "123456", "role": "teacher"}).status_code == 401
    assert c.post(f"/api/admin/users/{u['id']}/activate", headers=h).status_code == 200
    login("teacher", "9555500088")
    admin_row = next(x for x in c.get("/api/admin/users", headers=h).json() if x["role"] == "admin")
    assert c.post(f"/api/admin/users/{admin_row['id']}/deactivate", headers=h).status_code == 400


def test_promotion_and_graduation():
    h = ADMIN()
    classes = {x["name"]: x["id"] for x in c.get("/api/admin/classes", headers=h).json()}
    c.post("/api/admin/classes", headers=h, json={"name": "Class 20"})
    c.post("/api/admin/classes", headers=h, json={"name": "Class 21"})
    classes = {x["name"]: x["id"] for x in c.get("/api/admin/classes", headers=h).json()}
    for n in ("Class 20", "Class 21"):
        c.post("/api/admin/sections", headers=h, json={"class_id": classes[n], "name": "A"})
    ids = []
    for i in range(3):
        r = c.post("/api/admin/students", headers=h, json={"name": f"Promo {i}", "mobile": f"955550010{i}", "admission_no": f"PR-{i}", "class_id": classes["Class 20"]})
        assert r.status_code == 200, r.text
        ids.append(r.json()["id"])
    pv = c.get(f"/api/admin/promotion/preview?class_id={classes['Class 20']}", headers=h).json()
    assert len(pv["students"]) == 3 and pv["next_class_id"] == classes["Class 21"]
    # wrong students / same class are rejected
    assert c.post("/api/admin/promotion", headers=h, json={"from_class_id": classes["Class 20"], "to_class_id": classes["Class 21"], "student_ids": [1]}).status_code == 400
    assert c.post("/api/admin/promotion", headers=h, json={"from_class_id": classes["Class 20"], "to_class_id": classes["Class 20"], "student_ids": ids}).status_code == 400
    r = c.post("/api/admin/promotion", headers=h, json={"from_class_id": classes["Class 20"], "to_class_id": classes["Class 21"], "student_ids": ids[:2], "academic_year": "2031-32"})
    assert r.status_code == 200 and "2 students promoted" in r.json()["message"], r.text
    db = SessionLocal()
    assert db.get(m.Student, ids[0]).class_id == classes["Class 21"] and db.get(m.Student, ids[2]).class_id == classes["Class 20"]
    ay = db.query(m.AcademicYear).filter_by(is_current=True).all()
    assert len(ay) == 1 and ay[0].name == "2031-32"                                   # new year created and made current
    assert db.query(m.StudentClass).filter_by(student_id=ids[0], academic_year_id=ay[0].id).count() == 1
    db.close()
    # graduation = deactivate, history kept
    r = c.post("/api/admin/promotion", headers=h, json={"from_class_id": classes["Class 21"], "to_class_id": None, "student_ids": ids[:2]})
    assert r.status_code == 200 and "graduated" in r.json()["message"]
    assert not any(x["name"] == "Promo 0" for x in c.get("/api/admin/students", headers=h).json())


def test_settings_and_password():
    h = ADMIN()
    assert c.get("/api/settings/public").json()["school_name"]                       # no login needed
    assert c.put("/api/admin/settings", headers=h, json={"school_name": "Shree Demo School", "phone": "0261-123", "low_attendance": 80}).status_code == 200
    assert c.get("/api/settings/public").json()["school_name"] == "Shree Demo School"
    assert c.get("/api/admin/settings", headers=h).json()["low_attendance"] == "80.0"
    assert c.put("/api/admin/settings", headers=h, json={"low_attendance": 500}).status_code == 422
    assert c.put("/api/admin/settings", headers=STUDENT(), json={"school_name": "Hack"}).status_code == 403
    # password change
    assert c.post("/api/admin/change-password", headers=h, json={"old_password": "wrong", "new_password": "NewPass123"}).status_code == 400
    assert c.post("/api/admin/change-password", headers=h, json={"old_password": "Admin@123", "new_password": "onlyletters"}).status_code == 422
    assert c.post("/api/admin/change-password", headers=h, json={"old_password": "Admin@123", "new_password": "short1"}).status_code == 422
    assert c.post("/api/admin/change-password", headers=h, json={"old_password": "Admin@123", "new_password": "Admin@123"}).status_code == 400
    assert c.post("/api/admin/change-password", headers=h, json={"old_password": "Admin@123", "new_password": "BrandNew456"}).status_code == 200
    assert c.post("/api/auth/admin/login", json={"identifier": "admin@school.com", "password": "Admin@123"}).status_code == 401   # old one is dead
    h2 = login("admin", "admin@school.com", "BrandNew456")
    assert c.post("/api/admin/change-password", headers=h2, json={"old_password": "BrandNew456", "new_password": "Admin@123"}).status_code == 200  # restore
    c.put("/api/admin/settings", headers=ADMIN(), json={"school_name": "School ERP", "low_attendance": 75})


def test_audit_log_records_changes_but_not_secrets_or_failures():
    h = ADMIN()
    sid = c.get("/api/admin/students", headers=h).json()[0]["id"]
    assert c.put(f"/api/admin/students/{sid}", headers=h, json={"roll_no": 5}).status_code == 200
    c.put("/api/admin/students/999999", headers=h, json={"roll_no": 5})                        # 404 -> must not be logged
    c.delete("/api/admin/classes/1", headers=STUDENT())                                         # 403 -> must not be logged
    rows = c.get("/api/admin/audit", headers=h).json()
    assert any(r["action"] == f"Edited student #{sid}" and r["role"] == "admin" for r in rows)
    assert any(r["action"] == "Logged in" for r in rows)
    assert not any("999999" in r["action"] for r in rows)
    assert not any(r["role"] == "student" and "Deleted class" in r["action"] for r in rows)
    assert all("password" not in r["action"].lower() or r["action"] == "Changed the admin password" for r in rows)
    assert c.get("/api/admin/audit", headers=STUDENT()).status_code == 403


def test_pdf_receipt_and_report_card():
    h = ADMIN()
    s = c.get("/api/admin/students", headers=h).json()
    sid = next(x["id"] for x in s if x["name"].startswith("Aarav"))
    pend = c.get("/api/admin/fees/pending", headers=h).json()
    assert pend and "label" in pend[0]
    c.post("/api/fees", headers=h, json={"student_id": sid, "fee_type": "Other", "amount": 2500})
    fid = next(f["fee_id"] for f in c.get("/api/fees/report", headers=h).json() if f["student"].startswith("Aarav") and f["fee_type"] == "Other" and f["total"] == 2500)
    assert c.post("/api/fees/payment", headers=h, json={"fee_id": fid, "amount": 1000, "mode": "UPI"}).status_code == 200
    fees = c.get(f"/api/admin/students/{sid}/profile", headers=h).json()["payments"]
    pid = next(p["payment_id"] for p in fees if p["amount"] == 1000)
    r = c.get(f"/api/pdf/receipt/{pid}", headers=h)
    assert r.status_code == 200 and r.headers["content-type"] == "application/pdf" and r.content.startswith(b"%PDF") and r.content.rstrip().endswith(b"%%EOF")
    assert "attachment" in r.headers["content-disposition"]
    open("/tmp/receipt_test.pdf", "wb").write(r.content)
    assert c.get(f"/api/pdf/receipt/{pid}", headers=STUDENT()).status_code == 200          # the student's own receipt
    assert c.get(f"/api/pdf/receipt/{pid}", headers=login("student", "9100000002")).status_code == 403   # someone else's
    assert c.get(f"/api/pdf/receipt/{pid}", headers=WARDEN()).status_code == 403
    assert c.get("/api/pdf/receipt/999999", headers=h).status_code == 404
    assert c.get(f"/api/pdf/receipt/{pid}").status_code == 401
    # report card for a student who has published results
    for x in s:
        p = c.get(f"/api/admin/students/{x['id']}/profile", headers=h).json()
        if p["results"]:
            r = c.get(f"/api/pdf/report-card?student_id={x['id']}", headers=h)
            assert r.status_code == 200 and r.content.startswith(b"%PDF"), r.text
            open("/tmp/report_test.pdf", "wb").write(r.content)
            break
    else:
        raise AssertionError("seed data has no published results")
    assert c.get("/api/pdf/report-card", headers=h).status_code == 400                  # admin must say which student
    assert c.get("/api/pdf/report-card", headers=WARDEN()).status_code == 403


def test_outpass_lifecycle():
    sh, wh, h = STUDENT(), WARDEN(), ADMIN()
    tmr = date.today() + timedelta(days=1)
    body = {"from_date": str(tmr), "to_date": str(tmr + timedelta(days=2)), "reason": "Family function"}
    assert c.post("/api/hostel/outpass", headers=sh, json={**body, "to_date": str(tmr - timedelta(days=3))}).status_code == 400
    assert c.post("/api/hostel/outpass", headers=sh, json={**body, "from_date": str(date.today() - timedelta(days=9))}).status_code == 400
    assert c.post("/api/hostel/outpass", headers=sh, json=body).status_code == 200
    mine = c.get("/api/hostel/outpass", headers=sh).json()
    assert mine and mine[0]["status"] == "Pending"
    oid = mine[0]["id"]
    assert c.post(f"/api/hostel/outpass/{oid}/decide", headers=sh, json={"decision": "Approved"}).status_code == 403   # student cannot approve
    assert c.post(f"/api/hostel/outpass/{oid}/returned", headers=wh).status_code == 409                                # not approved yet
    assert c.post(f"/api/hostel/outpass/{oid}/decide", headers=wh, json={"decision": "Maybe"}).status_code == 422
    assert c.post(f"/api/hostel/outpass/{oid}/decide", headers=wh, json={"decision": "Approved", "remarks": "Back by Sunday"}).status_code == 200
    assert c.post(f"/api/hostel/outpass/{oid}/decide", headers=wh, json={"decision": "Rejected"}).status_code == 409   # already decided
    assert any("approved" in n["title"].lower() for n in c.get("/api/notifications/my", headers=sh).json())
    assert c.post(f"/api/hostel/outpass/{oid}/returned", headers=h).status_code == 200                                  # admin can too
    assert c.get("/api/hostel/outpass?status=Returned", headers=wh).json()[0]["status"] == "Returned"
    # a day scholar cannot request one
    day = next(x for x in c.get("/api/admin/students", headers=h).json() if x["hostel"] == "No")
    assert c.post("/api/hostel/outpass", headers=login("student", day["mobile"]), json=body).status_code == 400


def test_mess_menu_vacate_and_admin_hostel_access():
    h, wh, sh = ADMIN(), WARDEN(), STUDENT()
    assert c.put("/api/hostel/mess/Monday", headers=sh, json={"Lunch": "x"}).status_code == 403
    assert c.put("/api/hostel/mess/Funday", headers=wh, json={"Lunch": "x"}).status_code == 404
    assert c.put("/api/hostel/mess/Monday", headers=wh, json={"Breakfast": "Poha, tea", "Lunch": "Dal, rice, roti", "Dinner": "Khichdi"}).status_code == 200
    mon = next(r for r in c.get("/api/hostel/mess", headers=sh).json() if r["day"] == "Monday")
    assert mon["Breakfast"] == "Poha, tea" and mon["Snacks"] == "-" and len(c.get("/api/hostel/mess", headers=sh).json()) == 7
    c.put("/api/hostel/mess/Monday", headers=h, json={"Breakfast": "", "Lunch": "Dal, rice, roti"})                    # blank removes an item
    assert next(r for r in c.get("/api/hostel/mess", headers=sh).json() if r["day"] == "Monday")["Breakfast"] == "-"
    # admin sees the same hostel data as the warden, and can manage rooms
    rooms = c.get("/api/hostel/rooms", headers=h).json()
    assert rooms and "occupants" in rooms[0]
    assert c.put(f"/api/hostel/rooms/{rooms[0]['id']}", headers=h, json={"capacity": rooms[0]["capacity"]}).status_code == 200
    assert c.get("/api/hostel/dashboard", headers=h).status_code == 200
    # vacate
    st = next(x for x in c.get("/api/hostel/students", headers=h).json() if x["room"] != "Not allocated")
    assert c.post("/api/hostel/vacate", headers=h, json={"student_id": st["student_id"]}).status_code == 200
    assert c.post("/api/hostel/vacate", headers=h, json={"student_id": st["student_id"]}).status_code == 404
    assert c.post("/api/hostel/allocate", headers=h, json={"student_id": st["student_id"], "room_id": rooms[0]["id"]}).status_code in (200, 400)


def test_grade_never_contradicts_pass_mark():
    from app.utils.helpers import grade_for
    assert grade_for(32.9) == "F" and grade_for(33) == "D" and grade_for(39) == "D" and grade_for(59.9) == "D" and grade_for(60) == "C"
    assert grade_for(90) == "A+" and grade_for(0) == "F"
    h = ADMIN()
    for x in c.get("/api/admin/students", headers=h).json():
        for r in c.get(f"/api/admin/students/{x['id']}/profile", headers=h).json()["results"]:
            assert (r["grade"] == "F") == (r["result"] == "Fail"), r
