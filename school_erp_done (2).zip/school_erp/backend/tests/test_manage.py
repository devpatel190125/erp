import re
import smtplib
import httpx
import pytest
from test_api import c, login   # shares the seeded SQLite test DB
from app.config import settings
from app.ai.textutil import has
from app.ai import ai_service
from app.models import models as m
from app.database import SessionLocal

ADMIN = lambda: login("admin", "admin@school.com", "Admin@123")  # noqa


def test_edit_student_and_conflicts():
    h = ADMIN()
    cls = c.get("/api/admin/classes", headers=h).json()
    cid = cls[0]["id"]
    r = c.post("/api/admin/students", headers=h, json={"name": "Edit Me", "mobile": "9555500001", "admission_no": "EDIT-1",
                                                        "class_id": cid, "parent_name": "Old Parent", "parent_mobile": "9555500002"})
    assert r.status_code == 200, r.text
    sid = r.json()["id"]
    d = c.get(f"/api/admin/students/{sid}", headers=h).json()
    assert d["name"] == "Edit Me" and d["parent_mobile"] == "9555500002"
    r = c.put(f"/api/admin/students/{sid}", headers=h, json={"name": "Edited Name", "roll_no": 77, "email": "edit.me@x.com", "parent_name": "New Parent"})
    assert r.status_code == 200, r.text
    d = c.get(f"/api/admin/students/{sid}", headers=h).json()
    assert (d["name"], d["roll_no"], d["email"], d["parent_name"]) == ("Edited Name", 77, "edit.me@x.com", "New Parent")
    # duplicate mobile / admission no are rejected
    assert c.put(f"/api/admin/students/{sid}", headers=h, json={"mobile": "9100000001"}).status_code == 409
    other_adm = next(x["admission_no"] for x in c.get("/api/admin/students", headers=h).json() if x["id"] != sid)
    assert c.put(f"/api/admin/students/{sid}", headers=h, json={"admission_no": other_adm}).status_code == 409
    # a section from another class is rejected
    secs = c.get("/api/admin/sections", headers=h).json()
    other = next((s for s in secs if s["class_id"] != cid), None)
    if other:
        assert c.put(f"/api/admin/students/{sid}", headers=h, json={"section_id": other["id"]}).status_code == 400
    assert c.put("/api/admin/students/999999", headers=h, json={"name": "Zed"}).status_code == 404


def test_teacher_warden_edit_delete_and_master_data():
    h = ADMIN()
    assert c.post("/api/admin/teachers", headers=h, json={"name": "Temp Teacher", "mobile": "9555500010"}).status_code == 200
    t = next(x for x in c.get("/api/admin/teachers", headers=h).json() if x["mobile"] == "9555500010")
    assert c.put(f"/api/admin/teachers/{t['id']}", headers=h, json={"name": "Renamed Teacher", "email": "t@x.com"}).status_code == 200
    assert any(x["name"] == "Renamed Teacher" and x["email"] == "t@x.com" for x in c.get("/api/admin/teachers", headers=h).json())
    assert c.delete(f"/api/admin/teachers/{t['id']}", headers=h).status_code == 200
    assert all(x["id"] != t["id"] for x in c.get("/api/admin/teachers", headers=h).json())
    # class in use cannot be deleted, an empty one can
    in_use = c.get("/api/admin/classes", headers=h).json()[0]["id"]
    assert c.delete(f"/api/admin/classes/{in_use}", headers=h).status_code == 409
    assert c.post("/api/admin/classes", headers=h, json={"name": "Class Temp"}).status_code == 200
    tmp = next(x for x in c.get("/api/admin/classes", headers=h).json() if x["name"] == "Class Temp")
    assert c.put(f"/api/admin/classes/{tmp['id']}", headers=h, json={"name": "Class Temp 2"}).status_code == 200
    assert c.delete(f"/api/admin/classes/{tmp['id']}", headers=h).status_code == 200


def test_fee_flow_and_ids():
    h = ADMIN()
    cid = c.get("/api/admin/classes", headers=h).json()[0]["id"]
    assert c.post("/api/fees", headers=h, json={"class_id": cid, "fee_type": "Other", "amount": 500}).status_code == 200
    rows = c.get("/api/fees/report", headers=h).json()
    assert rows and "fee_id" in rows[0]
    fid = rows[0]["fee_id"]
    assert c.post("/api/fees/payment", headers=h, json={"fee_id": fid, "amount": 200, "mode": "Cash"}).status_code == 200
    assert c.put(f"/api/fees/{fid}", headers=h, json={"amount": 100}).status_code == 400      # below what is paid
    assert c.put(f"/api/fees/{fid}", headers=h, json={"amount": 900}).status_code == 200
    assert c.delete(f"/api/fees/{fid}", headers=h).status_code == 409                         # has a payment
    d = c.get("/api/admin/dashboard", headers=h).json()
    assert set(d["fee_summary"]) == {"Collected", "Pending"} and "students_by_class" in d and "attendance_trend" in d


def test_deactivated_student_leaves_reports():
    h = ADMIN()
    r = c.post("/api/admin/students", headers=h, json={"name": "Gone Soon", "mobile": "9555500030", "admission_no": "GONE-1",
                                                        "class_id": c.get("/api/admin/classes", headers=h).json()[0]["id"]})
    sid = r.json()["id"]
    c.post("/api/fees", headers=h, json={"student_id": sid, "fee_type": "Other", "amount": 123})
    assert any(x["student"] == "Gone Soon" for x in c.get("/api/fees/report", headers=h).json())
    assert c.delete(f"/api/admin/students/{sid}", headers=h).status_code == 200
    assert not any(x["student"] == "Gone Soon" for x in c.get("/api/fees/report", headers=h).json())


def test_timetable_exam_notice_edit_delete():
    h = ADMIN()
    classes = {x["name"]: x["id"] for x in c.get("/api/admin/classes", headers=h).json()}
    sub = c.get("/api/admin/subjects", headers=h).json()[0]
    cid = classes[sub["class"]]                      # a class that really owns this subject
    assert c.post("/api/timetable", headers=h, json={"class_id": cid, "subject_id": sub["id"], "day": "Saturday",
                                                       "start_time": "07:00", "end_time": "07:40"}).status_code == 200
    p = next(x for x in c.get("/api/timetable", headers=h).json() if x["day"] == "Saturday" and x["time"].startswith("07:00"))
    assert c.put(f"/api/timetable/{p['id']}", headers=h, json={"class_id": cid, "subject_id": sub["id"], "day": "Saturday",
                                                                "start_time": "07:10", "end_time": "07:50", "room": "R9"}).status_code == 200
    assert c.delete(f"/api/timetable/{p['id']}", headers=h).status_code == 200
    assert c.post("/api/exams", headers=h, json={"name": "Temp Exam", "class_id": cid, "subject_id": sub["id"]}).status_code == 200
    e = next(x for x in c.get("/api/exams", headers=h).json() if x["name"] == "Temp Exam")
    assert c.put(f"/api/exams/{e['id']}", headers=h, json={"name": "Temp Exam 2", "max_marks": 50}).status_code == 200
    assert c.delete(f"/api/exams/{e['id']}", headers=h).status_code == 200
    assert c.post("/api/notifications/notices", headers=h, json={"title": "Temp notice", "body": "x"}).status_code == 200
    n = next(x for x in c.get("/api/notifications/notices", headers=h).json() if x["title"] == "Temp notice")
    assert n["mine"] is True
    assert c.put(f"/api/notifications/notices/{n['id']}", headers=h, json={"title": "Temp notice 2", "body": "y"}).status_code == 200
    # a teacher may not touch the admin's notice
    th = login("teacher", "9000000011")
    assert c.delete(f"/api/notifications/notices/{n['id']}", headers=th).status_code == 403
    assert c.delete(f"/api/notifications/notices/{n['id']}", headers=h).status_code == 200


def test_teacher_cannot_use_admin_edit_routes():
    th = login("teacher", "9000000011")
    assert c.put("/api/admin/students/1", headers=th, json={"name": "Hacker"}).status_code == 403
    assert c.delete("/api/admin/classes/1", headers=th).status_code == 403
    sh = login("student", "9100000001")
    assert c.delete("/api/fees/1", headers=sh).status_code == 403


# ------------------------------------------------------------------ email OTP
class FakeSMTP:
    sent, fail = [], False

    def __init__(self, *a, **k):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def starttls(self, **k):
        pass

    def login(self, u, p):
        if FakeSMTP.fail:
            raise smtplib.SMTPAuthenticationError(535, b"bad")

    def send_message(self, msg):
        FakeSMTP.sent.append(msg)


@pytest.fixture
def email_mode(monkeypatch):
    monkeypatch.setattr(settings, "OTP_PROVIDER", "email")
    monkeypatch.setattr(settings, "SMTP_USER", "school@example.com")
    monkeypatch.setattr(settings, "SMTP_PASSWORD", "app-password")
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    FakeSMTP.sent, FakeSMTP.fail = [], False


def test_email_otp_goes_to_registered_email_and_logs_in(email_mode):
    r = c.post("/api/auth/admin/login", json={"identifier": "9000000001", "password": "Admin@123"})   # typed MOBILE
    assert r.status_code == 200, r.text
    assert len(FakeSMTP.sent) == 1
    msg = FakeSMTP.sent[0]
    assert msg["To"] == "admin@school.com"                                     # sent to the REGISTERED email
    otp = re.search(r"\b(\d{6})\b", msg.get_body(("plain",)).get_content()).group(1)
    assert otp != "123456"                                                      # real random OTP, not the dev one
    bad = c.post("/api/auth/verify-otp", json={"identifier": "9000000001", "otp": "123456" if otp != "123456" else "000000", "role": "admin"})
    assert bad.status_code == 401
    ok = c.post("/api/auth/verify-otp", json={"identifier": "9000000001", "otp": otp, "role": "admin"})
    assert ok.status_code == 200 and ok.json()["role"] == "admin"


def test_email_otp_errors(email_mode):
    # user without an email on file -> clear message, nothing stored
    r = c.post("/api/auth/request-otp", json={"identifier": "9100000001", "role": "student"})
    assert r.status_code == 400 and "email" in r.json()["detail"].lower()
    # SMTP login failure -> 502, and it must NOT use up the user's hourly OTP quota
    db = SessionLocal()
    before = db.query(m.OtpVerification).count()
    FakeSMTP.fail = True
    r = c.post("/api/auth/admin/login", json={"identifier": "admin@school.com", "password": "Admin@123"})
    assert r.status_code == 502
    assert db.query(m.OtpVerification).count() == before
    db.close()


# ------------------------------------------------------------------ AI
def test_keyword_matching_is_whole_word():
    assert not has("explain photosynthesis", "plan")
    assert not has("how do i feel about it", "fee")
    assert not has("classroom rules", "room")
    assert has("make a study plan", "plan") and has("pending fees", "fee") and has("rooms free?", "room")


def test_ai_offline_does_not_hijack_normal_questions():
    sh = login("student", "9100000001")
    r = c.post("/api/ai/chat", headers=sh, json={"message": "explain photosynthesis"}).json()
    assert not r["reply"].startswith("Study plan") and r["mode"] == "offline" and r["note"]
    r = c.post("/api/ai/chat", headers=sh, json={"message": "make me a 3 day study plan"}).json()
    assert r["reply"].startswith("Study plan for 3 day")
    assert c.get("/api/ai/status", headers=sh).json()["mode"] == "offline"


def test_ai_reports_api_errors_instead_of_hiding_them(monkeypatch):
    monkeypatch.setattr(settings, "ANTHROPIC_API_KEY", "sk-test")
    sh = login("student", "9100000001")

    def bad_key(*a, **k):
        req = httpx.Request("POST", "https://api.anthropic.com/v1/messages")
        return httpx.Response(401, request=req, text="invalid x-api-key")
    monkeypatch.setattr(httpx, "post", bad_key)
    r = c.post("/api/ai/chat", headers=sh, json={"message": "my attendance"}).json()
    assert r["mode"] == "offline" and "key" in r["note"].lower()
    assert "attendance" in r["reply"].lower()                                  # still answered by the fallback

    seen = {}

    def good(url, headers=None, json=None, timeout=None):
        seen["msgs"] = json["messages"]
        req = httpx.Request("POST", url)
        return httpx.Response(200, request=req, json={"content": [{"type": "text", "text": "Hello from Claude"}]})
    monkeypatch.setattr(httpx, "post", good)
    r = c.post("/api/ai/chat", headers=sh, json={"message": "hi"}).json()
    assert r["mode"] == "online" and r["label"] == "Claude" and r["reply"] == "Hello from Claude" and r["note"] is None
    assert seen["msgs"][0]["role"] == "user"                                   # API requires user-first messages


def test_clean_history_alternates_and_starts_with_user():
    h = [{"role": "assistant", "content": "a0"}, {"role": "user", "content": "u1"}, {"role": "user", "content": "u2"},
         {"role": "assistant", "content": "a1"}]
    out = ai_service.clean_history(h)
    assert [x["role"] for x in out] == ["user", "assistant"] and out[0]["content"] == "u1\nu2"


# ------------------------------------------------------------------ file access
def test_uploaded_files_are_not_open_to_everyone():
    th = login("teacher", "9000000011")
    subs = c.get("/api/teachers/subjects", headers=th).json()
    s0 = subs[0]
    r = c.post("/api/files/materials", headers=th, data={"title": "Notes", "class_id": s0["class_id"], "subject_id": s0["id"]},
               files={"file": ("n.txt", b"hello", "text/plain")})
    assert r.status_code == 200, r.text
    db = SessionLocal()
    fn = db.query(m.StudyMaterial).order_by(m.StudyMaterial.id.desc()).first().file_path
    db.close()
    assert c.get(f"/api/files/{fn}", headers=th).status_code == 200
    assert c.get(f"/api/files/{fn}", headers=ADMIN()).status_code == 200
    assert c.get(f"/api/files/{fn}", headers=login("warden", "9300000001")).status_code == 403
    assert c.get(f"/api/files/{fn}").status_code == 401


def test_ai_shows_the_real_reason_for_a_400(monkeypatch):
    monkeypatch.setattr(settings, "ANTHROPIC_API_KEY", "sk-test")
    sh = login("student", "9100000001")

    def fake(msg):
        def post(*a, **k):
            req = httpx.Request("POST", "https://api.anthropic.com/v1/messages")
            return httpx.Response(400, request=req, json={"type": "error", "error": {"type": "invalid_request_error", "message": msg}})
        return post
    monkeypatch.setattr(httpx, "post", fake("Your credit balance is too low to access the Anthropic API."))
    r = c.post("/api/ai/chat", headers=sh, json={"message": "explain photosynthesis"}).json()
    assert "credit" in r["note"].lower() and "billing" in r["note"].lower()
    monkeypatch.setattr(httpx, "post", fake("model: claude-fake is not a valid model"))
    r = c.post("/api/ai/chat", headers=sh, json={"message": "hi"}).json()
    assert "AI_MODEL" in r["note"]
    monkeypatch.setattr(httpx, "post", fake("messages: text content blocks must be non-empty"))
    r = c.post("/api/ai/chat", headers=sh, json={"message": "hi"}).json()
    assert "non-empty" in r["note"]


# ------------------------------------------------------------------ free providers
def _openai_ok(seen):
    def post(url, headers=None, json=None, timeout=None):
        seen.update(url=url, headers=headers, json=json, timeout=timeout)
        return httpx.Response(200, request=httpx.Request("POST", url), json={"choices": [{"message": {"content": "Plants make food from light."}}]})
    return post


@pytest.mark.parametrize("prov,url_part,model", [("gemini", "generativelanguage.googleapis.com/v1beta/openai/chat/completions", "gemini-flash-latest"),
                                                   ("groq", "api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile"),
                                                   ("ollama", "localhost:11434/v1/chat/completions", "llama3.2")])
def test_free_providers_use_the_right_endpoint_and_format(monkeypatch, prov, url_part, model):
    monkeypatch.setattr(settings, "AI_PROVIDER", prov)
    monkeypatch.setattr(settings, "AI_API_KEY", "" if prov == "ollama" else "free-key-123")
    monkeypatch.setattr(settings, "AI_MODEL", "claude-sonnet-4-6")          # stale Claude name left in .env must be ignored
    seen = {}
    monkeypatch.setattr(httpx, "post", _openai_ok(seen))
    sh = login("student", "9100000001")
    assert c.get("/api/ai/status", headers=sh).json()["mode"] == "online"
    r = c.post("/api/ai/chat", headers=sh, json={"message": "explain photosynthesis"}).json()
    assert r["mode"] == "online" and r["reply"] == "Plants make food from light." and r["note"] is None
    assert url_part in seen["url"] and seen["json"]["model"] == model
    assert seen["headers"]["Authorization"].startswith("Bearer ")
    assert seen["json"]["messages"][0]["role"] == "system" and seen["json"]["messages"][-1] == {"role": "user", "content": "explain photosynthesis"}
    if prov == "ollama":
        assert seen["timeout"] >= 120                                      # local models are slow on CPU


def test_free_provider_errors_are_explained(monkeypatch):
    monkeypatch.setattr(settings, "AI_PROVIDER", "gemini")
    monkeypatch.setattr(settings, "AI_API_KEY", "k")
    monkeypatch.setattr(settings, "AI_MODEL", "")
    sh = login("student", "9100000001")

    def err(code, body):
        return lambda *a, **k: httpx.Response(code, request=httpx.Request("POST", "https://x"), json=body)
    monkeypatch.setattr(httpx, "post", err(429, [{"error": {"message": "Quota exceeded"}}]))      # Gemini returns a LIST
    assert "quota" in c.post("/api/ai/chat", headers=sh, json={"message": "hi"}).json()["note"].lower()
    monkeypatch.setattr(httpx, "post", err(400, {"error": {"message": "API key not valid. Please pass a valid API key."}}))
    assert "API key not valid" in c.post("/api/ai/chat", headers=sh, json={"message": "hi"}).json()["note"]
    monkeypatch.setattr(httpx, "post", err(404, {"error": {"message": "models/foo is not found"}}))
    assert "AI_MODEL" in c.post("/api/ai/chat", headers=sh, json={"message": "hi"}).json()["note"]


def test_ollama_down_gives_a_helpful_note(monkeypatch):
    monkeypatch.setattr(settings, "AI_PROVIDER", "ollama")
    monkeypatch.setattr(settings, "AI_MODEL", "")

    def down(*a, **k):
        raise httpx.ConnectError("refused")
    monkeypatch.setattr(httpx, "post", down)
    r = c.post("/api/ai/chat", headers=login("student", "9100000001"), json={"message": "hi"}).json()
    assert "ollama" in r["note"].lower() and r["mode"] == "offline" and r["reply"]


def test_provider_without_key_stays_offline(monkeypatch):
    monkeypatch.setattr(settings, "AI_PROVIDER", "gemini")
    monkeypatch.setattr(settings, "AI_API_KEY", "")
    assert ai_service.active() is None


def test_busy_503_is_retried_then_falls_back_to_lite_model(monkeypatch):
    monkeypatch.setattr(settings, "AI_PROVIDER", "gemini")
    monkeypatch.setattr(settings, "AI_API_KEY", "k")
    monkeypatch.setattr(settings, "AI_MODEL", "")
    monkeypatch.setattr(ai_service.time, "sleep", lambda s: None)
    sh = login("student", "9100000001")
    models = []

    def flaky(ok_after):
        def post(url, headers=None, json=None, timeout=None):
            models.append(json["model"])
            req = httpx.Request("POST", url)
            if len(models) <= ok_after:
                return httpx.Response(503, request=req, json=[{"error": {"message": "This model is currently experiencing high demand."}}])
            return httpx.Response(200, request=req, json={"choices": [{"message": {"content": "Recovered answer"}}]})
        return post
    monkeypatch.setattr(httpx, "post", flaky(1))                       # one 503, then fine -> same model
    r = c.post("/api/ai/chat", headers=sh, json={"message": "hi"}).json()
    assert r["reply"] == "Recovered answer" and r["mode"] == "online" and models == ["gemini-flash-latest"] * 2
    models.clear()
    monkeypatch.setattr(httpx, "post", flaky(3))                       # main model stays busy -> lite model answers
    r = c.post("/api/ai/chat", headers=sh, json={"message": "hi"}).json()
    assert r["reply"] == "Recovered answer" and models == ["gemini-flash-latest"] * 3 + ["gemini-flash-lite-latest"]
    models.clear()
    monkeypatch.setattr(httpx, "post", flaky(99))                      # everything busy -> clear message + offline answer
    r = c.post("/api/ai/chat", headers=sh, json={"message": "my attendance"}).json()
    assert r["mode"] == "offline" and "overloaded" in r["note"].lower() and "attendance" in r["reply"].lower()
    assert len(models) == 6


def test_warden_dashboard_has_all_cards():
    d = c.get("/api/hostel/dashboard", headers=login("warden", "9300000001")).json()
    for k in ("total_students", "total_rooms", "occupied_rooms", "available_rooms", "today_present", "today_absent",
              "pending_complaints", "bed_occupancy", "attendance_chart", "complaints_by_category"):
        assert k in d, k
    assert d["total_rooms"] >= 1
