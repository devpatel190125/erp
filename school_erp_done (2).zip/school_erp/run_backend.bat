@echo off
cd backend
if not exist .env (
  copy .env.example .env >nul
  echo.
  echo  First run: a new backend\.env was created. Open it, set DATABASE_URL and SECRET_KEY, then run this file again.
  notepad .env
  pause
  exit /b
)
if not exist venv ( python -m venv venv & call venv\Scripts\activate & pip install -r requirements.txt ) else ( call venv\Scripts\activate )
python seed.py
uvicorn app.main:app --reload --port 8000
